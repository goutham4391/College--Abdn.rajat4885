
    
                <!DOCTYPE html>
        <html lang="en" xmlns:html5="http://www.w3.org/1999/xhtml">
        <head>
            <title>Login &middot; Postgraduate & Online Application Portal &middot; The University of Aberdeen</title>
            <meta http-equiv="content-type" content="text/html; charset=utf-8">
            <meta http-equiv="content-language" content="en-gb">
            <meta name="author" content="University of Aberdeen">
            <meta name="description" content="Submit and manage applications for postgraduate or online study at the University of Aberdeen.">
            <meta name="copyright" content="&copy; University of Aberdeen, 2022">
            <meta name="title" content="University of Aberdeen &middot; Postgraduate & Online Application Portal">
            <meta name="viewport" content="width=device-width, initial-scale=1">
                        <link rel="icon" type="image/png" href="./favicon.1613389569.png">
                        <link rel="stylesheet" type="text/css" href="style/reset.1613389570.css" media="screen, handheld, print">
    <link rel="stylesheet" type="text/css" href="style/login.1613389570.css" media="screen, handheld, print">
    
    <link rel="stylesheet" type="text/css" href="style/ff.1613389570.css" media="screen, handheld, print">

    <!--[if IE 9]>
        <link rel="stylesheet" type="text/css" href="style/ie9.1613389570.css" media="screen, handheld, print">
    <![endif]-->

    <!--[if IE 8]>
        <link rel="stylesheet" type="text/css" href="style/ie8.1613389570.css" media="screen, handheld, print">
    <![endif]-->

    <!--[if lte IE 7]>
        <link rel="stylesheet" type="text/css" href="style/ie6_7.1613389570.css" media="screen, handheld, print">
    <![endif]-->

    <!-- COLORBOX -->
    <link rel="stylesheet" type="text/css" href="style/jquery.colorbox.1613389570.css" media="screen">

    
    
    <!-- VALIDATION ENGINE -->
    <link rel="stylesheet" type="text/css" href="style/jquery.validationEngine.1613389570.css" media="screen">

    
    

<!-- Begin Google Tag Manager -->
<!-- Tracking code updated 03 Sep 2015 -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TLJCQH"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TLJCQH');</script>
<!-- End Google Tag Manager -->

<!-- ***JAVASCRIPT*** -->
<script type="text/javascript" src="scripts/jquery.1614695919.js" charset="utf-8"></script>
<script type="text/javascript" src="scripts/custom.1651231038.js" charset="utf-8"></script>
<script type="text/javascript" src="scripts/modernizr.1614695920.js" charset="utf-8"></script>
<script type="text/javascript" src="scripts/detectizr.1614695919.js" charset="utf-8"></script>

<!-- VARIABLES -->
<script type="text/javascript">
    var user = 'applicant';
    var uploader = 'standard';

    var debugOn = false; //should we print console.log messages
    var responseFromServer = false; //have we had a successful (200) response from the server
    var countTimerRun = 1; //is this the first timer run?

    var validateSessionPreviousData = 'x';
    var validateSessionTimerRun = 1;
    var messageText = 'Changes have been made to the form.\n\nIf you leave this page, those changes will not be saved.';
    var menuTopPaddingTop = 10, menuTopPaddingBottom = 15;
    var httpAjax = 'https://www.abdn.ac.uk/pgap/apply/ajax/';
    var spinnerSrc = 'images/spinner.1613389569.gif';
</script>

<!-- COLORBOX -->
<script type="text/javascript" src="scripts/jquery.colorbox.1614695919.js" charset="utf-8"></script>




<!-- VALIDATION ENGINE -->
<script type="text/javascript" src="scripts/jquery.validationEngine.en.1614695920.js" charset="utf-8"></script>
<script type="text/javascript" src="scripts/jquery.validationEngine.1614695920.js" charset="utf-8"></script>



<script type="text/javascript">
    function timerFunction(){
        if(!isIdle) {
                getFileList(false);
            }
    }

    function check_begin_application(){
        if (document.getElementById('autofill-data').checked) {
            $('#check_application').css({
                'display' : 'visible',
                'padding-top' : '15px'
            });
        } else {
            $('#check_application').css('display', 'none');
        }
    }

    function begin_application(programme_code){
        
        $('.begin_application').colorbox({
            href: "https://www.abdn.ac.uk/pgap/apply/popups/popup_apply_prog.inc.php?type=new&programme_code=" + programme_code,
            width: '500px',
            height: '350px'
        });
    }

    function update_application(programme_code){
        $('.update_application').colorbox({
            href: "https://www.abdn.ac.uk/pgap/apply/popups/popup_apply_prog.inc.php?type=update&programme_code=" + programme_code,
            width: '500px',
            height: '220px'
        });
    }

    // next three functions for help part (scrolling)
    function filterPath(string){
        return string
        .replace(/^\//,'')
        .replace(/(index|default).[a-zA-Z]{3,4}$/,'')
        .replace(/\/$/,'');
    }

    // Use the first element that is "scrollable"  (cross-browser fix?)
    function scrollableElement(els){
        for(var i = 0, argLength = arguments.length; i <argLength; i++){
            var el = arguments[i],
            $scrollElement = $(el);
            if($scrollElement.scrollTop() > 0){
                return el;
            } else {
                $scrollElement.scrollTop(1);
                var isScrollable = $scrollElement.scrollTop() > 0;
                $scrollElement.scrollTop(0);
                if(isScrollable){
                    return el;
                }
            }
        }
        return [];
    }

    function inviewAttach(){
        $('div.token-input-dropdown-facebook, ul.ui-autocomplete').each(function(){
            var thiz_id = $(this).attr('id');
            inviewConfig(thiz_id);
        });
    }

    function inviewConfig(thiz_id){
        $('#' + thiz_id).bind('inview', function(event, isInView, visiblePartX, visiblePartY){
            if($('#' + thiz_id).is(':visible') && ((isInView && visiblePartY == 'top') || (!isInView))){
                if (thiz_id === 'div-token-input-country') {
                    if (window.location.href.indexOf('pg04') !== -1) {
                        $('#' + thiz_id).css({top: '221.5px', left: '193px'});
                    } else if (window.location.href.indexOf('pg06') !== -1) {
                        $('#' + thiz_id).css({top: '297px', left: '193px'});
                    }
                }

                //partially out of viewport || completely out of viewport
                var scroll_top = $(window).scrollTop();
                var window_height = $(window).height();
                var dropdown_offset_top = $('#' + thiz_id).offset().top;
                var dropdown_height = $('#' + thiz_id).outerHeight();
                var input_height = $('input[type="text"]:enabled:first').outerHeight(); //27px
                var fixed_menu_height = $('div#breadcrumbs_moved').length == 1 ? $('div#content_top_navi').outerHeight() : 0;

                var scroll_by = scroll_top + (((dropdown_offset_top - window_height) + dropdown_height) - scroll_top);

                var content_top_height = $('#content_top').height(); //230px
                var content_footer_height = $('#content_footer').height(); //100px
                var main_body_height = Math.max($('#navigation').height(), $('#main_body').height());
                var page_height = content_top_height + main_body_height + content_footer_height;
                page_height = page_height == 0 ? $('body').height() : page_height;

                //scroll_by as much as you can without causing a bounce if the dropdown content was to shrink during typing
                if((dropdown_offset_top + dropdown_height) > page_height)
                    scroll_by = scroll_by - ((dropdown_offset_top + dropdown_height) - page_height) - 1;
                //make sure if we are scrolling, the top of our dropdown is still in the viewpoint
                else if((input_height + dropdown_height) > (window_height - fixed_menu_height))
                    scroll_by -= (input_height + dropdown_height) - (window_height - fixed_menu_height);

                if(scroll_by > scroll_top)
                    $('html, body').animate({scrollTop: scroll_by}, 'slow');
            }
        });
    }

    // Shows/Hides Post Code field based on value of country input
    function ShowHidePostCodeAjax(inputId, containerId, focusId)
    {
        var adm_coun_ref = $(`input#${inputId}`).val();
        $.ajax({
            url: `https://www.abdn.ac.uk/pgap/apply/ajax/is_uk_plus.php?adm_coun_ref=${adm_coun_ref}`,
            success: function(isUkPlus){
                if(isUkPlus) {
                    $(`#${containerId}`).show('fast', function(){
                        if($('.no-opacity').length > 0){
                            this.style.removeAttribute('filter');
                        }
                    });
                    $('body').trigger('click');
                    $(`#${focusId}`).focus();
                } else {
                    $(`#${containerId}`).hide('fast');
                }
            }
        });
    }

    var usePost = true; //.date_one_day
    var count = 0; //.date_one_day
    var usePost2 = true; //.date_two_day
    var count2 = 0; //.date_two_day

    var menuObject = {
        getDayMenu : function(limit1, limit2, inclusive){
            var year = $('select.date_one_year').val() || '';
            var month = $('select.date_one_month').val() || '';
            var timePeriod = $('select.date_one_year option:eq(1)').val() > $('select.date_one_year option:eq(2)').val() ? 'past' : 'future';
            var now = 'now';
            //console.log('?now=' + now + '&year=' + year + '&month=' + month + '&timePeriod=' + timePeriod + '&limit1=' + limit1 + '&limit2=' + limit2 + '&inclusive=' + inclusive);
            if(year != '' && month != '' && $('select.date_one_day').length){
                $.getJSON('https://www.abdn.ac.uk/pgap/apply/ajax/day.php', {now: now, year : year, month : month, timePeriod: timePeriod, limit1: limit1, limit2: limit2, inclusive: inclusive}, function(data){
                    if(!data.error){
                        $('.iphone select.date_one_day').blur();
                        var disabled = $('select.date_one_day option:eq(0)[disabled]').length;

                        var selected = $('select.date_one_day :selected').not(':disabled').attr('value');
                        selected = selected == '' ? undefined : selected;
                        var copyOfSelected = selected;
                        
                        $('select.date_one_day').html(data.menu).attr('disabled', 'disabled');
                        if(disabled) $('select.date_one_day option:eq(0)').attr({disabled: 'disabled', selected: 'selected'});
                        if(selected != undefined){
                            if((copyOfSelected != undefined) || (copyOfSelected == undefined && usePost)){
                                $('select.date_one_day option[value="' + selected + '"]').attr('selected', 'selected');
                            }
                        }

                        if($('select.date_one_day option').length == 1){
                            $('select.date_one_day option:gt(0)').remove(); //clear
                        }

                        $('select.date_one_day').removeAttr('disabled');
                    }
                });
            } else {
                $('select.date_one_day option:gt(0)').remove(); //clear
                $('select.date_one_month').change();
            }
        },

        getMonthMenu : function(limit1, limit2, inclusive){
            var year = $('select.date_one_year').val() || '';
            var timePeriod = $('select.date_one_year option:eq(1)').val() > $('select.date_one_year option:eq(2)').val() ? 'past' : 'future';
            var now = 'now';
            //console.log('?now=' + now + '&year=' + year + '&timePeriod=' + timePeriod + '&limit1=' + limit1 + '&limit2=' + limit2 + '&inclusive=' + inclusive);
            if(year != ''){
                $.getJSON('https://www.abdn.ac.uk/pgap/apply/ajax/month.php', {now: now, year: year, timePeriod: timePeriod, limit1: limit1, limit2: limit2, inclusive: inclusive}, function(data){
                    if(!data.error){
                        $('.iphone select.date_one_month').blur();
                        var disabled = $('select.date_one_month option:eq(0)[disabled]').length;

                        var selected = $('select.date_one_month :selected').not(':disabled').attr('value');
                        selected = selected == '' ? undefined : selected;
                        var copyOfSelected = selected;
                        
                        $('select.date_one_month').html(data.menu).attr('disabled', 'disabled');
                        if(disabled) $('select.date_one_month option:eq(0)').attr({disabled: 'disabled', selected: 'selected'});

                        if(selected != undefined){
                            if(count > 0){ //not first time but until used until the server updates the dropdowns
                                usePost = false;
                            }

                            if(copyOfSelected != undefined){
                                $('select.date_one_month option[value="' + selected + '"]').attr('selected', 'selected');
                            } else if(copyOfSelected == undefined && usePost){
                                $('select.date_one_month option[value="' + selected + '"]').attr('selected', 'selected');
                            }

                            if($('select.date_one_day').length)
                                menuObject.getDayMenu(limit1, limit2, inclusive); //update days

                            count++;
                        } else {
                            $('select.date_one_day option:gt(0)').remove(); //clear
                        }

                        if($('select.date_one_month option').length == 1){
                            $('select.date_one_month option:gt(0)').remove(); //clear
                            $('select.date_one_day option:gt(0)').remove(); //clear
                        }
                        $('select.date_one_month').removeAttr('disabled');
                    }
                });
            } else {
                $('select.date_one_month option:gt(0)').remove(); //clear
                $('select.date_one_day option:gt(0)').remove(); //clear
            }
        },
        getDayMenu2 : function(limit1, limit2, inclusive){
            var year = $('select.date_two_year').val() || '';
            var month = $('select.date_two_month').val() || '';
            var timePeriod = $('select.date_two_year option:eq(1)').val() > $('select.date_two_year option:eq(2)').val() ? 'past' : 'future';
            var now = 'now';
            //console.log('?now=' + now + '&year=' + year + '&month=' +  month + '&timePeriod=' + timePeriod + '&limit1=' + limit1 + '&limit2=' + limit2 + '&inclusive=' + inclusive);
            if(year != '' && month != '' && $('select.date_two_day').length){
                $.getJSON('https://www.abdn.ac.uk/pgap/apply/ajax/day.php', {now: now, year : year, month : month, timePeriod: timePeriod, limit1: limit1, limit2: limit2, inclusive: inclusive}, function(data){
                    if(!data.error){
                        $('.iphone select.date_two_day').blur();
                        var disabled = $('select.date_two_day option:eq(0)[disabled]').length;

                        var selected = $('select.date_two_day :selected').not(':disabled').attr('value');
                        selected = selected == '' ? undefined : selected;
                        var copyOfSelected = selected;
                        
                        $('select.date_two_day').html(data.menu).attr('disabled', 'disabled');
                        if(disabled) $('select.date_two_day option:eq(0)').attr({disabled: 'disabled', selected: 'selected'});
                        if(selected != undefined){
                            if((copyOfSelected != undefined) || (copyOfSelected == undefined && usePost2)){
                                $('select.date_two_day option[value="' + selected + '"]').attr('selected', 'selected');
                            }
                        }

                        if($('select.date_two_day option').length == 1){
                            $('select.date_two_day option:gt(0)').remove(); //clear
                        }

                        $('select.date_two_day').removeAttr('disabled');
                    }
                });
            } else {
                $('select.date_two_day option:gt(0)').remove(); //clear
                $('select.date_two_month').change();
            }
        },

        getMonthMenu2 : function(limit1, limit2, inclusive){
            var year = $('select.date_two_year').val() || '';
            var timePeriod = $('select.date_two_year option:eq(1)').val() > $('select.date_two_year option:eq(2)').val() ? 'past' : 'future';
            var now = 'now';
            //console.log('?now=' + now + '&year=' + year + '&timePeriod=' + timePeriod + '&limit1=' + limit1 + '&limit2=' + limit2 + '&inclusive=' + inclusive);
            if(year != ''){
                $.getJSON('https://www.abdn.ac.uk/pgap/apply/ajax/month.php', {now: now, year: year, timePeriod: timePeriod, limit1: limit1, limit2: limit2, inclusive: inclusive}, function(data){
                    if(!data.error){
                        $('.iphone select.date_two_month').blur();
                        var disabled = $('select.date_two_month option:eq(0)[disabled]').length;

                        var selected = $('select.date_two_month :selected').not(':disabled').attr('value');
                        selected = selected == '' ? undefined : selected;
                        var copyOfSelected = selected;
                        
                        $('select.date_two_month').html(data.menu).attr('disabled', 'disabled');
                        if(disabled) $('select.date_two_month option:eq(0)').attr({disabled: 'disabled', selected: 'selected'});

                        if(selected != undefined){
                            if(count2 > 0){ //not first time but until used until the server updates the dropdowns
                                usePost2 = false;
                            }

                            if(copyOfSelected != undefined){
                                $('select.date_two_month option[value="' + selected + '"]').attr('selected', 'selected');
                            } else if(copyOfSelected == undefined && usePost2){
                                $('select.date_two_month option[value="' + selected + '"]').attr('selected', 'selected');
                            }

                            if($('select.date_two_day').length)
                                menuObject.getDayMenu2(limit1, limit2, inclusive); //update days

                            count2++;
                        } else {
                            $('select.date_two_day option:gt(0)').remove(); //clear
                        }

                        if($('select.date_two_month option').length == 1){
                            $('select.date_two_month option:gt(0)').remove(); //clear
                            $('select.date_two_day option:gt(0)').remove(); //clear
                        }
                        $('select.date_two_month').removeAttr('disabled');
                    }
                });
            } else {
                $('select.date_two_month option:gt(0)').remove(); //clear
                $('select.date_two_day option:gt(0)').remove(); //clear
            }
        }
    }

    var message = ''; //global
    window.onbeforeunload = function (event){
        if(message != ''){
            if(typeof event == 'undefined'){
                event = window.event;
            }

            if(event){
                event.returnValue = message;
            }

            return message;
        } else {
            return;
        }
    }
    </script>
        <script type="text/javascript">
    <!--
    $(document).ready(function(){
        if(!!navigator.userAgent.match(/Trident\/7\./)) //IE11
            $('html').addClass('ie').addClass('ie11');

        Detectizr.detect({detectScreen: false});

            
        
        
        
        
        
        
        $('form.pg_form').on('change keyup paste', 'input:not(:hidden):not(input.token), select, textarea', function (event){
            var keyCodes = new Array();
            keyCodes['40'] = 'DOWN';
            keyCodes['35'] = 'END';
            keyCodes['13'] = 'ENTER';
            keyCodes['27'] = 'ESCAPE';
            keyCodes['36'] = 'HOME';
            keyCodes['37'] = 'LEFT';
            keyCodes['107'] = 'NUMPAD_ADD';
            keyCodes['110'] = 'NUMPAD_DECIMAL';
            keyCodes['111'] = 'NUMPAD_DIVIDE';
            keyCodes['108'] = 'NUMPAD_ENTER';
            keyCodes['106'] = 'NUMPAD_MULTIPLY';
            keyCodes['109'] = 'NUMPAD_SUBTRACT';
            keyCodes['34'] = 'PAGE_DOWN';
            keyCodes['33'] = 'PAGE_UP';
            keyCodes['39'] = 'RIGHT';
            keyCodes['9'] = 'TAB';
            keyCodes['38'] = 'UP';
            keyCodes['16'] = 'SHIFT';
            keyCodes['17'] = 'CONTROL';

            var current_value = $(this).val() || '';

            if(current_value != '' && keyCodes[event.keyCode] === undefined)
                message = messageText;
        });

        var save_scroll_position = -1;

        $(window).on('scroll.monitor',
            function(){
                if(save_scroll_position > -1 && $(window).scrollTop() != save_scroll_position)
                    $('#selected').removeAttr('id');
            }
        );

        $('a.hash').on('click', function(event){
            var scrollElem = scrollableElement('html', 'body');
            var classes = $(this).attr('class').split(/\s/);
            var lastClass = classes[classes.length - 1];

            var menuTopHeight = ($('div#content_top_navi').height() + menuTopPaddingTop + menuTopPaddingBottom + 15) || 0;

            $('#selected').removeAttr('id');
            $(this).attr('id', 'selected');
            save_scroll_position = -1; //clear

            $(scrollElem)
                .stop()
                .animate({scrollTop: ($('#' + lastClass).offset().top - menuTopHeight)},
                {complete: function(){ save_scroll_position = $(window).scrollTop(); }}, 800);

            event.preventDefault();
        });

    
        
    
        
        $("#logout").on('click', function(){
            message = ''; //clear
        });

        /* Popup box to display when clicking 'My Account' link */
        $("#confirm_login").on('click', function(){
            message = ''; //clear

            var page_url = document.URL;

            /* Do not reload login box if not on account page */
            if(page_url.indexOf("account") !== -1){
                window.location = "https://www.abdn.ac.uk/pgap/account/";
            } else {
                $('#confirm_login').colorbox({href: "https://www.abdn.ac.uk/pgap/includes/popup_login.inc.php", 'width': '440px', 'height': '270px'});
            }
        });

        
        $.ajaxSetup({ cache: false, timeout: 90000 });

        /* Submit form on pressing enter */
        $(document).on('keypress', 'input:not([type="submit"])', function(event){
            var page_id = 'login';

            if(page_id != 'admn_bk' || $('.firefox').length == 0){
                var thiz = $(this);
                var thiz_val = $(this).val() || '';

                //delay(function(){
                    //if(event.which == 13 && $('ul.ui-autocomplete:visible').length === 0){
                    if(event.which == 13 && thiz_val != '' && !$('.close_popup').is(':focus')){
                        if(thiz.prop('type') == 'email' && thiz_val.match(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/) == null)
                            return false;

                        $(event.target).closest('form').not('.uploadForm').submit(); //$('form').not('.uploadForm').submit();
                        return false;
                    }
                //}, 1);
            }
        });

        /* Smooth scrolling 'Back to Top' */
        delay(function(){
            if(!$('div#to_top').is(':visible') && $(window).scrollTop() != 0)
                $('div#to_top').fadeIn();
        }, 800);

        $(window).scroll(function(){
            if($(this).scrollTop() != 0){
                $('div#to_top').fadeIn();
            } else {
                $('div#to_top').fadeOut();
            }
        });

        $('div#to_top').on('click', function(){
            $('body, html')
                .stop()
                .animate({ scrollTop: 0 }, 800);
        });

        function load_token(token_query){
            var valid_token_query = false;

            switch(token_query){
                case 'pgt':
                    $('input#search').tokenInput('add', {id: 'Postgraduate Taught', name: 'Postgraduate Taught'});
                    valid_token_query = true;
                    break;
                case 'pgr':
                    $('input#search').tokenInput('add', {id: 'Postgraduate Research', name: 'Postgraduate Research'});
                    valid_token_query = true;
                    break;
                case 'online':
                    $('input#search').tokenInput('add', {id: 'Online Learning', name: 'Online Learning'});
                    valid_token_query = true;
                    break;
                default:
                    $('input.token').trigger('click'); //focus input box and show hint
                    break;
            }

            if(valid_token_query){
                $('.token-search-button').trigger('click');

                delay(function(){
                    $('body').trigger('click');
                    $('input.token').trigger('blur');
                }, 101);
            }
        }

        $('.view-all').on('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            var token_query = $(this).data('query');
            load_token(token_query);
        });

        
                                                
        /*padding-bottom fix for use with tokenInputs which reluctantly add 4px to their bottom*/
        $('.reg_form_input,.app_input,.close_form_input').each(function(){
            if($(this).find('.token-input-list-facebook').length == 0 && $(this).find('[type="text"],[type="password"],[type="email"],[type="tel"]').length > 0)
                $(this).css('padding-bottom', parseInt($(this).css('padding-bottom')) + 4);
        });

        //for tabbing, can't be in jquery.tokenInput.js
        $('input[type="text"].token').focus(function(){
            var id = 'ul-' + $(this).attr('id');

            //FF only - tabbing doesnt fire when token limit reached and input_box therefore disabled
            //remove focus glow on other disabled input tokens
            if($('.firefox').length > 0){
                $('ul.thin:visible').each(function(){
                    if($(this).find('input[type="text"].token:hidden').length == 1)
                        $(this).removeAttr('style');
                });
            }

            $('ul#' + id).css({
                border: '1px solid #787e5b',
                'box-shadow': '0 0 5px 0 #b0c358',
                '-webkit-box-shadow': '0 0 5px 0 #b0c358',
                '-moz-box-shadow': '0 0 5px 0 #b0c358'
            });
        });

        
        var initialise_forms = function(){
            //focus first input
            $('form:first').not('.login_form, #relogin, .uploadForm').find(':input:enabled:first').filter('[value=""]').not('select, :hidden, .date_one_year, :file, [type="submit"]').focus();
            $('form.login_form, form#relogin, form#admin_form').find(':input[value=""]:enabled:first').not('[type="submit"]').focus();

            //validationEngine
            $('form.reg_form, form.pg_form').validationEngine({
                promptPosition: 'centerRight',
                autoPositionUpdate: true,
                addPromptClass: 'override-prompt-style redTransparentPopup'
            });
            $('form.pg_popup').validationEngine({promptPosition: 'centerRight', autoPositionUpdate: false});
            $('form#admin_form, form#relogin, form.begin_application, form#change_application, form.delete_application, \
            form#extend_application, form.withdraw_application').validationEngine();

            $('form.acc_form').validationEngine({
                promptPosition: 'centerRight'
            });

            $('form.login_form, form.forgot_password, form.reset_password, form.set_password').validationEngine({promptPosition: 'topRight'});

            /* if JavaScript enabled */
            $('form, div.app_label').css('opacity', '1');
            $('input.minimal').css('opacity', '1');
            $('input.minimal').addClass('minimal_cursor');

            $('.close_popup').on('click', function(){
                parent.jQuery.fn.colorbox.close();
            });

        }

        initialise_forms();

        //stop dropdown opening if no selectable values exist
        $('select').on('mousedown', function(event){
            if($(this).is('select') === true){
                if(($(this).children().size() == 0) || ($(this).children().size() == 1 && $(this).children(':first').val() == '') || ($(this).children().size() == 2 && $(this).children(':first:disabled').val() == '' && $(this).children(':selected').index() != 0)){
                    if($('.ie').length == 0){
                        event.preventDefault();
                    } else {
                        event.returnValue = false; //IE still opens the select!
                    }
                }
            }
        });

        //ajax refresh + tablesorter: pg 4, 6 and 8
        
        /*pg01*/
                /* end of pg01*/

        /*pg02*/
                /* end of pg02*/

        /*pg03*/
                /*end of pg03*/

        /*pg04*/
        
                    /*end of pg04*/

        /*pg05*/
                /*end of pg05*/

        /*pg06*/
                    /*end of pg06*/

        /*pg07*/
                /*end of pg07*/

        /*pg08*/
                    /*end of pg08*/

        /*pg09*/
        /*end of pg09*/

        /*pg10*/
        /*end of pg10*/

        /*submit.php*/
                /*end of submit.php*/

        /* close_account.php */
                /*end of close_account.php*/

        //date dropdowns: pg02, pg05, popup_pg04, popup_pg06, register
        if($('select.date_one_month').length){
            menuObject.getDayMenu("", "", "");
            menuObject.getMonthMenu("", "", "");
            $('form.pg_form, form.reg_form, form.pg_popup').on('change', 'select.date_one_year',
                function(event){
                    menuObject.getMonthMenu("", "", "");
                });
            $('form.pg_form, form.reg_form, form.pg_popup').on('change', 'select.date_one_month',
                function(event){
                    delay(function(){
                        menuObject.getDayMenu("", "", "");
                        //menuObject.getMonthMenu("", "", "");
                    }, 100); //Win8 IE10 requires delay
                });

            $(document).on('change', 'select.date_one_year', function(event){
                var current_value = $(this).find(':selected').val() || '';

                if(current_value == '')
                    $('select.date_one_month').addClass('disabled');
                else
                    $('select.date_one_month').removeClass('disabled');

                if(current_value == '')
                    $('select.date_one_day').addClass('disabled');
            });

            $(document).on('change', 'select.date_one_month', function(event){
                var current_value = $(this).find(':selected').val() || '';

                if(current_value == '')
                    $('select.date_one_day').addClass('disabled');
                else
                    $('select.date_one_day').removeClass('disabled');
            });
        }
        if($('select.date_two_month').length){
            menuObject.getDayMenu2("", "", "");
            menuObject.getMonthMenu2("", "", "");
            $('form.pg_form, form.reg_form, form.pg_popup').on('change', 'select.date_two_year',
                function(event){
                    menuObject.getMonthMenu2("", "", "");
                });
            $('form.pg_form, form.reg_form, form.pg_popup').on('change', 'select.date_two_month',
                function(event){
                    delay(function(){
                        menuObject.getDayMenu2("", "", "");
                        //menuObject.getMonthMenu2("", "", "");
                    }, 100); //Win8 IE10 requires delay
                });

            $(document).on('change', 'select.date_two_year', function(event){
                var current_value = $(this).find(':selected').val() || '';

                if(current_value == '')
                    $('select.date_two_month').addClass('disabled');
                else
                    $('select.date_two_month').removeClass('disabled');

                if(current_value == '')
                    $('select.date_two_day').addClass('disabled');
            });

            $(document).on('change', 'select.date_two_month', function(event){
                var current_value = $(this).find(':selected').val() || '';

                if(current_value == '')
                    $('select.date_two_day').addClass('disabled');
                else
                    $('select.date_two_day').removeClass('disabled');
            });
        }

        
        // pages with file management
        
        var isComplete = false;
        $(document).ajaxStart(function(){
            if(!isComplete)
                $('#loader').show();
         });

        $(document).ajaxStop(function(){
            /* Hyperlinks in the News section to point to a new tab */
            $('div.external').find('a').each(function(){
                $(this).attr('target', '_blank').addClass('standard_link');
                $(this).has('img').addClass('no_hover');
            });

            $('#loader').hide();

            if(!isComplete)
                isComplete = true;
         });

        /* Hyperlinks in the News section to point to a new tab */
        $('div.external').find('a').each(function(){
            $(this).attr('target', '_blank').addClass('standard_link');
            $(this).has('img').addClass('no_hover');
        });

        /* Default */
        if($('#start_year').val() == 'Year'){
            $('#start_month').attr('disabled', 'disabled');
            $('#start_month').val('Month');
        }

        $('#start_year').change(function(){
            var selected_val = ($(this).val());

            if(selected_val == 'Year'){
                $('#start_month').attr('disabled', 'disabled');
                $('#start_month').val('Month');
                $('#start_month').css('color', '#444');
            } else {
                $('#start_month').removeAttr('disabled');
                $('#start_month').css('color', 'black');
            }
        });

        $(document).on('mouseover', 'a.view[href$=".bmp"], a.view[href$=".BMP"],' +
            'a.view[href$=".gif"], a.view[href$=".GIF"],' +
            'a.view[href$=".jpg"], a.view[href$=".JPG"],' +
            'a.view[href$=".jpeg"], a.view[href$=".JPEG"],' +
            'a.view[href$=".png"], a.view[href$=".PNG"]', function(event){
            $(this).qtip({
                style: {
                    classes: 'ui-tooltip-light ui-tooltip-bootstrap',
                    tip: false
                },
                overwrite: false,
                suppress: false,
                position: {
                    my: 'bottom left',
                    at: 'top left',
                    target: $(this),
                    adjust: {
                        x: 0,
                        y: -5
                    }
                },
                content: {
                    text: '<img style="width: 100%;" src="' + $(this).attr('href') + '">'
                },
                hide: {
                    event: 'mouseleave click'
                },
                show: {
                    event: event.type,
                    ready: true
                },
                events: {
                    show: function(event, api){
                        $('*').qtip('hide');
                    }
                }
            }, event);
        });

        
        
        inviewAttach();

         // PGAP
            $.extend($.fn.colorbox.settings, {
                iframe: true,
                fastIframe: false
            });
        

        if($('#navigation').length > 0){
            var side_menu = '#navigation';
            var top_menu = '#content_top_navi';
            if(($('#content_top').width() + 16) >= correctedViewportWidth()) top_menu = '';
            var side_menu_manual_offset_top = 56;

            $(side_menu).mouseenter(function(){
                var transition = '';
                $(this)
                .addClass('mouseover')
                .css({
                    'margin-top': $(this).css('margin-top'),
                    '-webkit-transition': transition,
                    '-moz-transition': transition,
                    '-o-transition': transition,
                    'transition': transition
                })
                .stop();
            }).mouseleave(function(){
                $(this).removeAttr('class');
                sticky_menus(false);
            });

            /* values that DON'T change */
            //top_menu:
            var top_menu_offset = top_menu != '' ? $(top_menu).offset().top : 0;
            var top_menu_height = $(top_menu).height();
            var breadcrumb_offset = $('small.breadcrumb').offset().top - top_menu_height - $('small.breadcrumb').height() + 6;
            //side_menu:
            var content_top_height = $('#content_top').height(); //230px
            var content_footer_height = $('#content_footer').height(); //100px
            var main_body_height = $('#main_body').height();
            var body_height = Math.max($('body').height(), content_top_height + main_body_height + content_footer_height);
            var side_menu_offset = $(side_menu).offset().top;
            var side_menu_offset_with_manual_offset = side_menu_offset - side_menu_manual_offset_top;
            var content_navigation_height = $(side_menu).height();
            var window_height = $(window).height();

            var sticky_menus = function(addDelay){
                /* values that DO change */
                //side_menu:
                if($('#main_body').height() != main_body_height){
                    //update
                    body_height = main_body_height = $('#main_body').height();
                    body_height += content_top_height + content_footer_height;
                }
                var scroll_top = $(window).scrollTop();
                var side_menu_duration = !addDelay || ((scroll_top + window_height) == body_height) ? 0 : 500;
                //if attempting to show full menu
                var margin_top_to_add = scroll_top - side_menu_offset_with_manual_offset;
                    margin_top_to_add = margin_top_to_add > 0 ? margin_top_to_add : 0; //should not be negative!
                var new_body_height = side_menu_offset + margin_top_to_add + content_navigation_height + content_footer_height;
                //if pushing menu down as far as it can go without increasing the overall body height - top of menu will be hidden
                var adjusted_margin_top_to_add = new_body_height > body_height ? body_height - (side_menu_offset + content_navigation_height + content_footer_height) : 0;
                    adjusted_margin_top_to_add = adjusted_margin_top_to_add > 0 ? adjusted_margin_top_to_add : 0; //should not be negative!
                var adjusted_body_height = side_menu_offset + content_navigation_height + adjusted_margin_top_to_add + content_footer_height;

                //pin top menu
                if(scroll_top <= top_menu_offset && $(top_menu).css('position') == 'fixed'){ //hit top
                    var width = 'inherit';

                    if($('.ie7').length > 0){
                        $('#content_top_left').show();
                        $('#content_top_logo').show();
                        width = '';
                    }

                    $('#content_top_navi_left').show(); //welcome message

                    $(top_menu)
                        .css({'width': width, 'position': 'static', 'padding': '12px 35px 0 0', 'background': 'none', 'z-index': '1'})
                        .find('#content_top_navi_right')
                            .css({'marginRight': '0'});

                    if($('div#breadcrumbs_moved').length > 0){
                        $('div#breadcrumbs_moved')
                            .stop()
                            .remove();
                        $('small.breadcrumb')
                            .css({'visibility': ''});
                    }
                } else if(scroll_top > top_menu_offset && $(top_menu).css('position') == 'static'){
                    var width = 'inherit';

                    if($('.ie7').length > 0){
                        $('#content_top_left').hide();
                        $('#content_top_logo').hide();
                        width = '960px';
                    }

                    $('#content_top_navi_left').hide(); //welcome message

                    $(top_menu)
                        .css({'height': '17px', 'width': width, 'position': 'fixed', 'padding': menuTopPaddingTop + 'px 0 ' + menuTopPaddingBottom + 'px 0', 'background': 'transparent url("images/style-sprite-ii.1613389569.png") repeat-y left top', 'z-index': '1000'})
                        .find('#content_top_navi_right')
                            .css({'marginRight': '35px'});
                }

                //add breadcrumbs to pinned top menu
                if(scroll_top >= breadcrumb_offset && $('div#breadcrumbs_moved').length == 0 && $(top_menu).css('position') == 'fixed'){
                    $(top_menu)
                        .append('<div id="breadcrumbs_moved" style="margin-top: -50px; padding-left: 262px;" />')

                    $('div#breadcrumbs_moved')
                        .append($('small.breadcrumb').get(0).outerHTML)
                        .find('small.breadcrumb')
                            .css({'display': 'inline'})
                            .addClass('sticky')
                            .find('span.last')
                                .remove();

                    $('div#breadcrumbs_moved')
                        .filter(function(){ return $.trim($(this).text()) == ''; })
                        .remove();

                    $('small.breadcrumb')
                        .not('.sticky')
                        .css({'visibility': 'hidden'});

                    if(side_menu_duration == 0) //possible [End] key press
                        $('div#breadcrumbs_moved')
                            .css({'marginTop': ''});
                    else
                        $('div#breadcrumbs_moved')
                            .stop()
                            .animate({'marginTop': ''}, 'slow');
                } else if(scroll_top < breadcrumb_offset && $('div#breadcrumbs_moved').length > 0 && $(top_menu).css('position') == 'fixed'){
                    $('small.breadcrumb')
                        .css({'visibility': ''});

                    $('div#breadcrumbs_moved')
                        .stop()
                        .animate({'marginTop': '-50px'}, 'slow', function(){
                            $(this).remove();
                            sticky_menus(true); //call self in case we need to stick
                        });
                }

                //pin side menu
                if(!$(side_menu).hasClass('mouseover')){
                    if(scroll_top <= side_menu_offset_with_manual_offset){ //hit top
                        side_menu_duration = 0; //not used but side_menu_duration would be zero as at top
                        $(side_menu)
                            .stop()
                            .moveIt('');//.animate({'marginTop': ''}, 'slow');
                    } else if(scroll_top > side_menu_offset_with_manual_offset && new_body_height <= body_height){
                        delay(function(){
                            //update values in case of change if side_menu_duration > 0
                            if(side_menu_duration > 0){
                                scroll_top = $(window).scrollTop();
                                margin_top_to_add = scroll_top - side_menu_offset_with_manual_offset;
                                new_body_height = side_menu_offset + content_navigation_height + margin_top_to_add + content_footer_height;
                            }

                            //re-check, only then: do, ignore re-check if side_menu_duration == 0
                            if(side_menu_duration == 0 || (scroll_top > side_menu_offset_with_manual_offset && new_body_height <= body_height))
                                $(side_menu)
                                    .stop()
                                    .moveIt(margin_top_to_add + 'px');//.animate({'marginTop': margin_top_to_add + 'px'}, 'slow');
                        }, side_menu_duration);
                    } else if(scroll_top > side_menu_offset_with_manual_offset && adjusted_body_height <= body_height){
                        side_menu_duration = 0; //not used but side_menu_duration would be zero as this is one scenario where we have hit the bottom
                        $(side_menu)
                            .stop()
                            .moveIt(adjusted_margin_top_to_add + 'px');//.animate({'marginTop': adjusted_margin_top_to_add + 'px'}, 'slow');
                    }
                }
            }

            sticky_menus(false); //onLoad

            $(window).scroll(function(){
                 sticky_menus(true);
            });
        }


        if(!isInputTypeSupported('email')){
            $('input[type="email"]').each(function(){
                $(this).prop('type', 'text');
            });
        }
        });

        $(window).load(function(){
        var date_one_year_page_load_value = $('select.date_one_year').val() || '';
        var date_two_year_page_load_value = $('select.date_two_year').val() || '';

        if(date_one_year_page_load_value == '')
            $('select.date_one_year, select.date_one_month').change();

        if(date_two_year_page_load_value == '')
            $('select.date_two_year, select.date_two_month').change();

            });
        -->
</script>
        </head>
        <body>
            <a href="#main_body" class="skiplink">Skip to main content</a>
                        <div id="container_login">
            
    
<div class="login">
    <div class="login_top">
        <h1>Postgraduate & Online<br>Application Portal Login</h1>
    </div>
    <div class="login_content" id="main_body">
        <p id="login_title">Your University of Aberdeen journey starts here!</p>
        <!--[if IE 7]>
            <div class="ie_cover_7"><p>The Postgraduate & Online Application Portal is optimised for modern web browers, and does not support your version of Internet Explorer.</p><br><p>Please <a href="http://www.google.com/chrome/" class="standard_link">upgrade your web browser</a> to use this service.</p></div>
        <![endif]-->
        <!--[if lt IE 7]>
            <div class="ie_cover_6"><p>The Postgraduate & Online Application Portal is optimised for modern web browers, and does not support your version of Internet Explorer.</p><br><p>Please <a href="http://www.google.com/chrome/" class="standard_link">upgrade your web browser</a> to use this service.</p></div>
        <![endif]-->
                <p class="registration-link" id="message"><strong>First time applicant?</strong> <a href="register.php" class="standard_link">Register an Account</a></p><br>
                <p id="reg_message" ><strong>Already registered?</strong> Log in to your account below</p>
                <form action="" method="post" class="login_form">
            <div class="form_label">
                <label for="username">Email Address: </label>
            </div>
            <div class="form_input">
                <input class="input_field" type="email" id="username" name="username" size="35" maxlength="255" value="">
            </div>
            <div class="clear"></div>
            <div class="form_label">
                <label for="password">Password: </label>
            </div>
            <div class="form_input">
                <input class="input_field" type="password" id="password" name="password" size="35" maxlength="25" value="">
                <span class="forgot_password"><a href="forgot_password.php" class="standard_link" tabindex="-1">forgot password?</a></span>
            </div>
            <div class="clear"></div>
            <input type="hidden" name="token" value="47f689efa79f70ee177881df6f5c86aa58baef2d">
            <div id="login_button">
                <input onclick="javascript: $('div form').not('.uploadForm').submit();" type="submit" class="submit_button minimal" value="LOG IN">            </div>
        </form>
            </div>
    <div class="login_bottom">
                <span>
            <a href="login_help.php" class="standard_link" title="Help (Opens in a new tab)" target="_blank">Help</a>
        </span>
    </div>
</div><!-- .login -->
                    <footer id="content_footer">
            <div class="left">
                <p>
                    &copy; 2022 University of Aberdeen.&nbsp;
                    <a href="http://www.abdn.ac.uk/about/our-website/accessibility.php" target="_blank" class="standard_link" title="Accessibility (Opens in a new tab)">Accessibility</a> &middot;
                    <a href="http://www.abdn.ac.uk/about/our-website/privacy.php" target="_blank" class="standard_link" title="Privacy Statement (Opens in a new tab)">Privacy Statement</a> &middot;
                    <a href="http://www.abdn.ac.uk/about/our-website/cookies.php" target="_blank" class="standard_link" title="Cookies (Opens in a new tab)">Cookies</a>
                </p>
            </div>
                    </footer>
    </div>
    <div class="noscript compat-msg hidden no-show">
        <p>
            It looks like you have enabled Internet Explorer Compatibility View. This site works best if you turn this off. <a href="http://windows.microsoft.com/en-us/internet-explorer/use-compatibility-view#ie=ie-8" class="standard_link white" target="_blank" title="Fix site display problems with Compatibility View (Opens in a new tab)">Learn how to do this</a>
        </p>
    </div>
    <noscript>
        <div class="noscript">
            The Postgraduate & Online Application Portal requires JavaScript to function correctly.
        </div>
        <style>
            .compat-msg,.registration-link{display:none}
        </style>
    </noscript>
</body>
</html>
