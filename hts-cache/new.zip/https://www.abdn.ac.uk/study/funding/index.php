<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Scholarships | Study Here | The University of Aberdeen</title>
    <!-- Page ID : 3146 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
    <style>
        #futr-webchat-callout {
            background-color: #f4c900 !important;
            box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%) !important;
        }

        #futr-webchat-callout-explainer {
            font-size: 0.85em !important;
            opacity: 0.8 !important;
            margin-top: 1px !important;
        }

        #futr-roundel-closed > #roundel-logo {
            display: none;
        }

        #futr-roundel-closed > #roundel-custom-icon {
            font-weight: 400;
            font-family: 'Font Awesome 5 Pro';
            font-size: 20pt;
            color: #fff;
        }

        #futr-roundel-closed > #roundel-custom-icon::before {
            content: "\f086";
        }
    </style>
    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/forms.css" media="screen">
                    
                    <link rel="stylesheet" href="/funding/site/css/funding.css" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/study/" class="section_head_text">
                    Study Here                </a>
                <a href="https://www.abdn.ac.uk/study/enquire-now/" id="enquire_link" class="header_button_link">
Enquire Now <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a>            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="Study Here navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/study/undergraduate/index.php">Undergraduate</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-taught/index.php">Postgraduate Taught</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-research/index.php">Postgraduate Research</a>
            </li>
            
            <li>
                <a href="/study/online/index.php">Online</a>
            </li>
            
            <li>
                <a href="/study/international/index.php">International</a>
            </li>
            
            <li>
                <a href="/study/funding/index.php" class="current">Scholarships</a>
            </li>
            
            <li>
                <a href="/study/student-life/index.php">Student Life</a>
            </li>
            
            <li>
                <a href="/study/open-days.php">Open Days and Events</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Scholarships</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/study/">Study Here</a></li>
            
            <li tabindex="0" aria-current="page">Scholarships</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section heading_only">
                        <div class="container">
                    
                        <div class="h1">Scholarships</div>
                        
                        </div>
                    </div>
                    <div class="text_content">
    <p>Use the form below to search for all types of funding sources to assist with financing either your Undergraduate or Postgraduate study. You'll find information on bursaries, scholarships, PhD vacancies and external sources of funding relevant to you.</p>
    <div id="form_container">
        <form id="form" method="get" action="search/">
            <fieldset>
                <legend>Search the Database</legend>
                <div class="form_label">
                    <label for="ug">Study Level</label>
                </div>

                <div class="form_field">
                    <input type="radio" name="level" id="ug" value="ug" >
                    <label for="ug">Undergraduate</label><br>

                    <div id="ugrad_years_container">
                        <input type="radio" id="ug_all" name="ugrad_year" value="all" >
                        <label for="ug_all">All Years</label>
                        <br>
                        <input type="radio" id="entrance" name="ugrad_year" value="entrance" >
                        <label for="entrance">Entrance</label>
                        <br>
                        <input type="radio" id="year1" name="ugrad_year" value="year1" >
                        <label for="year1">Year 1</label>
                        <br>
                        <input type="radio" id="year2" name="ugrad_year" value="year2" >
                        <label for="year2">Year 2</label>
                        <br>
                        <input type="radio" id="year3" name="ugrad_year" value="year3" >
                        <label for="year3">Year 3</label>
                        <br>
                        <input type="radio" id="year4" name="ugrad_year" value="year4" >
                        <label for="year4">Year 4</label>
                        <br>
                        <input type="radio" id="year5" name="ugrad_year" value="year5" >
                        <label for="year5">Year 5</label>
                    </div>

                    <input type="radio" id="pg_taught" name="level" value="tpg" >
                    <label for="pg_taught">Postgraduate Taught</label>
                    <br>
                    <input type="radio" id="pg_research" name="level" value="rpg" >
                    <label for="pg_research">Postgraduate Research</label>
                </div>

                <div class="form_label">
                    <label for="country">Nationality</label>
                </div>
                <div class="form_field">
                    <select id="country" name="country" class="search_dropdown medium_field">
                        <option value="all"> - Select Country - </option>
                        <option value="all" >All Countries</option>
                        
                            <option value="1">Afghanistan</option>
                            
                            <option value="244">Aland Islands</option>
                            
                            <option value="2">Albania</option>
                            
                            <option value="3">Algeria</option>
                            
                            <option value="4">American Samoa</option>
                            
                            <option value="5">Andorra</option>
                            
                            <option value="6">Angola</option>
                            
                            <option value="7">Anguilla</option>
                            
                            <option value="8">Antarctica</option>
                            
                            <option value="9">Antigua and Barbuda</option>
                            
                            <option value="10">Argentina</option>
                            
                            <option value="11">Armenia</option>
                            
                            <option value="12">Aruba</option>
                            
                            <option value="13">Australia</option>
                            
                            <option value="14">Austria</option>
                            
                            <option value="15">Azerbaijan</option>
                            
                            <option value="16">Bahamas</option>
                            
                            <option value="17">Bahrain</option>
                            
                            <option value="18">Bangladesh</option>
                            
                            <option value="19">Barbados</option>
                            
                            <option value="20">Belarus</option>
                            
                            <option value="21">Belgium</option>
                            
                            <option value="22">Belize</option>
                            
                            <option value="23">Benin</option>
                            
                            <option value="24">Bermuda</option>
                            
                            <option value="25">Bhutan</option>
                            
                            <option value="26">Bolivia</option>
                            
                            <option value="245">Bonaire, Sint Eustatius and Saba</option>
                            
                            <option value="27">Bosnia and Herzegovina</option>
                            
                            <option value="28">Botswana</option>
                            
                            <option value="29">Bouvet Island</option>
                            
                            <option value="30">Brazil</option>
                            
                            <option value="31">British Indian Ocean Territory</option>
                            
                            <option value="32">Brunei Darussalam</option>
                            
                            <option value="33">Bulgaria</option>
                            
                            <option value="34">Burkina Faso</option>
                            
                            <option value="35">Burundi</option>
                            
                            <option value="36">Cambodia</option>
                            
                            <option value="37">Cameroon</option>
                            
                            <option value="38">Canada</option>
                            
                            <option value="39">Cape Verde</option>
                            
                            <option value="40">Cayman Islands</option>
                            
                            <option value="41">Central African Republic</option>
                            
                            <option value="42">Chad</option>
                            
                            <option value="43">Chile</option>
                            
                            <option value="44">China (People’s Republic of)</option>
                            
                            <option value="45">Christmas Island</option>
                            
                            <option value="46">Cocos (Keeling) Islands</option>
                            
                            <option value="47">Colombia</option>
                            
                            <option value="48">Comoros</option>
                            
                            <option value="49">Congo (Zaire)</option>
                            
                            <option value="50">Congo, Republic of</option>
                            
                            <option value="51">Cook Islands</option>
                            
                            <option value="52">Costa Rica</option>
                            
                            <option value="53">Cote d'Ivoire</option>
                            
                            <option value="54">Croatia</option>
                            
                            <option value="55">Cuba</option>
                            
                            <option value="246">Curacao</option>
                            
                            <option value="56">Cyprus</option>
                            
                            <option value="57">Czech Republic</option>
                            
                            <option value="58">Denmark</option>
                            
                            <option value="59">Djibouti</option>
                            
                            <option value="60">Dominica</option>
                            
                            <option value="61">Dominican Republic</option>
                            
                            <option value="63">Ecuador</option>
                            
                            <option value="64">Egypt, Arab Republic</option>
                            
                            <option value="65">El Salvador</option>
                            
                            <option value="66">Equatorial Guinea</option>
                            
                            <option value="67">Eritrea</option>
                            
                            <option value="68">Estonia</option>
                            
                            <option value="205">Eswatini</option>
                            
                            <option value="69">Ethiopia</option>
                            
                            <option value="70">Falkland Islands (Malvinas)</option>
                            
                            <option value="71">Faroe Islands</option>
                            
                            <option value="72">Fiji</option>
                            
                            <option value="73">Finland</option>
                            
                            <option value="74">France</option>
                            
                            <option value="75">French Guiana</option>
                            
                            <option value="76">French Polynesia</option>
                            
                            <option value="77">French Southern Territories</option>
                            
                            <option value="78">Gabon</option>
                            
                            <option value="80">Georgia</option>
                            
                            <option value="81">Germany</option>
                            
                            <option value="82">Ghana</option>
                            
                            <option value="83">Gibraltar</option>
                            
                            <option value="84">Greece</option>
                            
                            <option value="85">Greenland</option>
                            
                            <option value="86">Grenada</option>
                            
                            <option value="87">Guadeloupe</option>
                            
                            <option value="88">Guam</option>
                            
                            <option value="89">Guatemala</option>
                            
                            <option value="247">Guernsey</option>
                            
                            <option value="90">Guinea</option>
                            
                            <option value="91">Guinea-Bissau</option>
                            
                            <option value="92">Guyana</option>
                            
                            <option value="93">Haiti</option>
                            
                            <option value="94">Heard Island and Mcdonald</option>
                            
                            <option value="95">Holy See (Vatican City State)</option>
                            
                            <option value="96">Honduras</option>
                            
                            <option value="97">Hong Kong</option>
                            
                            <option value="98">Hungary</option>
                            
                            <option value="99">Iceland</option>
                            
                            <option value="100">India</option>
                            
                            <option value="101">Indonesia</option>
                            
                            <option value="102">Iran</option>
                            
                            <option value="103">Iraq</option>
                            
                            <option value="104">Ireland</option>
                            
                            <option value="248">Isle of Man</option>
                            
                            <option value="105">Israel</option>
                            
                            <option value="106">Italy</option>
                            
                            <option value="107">Ivory Coast</option>
                            
                            <option value="108">Jamaica</option>
                            
                            <option value="109">Japan</option>
                            
                            <option value="249">Jersey</option>
                            
                            <option value="110">Jordan</option>
                            
                            <option value="111">Kazakhstan</option>
                            
                            <option value="112">Kenya</option>
                            
                            <option value="113">Kiribati</option>
                            
                            <option value="114">Korea, Democratic People's Republic of</option>
                            
                            <option value="116">Kuwait</option>
                            
                            <option value="117">Kyrgyzstan</option>
                            
                            <option value="118">Laos</option>
                            
                            <option value="119">Latvia</option>
                            
                            <option value="120">Lebanon</option>
                            
                            <option value="121">Lesotho</option>
                            
                            <option value="122">Liberia</option>
                            
                            <option value="123">Libya</option>
                            
                            <option value="124">Liechtenstein</option>
                            
                            <option value="125">Lithuania</option>
                            
                            <option value="126">Luxembourg</option>
                            
                            <option value="127">Macao</option>
                            
                            <option value="128">Macedonia</option>
                            
                            <option value="129">Madagascar</option>
                            
                            <option value="130">Malawi</option>
                            
                            <option value="131">Malaysia</option>
                            
                            <option value="132">Maldives</option>
                            
                            <option value="133">Mali</option>
                            
                            <option value="134">Malta</option>
                            
                            <option value="135">Marshall Islands</option>
                            
                            <option value="136">Martinique</option>
                            
                            <option value="137">Mauritania</option>
                            
                            <option value="138">Mauritius</option>
                            
                            <option value="139">Mayotte</option>
                            
                            <option value="140">Mexico</option>
                            
                            <option value="141">Micronesia</option>
                            
                            <option value="142">Moldova</option>
                            
                            <option value="143">Monaco</option>
                            
                            <option value="144">Mongolia</option>
                            
                            <option value="250">Montenegro</option>
                            
                            <option value="145">Montserrat</option>
                            
                            <option value="146">Morocco</option>
                            
                            <option value="147">Mozambique</option>
                            
                            <option value="148">Myanmar</option>
                            
                            <option value="149">Namibia</option>
                            
                            <option value="150">Nauru</option>
                            
                            <option value="151">Nepal</option>
                            
                            <option value="152">Netherlands</option>
                            
                            <option value="153">Netherlands Antilles</option>
                            
                            <option value="154">New Caledonia</option>
                            
                            <option value="155">New Zealand</option>
                            
                            <option value="156">Nicaragua</option>
                            
                            <option value="157">Niger</option>
                            
                            <option value="158">Nigeria</option>
                            
                            <option value="159">Niue</option>
                            
                            <option value="160">Norfolk Island</option>
                            
                            <option value="161">Northern Mariana Islands</option>
                            
                            <option value="162">Norway</option>
                            
                            <option value="163">Oman</option>
                            
                            <option value="164">Pakistan</option>
                            
                            <option value="165">Palau</option>
                            
                            <option value="166">Palestinian Territories</option>
                            
                            <option value="167">Panama</option>
                            
                            <option value="168">Papua New Guinea</option>
                            
                            <option value="169">Paraguay</option>
                            
                            <option value="170">Peru</option>
                            
                            <option value="171">Philippines</option>
                            
                            <option value="172">Pitcairn</option>
                            
                            <option value="173">Poland</option>
                            
                            <option value="174">Portugal</option>
                            
                            <option value="175">Puerto Rico</option>
                            
                            <option value="176">Qatar</option>
                            
                            <option value="177">Reunion</option>
                            
                            <option value="178">Romania</option>
                            
                            <option value="179">Russian Federation
</option>
                            
                            <option value="180">Rwanda</option>
                            
                            <option value="251">Saint Barthelemy</option>
                            
                            <option value="181">Saint Helena</option>
                            
                            <option value="182">Saint Kitts and Nevis</option>
                            
                            <option value="183">Saint Lucia</option>
                            
                            <option value="252">Saint Martin</option>
                            
                            <option value="184">Saint Pierre and Miquelon</option>
                            
                            <option value="185">Saint Vincent and the Grenadines</option>
                            
                            <option value="186">Samoa</option>
                            
                            <option value="187">San Marino</option>
                            
                            <option value="188">Sao Tome and Principe</option>
                            
                            <option value="189">Saudi Arabia</option>
                            
                            <option value="190">Senegal</option>
                            
                            <option value="253">Serbia</option>
                            
                            <option value="191">Seychelles</option>
                            
                            <option value="192">Sierra Leone</option>
                            
                            <option value="193">Singapore</option>
                            
                            <option value="254">Sint Maarten</option>
                            
                            <option value="194">Slovakia</option>
                            
                            <option value="195">Slovenia</option>
                            
                            <option value="196">Solomon Islands</option>
                            
                            <option value="197">Somalia</option>
                            
                            <option value="198">South Africa</option>
                            
                            <option value="199">South Georgia and the South Sandwich Islands</option>
                            
                            <option value="115">South Korea</option>
                            
                            <option value="242">South Sudan</option>
                            
                            <option value="200">Spain</option>
                            
                            <option value="201">Sri Lanka</option>
                            
                            <option value="202">Sudan</option>
                            
                            <option value="203">Suriname</option>
                            
                            <option value="204">Svalbard and Jan Mayen</option>
                            
                            <option value="206">Sweden</option>
                            
                            <option value="207">Switzerland</option>
                            
                            <option value="208">Syria</option>
                            
                            <option value="209">Taiwan</option>
                            
                            <option value="210">Tajikistan</option>
                            
                            <option value="211">Tanzania</option>
                            
                            <option value="212">Thailand</option>
                            
                            <option value="79">The Gambia</option>
                            
                            <option value="62">Timor-Leste</option>
                            
                            <option value="213">Togo</option>
                            
                            <option value="214">Tokelau</option>
                            
                            <option value="215">Tonga</option>
                            
                            <option value="216">Trinidad and Tobago</option>
                            
                            <option value="217">Tunisia</option>
                            
                            <option value="218">Turkey</option>
                            
                            <option value="219">Turkmenistan</option>
                            
                            <option value="220">Turks and Caicos Islands</option>
                            
                            <option value="221">Tuvalu</option>
                            
                            <option value="222">Uganda</option>
                            
                            <option value="223">Ukraine</option>
                            
                            <option value="224">United Arab Emirates</option>
                            
                            <option value="225">United Kingdom</option>
                            
                            <option value="226">United States</option>
                            
                            <option value="227">United States Minor Outlying Islands</option>
                            
                            <option value="228">Uruguay</option>
                            
                            <option value="229">Uzbekistan</option>
                            
                            <option value="230">Vanuatu</option>
                            
                            <option value="231">Venezuela</option>
                            
                            <option value="232">Vietnam</option>
                            
                            <option value="233">Virgin Islands, British</option>
                            
                            <option value="234">Virgin Islands, U.S.</option>
                            
                            <option value="235">Wallis and Futuna</option>
                            
                            <option value="255">Western Sahara</option>
                            
                            <option value="236">Western Samoa</option>
                            
                            <option value="237">Yemen</option>
                            
                            <option value="243">Yemen Republic</option>
                            
                            <option value="239">Zambia</option>
                            
                            <option value="240">Zanzibar</option>
                            
                            <option value="241">Zimbabwe</option>
                                                </select>
                </div>
                <div class="form_label">
                    <label for="subject">Subject</label>
                </div>
                <div class="form_field">
                    <select id="subject" name="subject" class="search_dropdown medium_field">
                        <option value="all"> - Select Subject - </option>
                        <option value="all" >All Subjects</option>
                        
                            <option value="1">Accountancy</option>
                            
                            <option value="183">Advanced Chemical Engineering</option>
                            
                            <option value="195">Agricultural Sciences</option>
                            
                            <option value="119">Animal Behaviour</option>
                            
                            <option value="189">Animal Science</option>
                            
                            <option value="2">Anthropology</option>
                            
                            <option value="120">Applied Health Sciences</option>
                            
                            <option value="105">Archaeology</option>
                            
                            <option value="198">Art History</option>
                            
                            <option value="177">Artificial Intelligence</option>
                            
                            <option value="121">Behavioural Biology</option>
                            
                            <option value="122">Behavioural Studies</option>
                            
                            <option value="123">Biochemistry</option>
                            
                            <option value="186">Bioinformatics</option>
                            
                            <option value="124">Biological and Environmental Sciences</option>
                            
                            <option value="3">Biological Sciences</option>
                            
                            <option value="125">Biology</option>
                            
                            <option value="5">Biomedical Sciences</option>
                            
                            <option value="190">Biophysics</option>
                            
                            <option value="126">Biotechnology</option>
                            
                            <option value="97">Business Management</option>
                            
                            <option value="174">Cardiovascular Science and Diabetes</option>
                            
                            <option value="193">Cell Biology / Development</option>
                            
                            <option value="7">Celtic Studies</option>
                            
                            <option value="127">Chemical Engineering</option>
                            
                            <option value="15">Chemistry</option>
                            
                            <option value="130">Civil Engineering</option>
                            
                            <option value="129">Computing</option>
                            
                            <option value="17">Computing Science</option>
                            
                            <option value="132">Conservation Biology</option>
                            
                            <option value="199">Creative Writing</option>
                            
                            <option value="200">Cultural Studies</option>
                            
                            <option value="131">Dentistry</option>
                            
                            <option value="19">Divinity</option>
                            
                            <option value="134">Ecology</option>
                            
                            <option value="202">Economic and Social History</option>
                            
                            <option value="20">Economics</option>
                            
                            <option value="21">Education</option>
                            
                            <option value="133">Electrical and Electronic Engineering</option>
                            
                            <option value="22">Engineering</option>
                            
                            <option value="135">English</option>
                            
                            <option value="23">English, Film and Visual Culture and Linguistics</option>
                            
                            <option value="80">Environmental Humanities</option>
                            
                            <option value="171">Environmental Partnership Management</option>
                            
                            <option value="24">Environmental Science</option>
                            
                            <option value="13">European Labour Market Research</option>
                            
                            <option value="187">Evolution</option>
                            
                            <option value="137">Exercise and Health Science</option>
                            
                            <option value="78">Film and Visual Culture</option>
                            
                            <option value="25">Finance</option>
                            
                            <option value="140">Forest Sciences</option>
                            
                            <option value="139">Forestry</option>
                            
                            <option value="26">French</option>
                            
                            <option value="142">Gaelic Studies</option>
                            
                            <option value="144">Genetics</option>
                            
                            <option value="143">Geography</option>
                            
                            <option value="28">Geography and Environment</option>
                            
                            <option value="146">Geology</option>
                            
                            <option value="29">Geology and Petroleum Geology</option>
                            
                            <option value="182">Geophysics</option>
                            
                            <option value="30">German</option>
                            
                            <option value="82">Gynaecology</option>
                            
                            <option value="197">Health Data Science</option>
                            
                            <option value="32">Hispanic Studies</option>
                            
                            <option value="33">History</option>
                            
                            <option value="34">History of Art</option>
                            
                            <option value="179">Human Nutrition</option>
                            
                            <option value="147">Immunology</option>
                            
                            <option value="175">Industrial Biotechnology</option>
                            
                            <option value="150">Information Systems</option>
                            
                            <option value="185">Integrated Petroleum Geoscience</option>
                            
                            <option value="201">International Development, Diplomacy and International Relations</option>
                            
                            <option value="92">Language and Linguistics</option>
                            
                            <option value="149">Languages and Literature of Scotland</option>
                            
                            <option value="37">Law</option>
                            
                            <option value="152">Legal Studies</option>
                            
                            <option value="38">Management Studies</option>
                            
                            <option value="158">Marine Biology</option>
                            
                            <option value="39">Mathematical Sciences</option>
                            
                            <option value="153">Mathematics</option>
                            
                            <option value="156">Mechanical Engineering</option>
                            
                            <option value="178">Medical Imaging</option>
                            
                            <option value="155">Medical Sciences</option>
                            
                            <option value="41">Medicine</option>
                            
                            <option value="40">Microbiology</option>
                            
                            <option value="88">Modern Thought</option>
                            
                            <option value="43">Molecular Biology</option>
                            
                            <option value="172">Molecular Medicine</option>
                            
                            <option value="181">Museum Studies</option>
                            
                            <option value="44">Music</option>
                            
                            <option value="157">Natural Philosophy</option>
                            
                            <option value="160">Neuroscience with Psychology</option>
                            
                            <option value="191">Neuroscience/Neurology</option>
                            
                            <option value="162">Nutrition and Health</option>
                            
                            <option value="194">Obstetrics, Gynaecology and Reproduction</option>
                            
                            <option value="196">Oncology</option>
                            
                            <option value="188">Parasitology</option>
                            
                            <option value="170">Petroleum Data Management</option>
                            
                            <option value="161">Petroleum Engineering</option>
                            
                            <option value="164">Pharmacology</option>
                            
                            <option value="48">Philosophy</option>
                            
                            <option value="49">Physics</option>
                            
                            <option value="163">Physiology</option>
                            
                            <option value="166">Plant and Soil Science</option>
                            
                            <option value="50">Politics and International Relations</option>
                            
                            <option value="52">Psychology</option>
                            
                            <option value="192">Psychology and Psychiatry</option>
                            
                            <option value="176">Public Health</option>
                            
                            <option value="51">Real Estate</option>
                            
                            <option value="77">Religious Studies</option>
                            
                            <option value="173">Reproductive and Developmental Biology</option>
                            
                            <option value="180">Safety</option>
                            
                            <option value="184">Safety and Reliability Engineering for Oil and Gas</option>
                            
                            <option value="108">Scandinavian Studies</option>
                            
                            <option value="85">Scottish Studies</option>
                            
                            <option value="56">Sociology</option>
                            
                            <option value="9">Spirituality, Health and Disability</option>
                            
                            <option value="94">Sports and Exercise Science</option>
                            
                            <option value="118">Theology</option>
                            
                            <option value="169">Zoology</option>
                                                </select>
                </div>
            </fieldset>
            <button type="submit" class="submit">Search</button>
        </form>
    </div>
</div>

<script>
    /**
     * function to check if undergraduate is the selected level of study, and
     * display or hide the years checkboxes as required
     */
    function checkLevel() {
        // hide the year checkboxes by default
        document.getElementById('ugrad_years_container').className = 'offscreen';
        if (document.getElementById('ug').checked) {
            document.getElementById('ugrad_years_container').className = '';
                            document.querySelector('input[name=ugrad_year][value=all]').checked = true;
                        } else {
            var upgrad_years = document.querySelectorAll('input[name=ugrad_year]');
            if (upgrad_years.length) {
                for (var i = 0, m = upgrad_years.length; i < m; i++) {
                    upgrad_years[i].checked = false;
                }
            }
        }
    }

    // progressively enhance level options
    if ('querySelector' in document && 'addEventListener' in window) {
        var level_options = document.querySelectorAll('input[name=level]');
        if (level_options.length) {
            for (var i = 0, m = level_options.length; i < m; i++) {
                level_options[i].addEventListener('click', checkLevel);
            }
        }
    }

    checkLevel();
</script>
            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/study/index.php">Study Here</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/study/undergraduate/index.php">Undergraduate</a></li>
                
                <li><a href="/study/postgraduate-taught/index.php">Postgraduate Taught</a></li>
                
                <li><a href="/study/postgraduate-research/index.php">Postgraduate Research</a></li>
                
                <li><a href="/study/online/index.php">Online</a></li>
                
                <li><a href="/study/international/index.php">International</a></li>
                
                <li><a href="/study/funding/index.php" class="current" aria-current="page">Scholarships</a></li>
                
                <li><a href="/study/student-life/index.php">Student Life</a></li>
                
                <li><a href="/study/open-days.php">Open Days and Events</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/study/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

    <script src="https://assets.app.futr.ai/webchat/futrwebchat.js" async></script>
    <script>
        window.futrWebchatSettings = [
            "n51ABtk8MqJ2co59TDT86z", {
                calloutLabel: "University of Aberdeen",
                calloutTitle: "Chat with us!",
                calloutExplainer: ""
            }
        ];
    </script>
    
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
