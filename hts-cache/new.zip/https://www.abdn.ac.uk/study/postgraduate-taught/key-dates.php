<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Key Dates | Study Here | The University of Aberdeen</title>
    <!-- Page ID : 6046 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
    <style>
        #futr-webchat-callout {
            background-color: #f4c900 !important;
            box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%) !important;
        }

        #futr-webchat-callout-explainer {
            font-size: 0.85em !important;
            opacity: 0.8 !important;
            margin-top: 1px !important;
        }

        #futr-roundel-closed > #roundel-logo {
            display: none;
        }

        #futr-roundel-closed > #roundel-custom-icon {
            font-weight: 400;
            font-family: 'Font Awesome 5 Pro';
            font-size: 20pt;
            color: #fff;
        }

        #futr-roundel-closed > #roundel-custom-icon::before {
            content: "\f086";
        }
    </style>
    
                    <link rel="stylesheet" href="/global/lib/picnet_table/picnet.table.css" media="screen">
                    
<style>
#key_dates_table_filter_1,
#key_dates_table_filter_2 {
    display: none;
}
</style>
    <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>

                    <script src="/global/lib/picnet_table/picnet.table.filter.min.js"></script>
                    </head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/study/" class="section_head_text">
                    Study Here                </a>
                <a href="https://www.abdn.ac.uk/study/enquire-now/" id="enquire_link" class="header_button_link">
Enquire Now <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a>            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="Study Here navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/study/undergraduate/index.php">Undergraduate</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-taught/index.php" class="current">Postgraduate Taught</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-research/index.php">Postgraduate Research</a>
            </li>
            
            <li>
                <a href="/study/online/index.php">Online</a>
            </li>
            
            <li>
                <a href="/study/international/index.php">International</a>
            </li>
            
            <li>
                <a href="/study/funding/index.php">Scholarships</a>
            </li>
            
            <li>
                <a href="/study/student-life/index.php">Student Life</a>
            </li>
            
            <li>
                <a href="/study/open-days.php">Open Days and Events</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Key Dates</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/study/">Study Here</a></li>
            
            <li><a href="/study/postgraduate-taught/index.php">Postgraduate Taught</a></li>
            
            <li tabindex="0" aria-current="page">Key Dates</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">Key Dates</div>
                        <p><strong>We look forward to welcoming you to the University of Aberdeen in January 2023!</strong></p>

<p>The below key dates are for overseas fees applicants for our postgraduate taught programmes.&nbsp;</p>

<p>Please remember to complete all required steps as soon as possible. Don’t wait until the date listed below to complete a step! If you have any questions about your application, please email <a href="mailto:pgadmissions@abdn.ac.uk">pgadmissions@abdn.ac.uk</a>.</p>
                        </div>
                    </div>
                    <div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Applications">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Applications-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Applications-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Applications-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Applications-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/Applications-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/Applications-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Applications</h2>
                        <p>Applications must be received by <strong>21 October</strong> for <strong>January 2023</strong> entry. &nbsp;</p>

<p>However, please be aware that we currently have very high demand for places, and we cannot guarantee that we are able to consider all applications for a January 2023 start even if they are received before Friday 21 October.</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Accept and Send">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Accept-Send-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Accept-Send-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Accept-Send-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Accept-Send-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/Accept-Send-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/Accept-Send-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Accept and Send</h2>
                        <p>Accept your offer and send all required documents to the Admissions Team&nbsp;<strong>by 16 November 2022.</strong></p>

<p><a href="https://www.abdn.ac.uk/study/international/certificate-of-acceptance-of-studies-cas-2020.php">You can check what documents are required&nbsp;on our CAS page.</a></p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="VISA">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/VISA-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/VISA-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/VISA-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/VISA-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/VISA-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/VISA-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>VISA</h2>
                        <p>You need to <a href="https://www.abdn.ac.uk/students/academic-life/immigration-and-student-visas.php" target="_blank">apply for your visa </a>as soon as possible after receiving your CAS.</p>

<p>Please ensure you are aware of visa processing times in your own country.</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Accommodation">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Accommodation-Key-Dates-450x338px_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Accommodation-Key-Dates-450x338px_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Accommodation-Key-Dates-450x338px_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Accommodation-Key-Dates-450x338px_rdax_450x338.jpg"><source srcset="/img/250x/study/feature-images/Accommodation-Key-Dates-450x338px_rdax_450x338.jpg"><img src="/img/450x/study/feature-images/Accommodation-Key-Dates-450x338px_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Accommodation</h2>
                        <p>You are guaranteed an offer of accommodation in our university-managed residences if you apply for accommodation by <strong>12 December.</strong></p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="IT Set-Up">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/IT-Set-Up-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/IT-Set-Up-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/IT-Set-Up-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/IT-Set-Up-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/IT-Set-Up-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/IT-Set-Up-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>IT Set-Up</h2>
                        <p>Once you have a Student ID you need to set up your IT account and complete multi-factor authentication from <strong>14 December</strong>.</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Start Registration">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Registration-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Registration-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Registration-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Registration-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/Registration-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/Registration-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Start Registration</h2>
                        <p>You need to complete online registration from <strong>23 December.</strong></p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Welcome Week">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Welcome-Week-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Welcome-Week-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Welcome-Week-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Welcome-Week-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/Welcome-Week-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/Welcome-Week-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Welcome Week</h2>
                        <p>Welcome Week starts on <strong>16 January.</strong></p>

<p>Welcome Week&nbsp;is all about helping you settle in and prepare for your academic and non-academic university life.</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Teaching Starts">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Teaching-Starts-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Teaching-Starts-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Teaching-Starts-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Teaching-Starts-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/Teaching-Starts-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/Teaching-Starts-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Teaching Starts</h2>
                        <p>Teaching starts on <strong>23 January.</strong></p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Registration Deadline">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Deadline-640x480px_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Deadline-640x480px_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Deadline-640x480px_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Deadline-640x480px_rdax_450x338.png"><source srcset="/img/250x/study/feature-images/Deadline-640x480px_rdax_450x338.png"><img src="/img/450x/study/feature-images/Deadline-640x480px_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Registration Deadline</h2>
                        <p>For the programmes listed below, the deadline for completing registration is <strong>25 January</strong> OR <strong>30 January</strong>. Please check carefully. For all other programmes the deadline &nbsp;for completing registration is <strong>6 February</strong>.</p>

<p>To complete registration by the deadline you must:</p>

<ul>
	<li>Have carried out the online registration process</li>
	<li>Be in Aberdeen</li>
	<li>Attended an in-person visa check</li>
	<li>Attended any in-person classes for your programme</li>
</ul>

<p>The University will not permit students to begin their studies online and will not permit you to register after the date specified for your programme.<br />
&nbsp;</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>

<div class="section">
    <div class="container">
    <h2 class="optional_heading">Deadline Dates</h2>

<p>The deadline for registration is <strong>6 February 2023</strong>, unless your degree programme appears in the list below:</p>

<table class="filtertable" id="key_dates_table" style="width:100%">
	<thead>
		<tr>
			<th align="left" id="filter-degree">Degree Programme</th>
			<th id="filter-qual">Qualification</th>
			<th id="filter-deadline">Registration Deadline</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>(IBM Pathway) - MBA Top Up</td>
			<td align="center">MBA</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Artificial Intelligence</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Business Administration</td>
			<td align="center">MBA</td>
			<td align="center"><span style="line-height:107%">25 January 2023</span></td>
		</tr>
		<tr>
			<td>Data Science</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Energy Management</td>
			<td align="center">MBA</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Entrepreneurship</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Environmental Science</td>
			<td align="center">MSc</td>
			<td align="center">30 January 2023</td>
		</tr>
		<tr>
			<td>Global Business Communication</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Information Technology</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>International Business Management</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>International Human Resource Management</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>International Relations and Management</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>International Tourism Management</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Marketing Management</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Oil and Gas Engineering</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Oil and Gas Enterprise Management</td>
			<td align="center">MSc</td>
			<td align="center"><span style="line-height:107%">25 January 2023</span></td>
		</tr>
		<tr>
			<td>Petroleum Engineering</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Public Health&nbsp;</td>
			<td align="center">MSc</td>
			<td align="center">25 January 2023</td>
		</tr>
		<tr>
			<td>Strategic Studies and Management</td>
			<td align="center">MSc</td>
			<td align="center"><span style="line-height:107%">25 January 2023</span></td>
		</tr>
		<tr>
			<td>Sustainability Transitions</td>
			<td align="center">MSc</td>
			<td align="center"><span style="line-height:107%">25 January 2023</span></td>
		</tr>
	</tbody>
</table>
    </div>
</div>
            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/study/index.php">Study Here</a></li>
            
            <li><a href="/study/postgraduate-taught/index.php">Postgraduate Taught</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/study/postgraduate-taught/degree-programmes/index.php">Our Degrees</a></li>
                
                <li><a href="/study/postgraduate-taught/apply.php">How to Apply</a></li>
                
                <li><a href="/study/postgraduate-taught/offer-holder-information-3355.php">Offer Holder Information</a></li>
                
                <li><a href="/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                
                <li><a href="/study/postgraduate-taught/january.php">January Programmes</a></li>
                
                <li><a href="/study/postgraduate-taught/part-time.php">Part-time Learning</a></li>
                
                <li><a href="/study/postgraduate-taught/careers-1698.php">Employment</a></li>
                
                <li><a href="/study/postgraduate-taught/considering-options.php">Still considering your options?</a></li>
                
                <li><a href="/study/postgraduate-taught/key-dates.php" class="current" aria-current="page">Key Dates</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/study/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

    <script src="https://assets.app.futr.ai/webchat/futrwebchat.js" async></script>
    <script>
        window.futrWebchatSettings = [
            "n51ABtk8MqJ2co59TDT86z", {
                calloutLabel: "University of Aberdeen",
                calloutTitle: "Chat with us!",
                calloutExplainer: ""
            }
        ];
    </script>
    
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                <script>
$(document).ready(function() {
// Initialise Plugin
// dynamically create the filter type attribute as the text editor will remove from users code
document.getElementById("filter-degree").setAttribute("filter-type", "text");
document.getElementById("filter-deadline").setAttribute("filter-type", "text");

$('#key_dates_table').tableFilter();
$('#key_dates_table_filter_0').attr('placeholder', 'Filter...');
});
</script>    </body>
</html>
