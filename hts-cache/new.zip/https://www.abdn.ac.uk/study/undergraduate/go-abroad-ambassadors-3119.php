<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Go Abroad Ambassadors | Study Here | The University of Aberdeen</title>
    <!-- Page ID : 3119 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
    <style>
        #futr-webchat-callout {
            background-color: #f4c900 !important;
            box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%) !important;
        }

        #futr-webchat-callout-explainer {
            font-size: 0.85em !important;
            opacity: 0.8 !important;
            margin-top: 1px !important;
        }

        #futr-roundel-closed > #roundel-logo {
            display: none;
        }

        #futr-roundel-closed > #roundel-custom-icon {
            font-weight: 400;
            font-family: 'Font Awesome 5 Pro';
            font-size: 20pt;
            color: #fff;
        }

        #futr-roundel-closed > #roundel-custom-icon::before {
            content: "\f086";
        }
    </style>
        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/study/" class="section_head_text">
                    Study Here                </a>
                <a href="https://www.abdn.ac.uk/study/enquire-now/" id="enquire_link" class="header_button_link">
Enquire Now <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a>            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="Study Here navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/study/undergraduate/index.php" class="current">Undergraduate</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-taught/index.php">Postgraduate Taught</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-research/index.php">Postgraduate Research</a>
            </li>
            
            <li>
                <a href="/study/online/index.php">Online</a>
            </li>
            
            <li>
                <a href="/study/international/index.php">International</a>
            </li>
            
            <li>
                <a href="/study/funding/index.php">Scholarships</a>
            </li>
            
            <li>
                <a href="/study/student-life/index.php">Student Life</a>
            </li>
            
            <li>
                <a href="/study/open-days.php">Open Days and Events</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Go Abroad Ambassadors</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/study/">Study Here</a></li>
            
            <li><a href="/study/undergraduate/index.php">Undergraduate</a></li>
            
            <li><a href="/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
            
            <li><a href="/study/undergraduate/engage-with-us-3070.php">Engage with us</a></li>
            
            <li tabindex="0" aria-current="page">Go Abroad Ambassadors</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">Go Abroad Ambassadors</div>
                        <p>Meet our team of Go Abroad Ambassadors, Aberdeen students that have studied or worked abroad, and are keen to share their experiences with you!</p>
                        </div>
                    </div>
                    <div class="section">
    <div class="container">
                <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Theo Williamson">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/tempImagegyMALg_Theodore%20Williamson_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/tempImagegyMALg_Theodore%20Williamson_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/tempImagegyMALg_Theodore%20Williamson_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/tempImagegyMALg_Theodore%20Williamson_rdax_450x338.jpg"><source srcset="/img/250x/study/feature-images/tempImagegyMALg_Theodore%20Williamson_rdax_450x338.jpg"><img src="/img/450x/study/feature-images/tempImagegyMALg_Theodore%20Williamson_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Theo Williamson</h2>
                        <p><a href="mailto:s03tw2@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Theo</a></p>

<p><strong>Theo is our Go Abroad Champion for students in the LGBTQ+ community, students with Physical Disabilities and First Generation students, ask Theo about his experiences abroad.</strong></p>

<p>&nbsp;
<p><strong>Degree</strong>: International Relations and English</p>
</p>

<p><strong>Exchange Programme: </strong>International Exchange</p>

<p><strong>Destination: </strong>University of North Carolina at Wilmington,&nbsp;USA</p>

<p><strong>Why USA?</strong>&nbsp;I chose the USA as my go-abroad destination as it was a country I had always been interested in with my studies in IR and knew I wanted to write my dissertation about the politics there. Although I had never thought to go there as a disabled student, I had so many opportunities thrown my way from conferences to kayaking and travelling to Canada as well as Universal Orlando. I had access to incredible support at both home and abroad, the university I chose was right next to a beach and an airport it was incredibly easy to chill by the beach on a hot day or travel on a long weekend. It has been the best thing I've done in my degree.<span style="line-height:107%"> </span></p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Erin Hodgson">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/staff%20id%202_Erin%20Hodgson_rdax_450x653.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/staff%20id%202_Erin%20Hodgson_rdax_450x653.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/staff%20id%202_Erin%20Hodgson_rdax_450x653.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/staff%20id%202_Erin%20Hodgson_rdax_450x653.png"><source srcset="/img/250x/study/feature-images/staff%20id%202_Erin%20Hodgson_rdax_450x653.png"><img src="/img/450x/study/feature-images/staff%20id%202_Erin%20Hodgson_rdax_450x653.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Erin Hodgson</h2>
                        <p><a href="mailto:u06eh20@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Erin</a></p>

<p><strong>Degree</strong>: Business and Politics</p>

<p><strong>Exchange Programme</strong>: Internation exchange</p>

<p><strong>Destination</strong>: University of North Carolina at Wilmington, USA</p>

<p><strong>Why I went abroad</strong>:&nbsp;Hi, I'm Erin and I'm a third year studying business and politics here in Aberdeen. I love travelling, having spent spent 6 months in South India as a volunteer primary school teacher helping a local community. The experience was cut short with the pandemic but the memories remain. Last year I was fortunate enough to have the opportunity to complete my second year on exchange at the university of North Carolina Wilmington. Studying and living abroad gives you a mix of experiences and I have made some lifelong friends on the way. Travel (without the study or work) is a big part of my future life plans so when we meet I would love to hear if you have similar plans, where you have been and where you would love to visit:)</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Daniel Grant">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/switzerland%20profile%20photo%202_Daniel%20Grant_rdax_450x613.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/switzerland%20profile%20photo%202_Daniel%20Grant_rdax_450x613.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/switzerland%20profile%20photo%202_Daniel%20Grant_rdax_450x613.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/switzerland%20profile%20photo%202_Daniel%20Grant_rdax_450x613.jpg"><source srcset="/img/250x/study/feature-images/switzerland%20profile%20photo%202_Daniel%20Grant_rdax_450x613.jpg"><img src="/img/450x/study/feature-images/switzerland%20profile%20photo%202_Daniel%20Grant_rdax_450x613.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Daniel Grant</h2>
                        <p><a href="mailto:u06dg19@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Daniel</a>&nbsp;</p>

<p><strong>Degree</strong>:&nbsp;Geography</p>

<p><strong>Exchange Programme</strong>:&nbsp;SEMP (Swiss European Mobility Programme)</p>

<p><strong>Destination</strong>:&nbsp;University of Zurich, Switzerland</p>

<p><strong>My Advice:</strong> Do as many things as you can while you are on exchange! Although you are still at university, you will only get this experience once in your life, so make the most of it and treat your exchange as a semi-holiday. Also, save as much money as you can before you go - going on exchange, especially to somewhere like Switzerland, can be expensive but worth every penny.</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Alba Cristobal-Andaluz">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Alba%20Cristoba_rdax_450x552.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Alba%20Cristoba_rdax_450x552.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Alba%20Cristoba_rdax_450x552.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Alba%20Cristoba_rdax_450x552.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Alba%20Cristoba_rdax_450x552.jpg"><img src="/img/450x/study/feature-images/GAA%20Alba%20Cristoba_rdax_450x552.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Alba Cristobal-Andaluz</h2>
                        <p><a href="mailto:u09ac18@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Alba</a></p>

<p><strong>Degree</strong>: MA French &amp; German</p>

<p><strong>Exchange Programme</strong>:&nbsp;Erasmus Study</p>

<p><strong>Destination</strong>:&nbsp;Universit&eacute; Grenoble Alpes, France &amp; Universit&auml;t Wien, Austria&nbsp;</p>

<p><strong>My Exchange Experience:</strong> Before Austria, I had never traveled to a German-speaking country and thought it would be too challenging for me. In the beginning, it was hard, but after making an effort to speak and listen to German every day in the streets and shops, I felt motivated to keep going. Among the Erasmus people that I met, many of them were German, this means that you can find people that will help you and be patient with you when you're trying to learn the language. I can't wait to see them again!! My tip would be to enjoy every minute you are in exchange and value the new people, opportunities and experiences that come around - you won't regret it!!</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Johanna Alt">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Johanna%20Alt_rdax_450x540.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Johanna%20Alt_rdax_450x540.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Johanna%20Alt_rdax_450x540.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Johanna%20Alt_rdax_450x540.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Johanna%20Alt_rdax_450x540.jpg"><img src="/img/450x/study/feature-images/GAA%20Johanna%20Alt_rdax_450x540.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Johanna Alt</h2>
                        <p><a href="mailto:johanna.alt@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Johanna</a></p>

<p><strong>Degree</strong>: English &amp; Philosophy&nbsp;</p>

<p><strong>Exchange Programme</strong>: International Exchange&nbsp;</p>

<p><span style="display:inline !important; text-align:left; white-space:pre-wrap"><strong>Destination</strong>: </span><span style="text-decoration-thickness:initial">University of British Columbia (Vancouver campus),&nbsp;</span><span style="display:inline !important; text-align:left; white-space:pre-wrap">Canada </span></p>

<p><strong>My top tip:</strong>&nbsp;There are very few good reasons not to travel. The UBC Campus, the Canadian mountains, the people, the sled dogs, the northern lights, and poutine (!) all turned out to be excellent reasons to travel to Canada. Most of the time, you don't know why you should visit a place until you do it - so do it!</p>

<p>&nbsp;</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Tinca Radzichevici">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Ecaterina%20Radzichevi_rdax_450x600.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Ecaterina%20Radzichevi_rdax_450x600.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Ecaterina%20Radzichevi_rdax_450x600.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Ecaterina%20Radzichevi_rdax_450x600.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Ecaterina%20Radzichevi_rdax_450x600.jpg"><img src="/img/450x/study/feature-images/GAA%20Ecaterina%20Radzichevi_rdax_450x600.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Tinca Radzichevici</h2>
                        <p><a href="mailto:u07er20@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Tinca</a></p>

<p><strong>Degree</strong>: BSc Biotechnology (Applied Molecular Biology)</p>

<p><strong>Exchange Programme</strong>: Erasmus+ Traineeship</p>

<p><strong>Destination</strong>: Munich, Germany</p>

<p><strong>My biggest takeaway from the mobility:</strong>&nbsp;You miss all the shots you don't take! Going abroad seems like a long and stressful process (and it definitely is sometimes). However, applying and taking this opportunity pays off significantly in the end. Not only do you boost your CV, but you also make friends and memories that you'll cherish forever. Doing an internship abroad made me more certain about the career I want to follow once I finish my degree. I discovered a lot about myself and my passions, whilst gaining valuable professional experience. Get in touch with me if you want to talk about how to find (and what to do if you get accepted to) an internship in a lab, German work culture, and the best spots in Munich.</p>

<p>&nbsp;</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Silvia Paolucci">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Silvia%20Paolucci%20Profile_photo_rdax_450x391.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Silvia%20Paolucci%20Profile_photo_rdax_450x391.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Silvia%20Paolucci%20Profile_photo_rdax_450x391.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Silvia%20Paolucci%20Profile_photo_rdax_450x391.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Silvia%20Paolucci%20Profile_photo_rdax_450x391.jpg"><img src="/img/450x/study/feature-images/GAA%20Silvia%20Paolucci%20Profile_photo_rdax_450x391.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Silvia Paolucci</h2>
                        <p><a href="mailto:silvia.paolucci@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email&nbsp;Silvia</a></p>

<p><strong>Degree</strong>:&nbsp;Data Science<span style="line-height:107%"> </span></p>

<p><strong>Exchange Programme</strong>: Erasmus&nbsp;&amp; Santander Mobility Award</p>

<p><strong>Destination</strong>:&nbsp;LUISS Guido Carli, Italy&nbsp;and City London University, UK</p>

<p><span style="line-height:107%"><strong>My Advice:</strong> </span>Don’t be afraid of taking new opportunities, this is the only way to improve yourself. Should you need any help, don’t hesitate to ask!</p>

<p><strong>My Top Tip:</strong> Focus on what can go well, rather than thinking about what can go wrong!<span style="line-height:107%"> </span></p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Diana Fakhouriova">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Diana%20Fakhouriova_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Diana%20Fakhouriova_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Diana%20Fakhouriova_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Diana%20Fakhouriova_rdax_450x450.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Diana%20Fakhouriova_rdax_450x450.jpg"><img src="/img/450x/study/feature-images/GAA%20Diana%20Fakhouriova_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Diana Fakhouriova</h2>
                        <p><a href="mailto:u05df20@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Diana</a></p>

<p><strong>Diana is our Go Abroad Champion for students with Learning Difficulties, ask Diana about her experiences abroad.</strong></p>

<p><strong>Degree</strong>:&nbsp;<span style="line-height:107%">Neuroscience With Psychology</span></p>

<p><strong>Exchange Programme:</strong> Erasmus Study&nbsp;</p>

<p><strong>Destination:</strong>&nbsp;<span style="line-height:107%">VU Amsterdam, The Netherlands&nbsp;</span></p>

<p><strong><span style="line-height:107%">About Diana:</span></strong>&nbsp;Diana is a 3rd year Neuroscience student coming back from a year of exchange in the Netherlands. She spent her time in Amsterdam with munching on the Dutch fried delicacies, exploring the city on bike and cooking Arabic/German/fusion food with her international flatmates. When she wasn't working or studying, she travelled Italy, Spain, Germany, Switzerland and France with a heavy backpack and an open mind. Growing up in between cultures, she developed a curiosity for communication and loves dissecting common traits and differences, as well as navigating intercultural contexts. She loves giving advice and exchanging experiences, especially if they vary from her own. Diana feels passionate about the accessibility of education and the umbrella of experiences that come with being in uni. Grappling with navigating academia and social life as a neurodivergent while being a first-generation student and having to make a living for herself, she would love to help others deal with similar challenges and discuss how to protect one's mental health through that. She also looks forward to getting acquainted with the freezing Scottish waters while learning how to kayak!<span style="line-height:107%"> </span></p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Annie Lennam">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Annie%20Lennam_rdax_450x556.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Annie%20Lennam_rdax_450x556.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Annie%20Lennam_rdax_450x556.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Annie%20Lennam_rdax_450x556.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Annie%20Lennam_rdax_450x556.jpg"><img src="/img/450x/study/feature-images/GAA%20Annie%20Lennam_rdax_450x556.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Annie Lennam</h2>
                        <p><a href="mailto:u11al19@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email&nbsp;Annie</a></p>

<p><strong>Degree</strong>:&nbsp;Economics and French</p>

<p><strong>Exchange Programme</strong>:&nbsp;Swiss European Mobility Programme (SEMP) and Erasmus Traineeship</p>

<p><strong>Destination</strong>:&nbsp;&nbsp;Lausanne University, Switzerland and Biarritz, France</p>

<p><strong>Highlights from my time abroad:</strong> Hiking in the Swiss Alps, learning to surf, speaking French every day, running a half marathon, camping in the mountains, watching the sunset on the beach and meeting people from all over the world. Studying at a university in Switzerland and working in a language school in France gave me two completely different but fantastic experiences abroad. It was so interesting seeing the differences in culture in each country and experiencing new things all the time. I did things I never thought I'd be able to do and learnt a lot. Don’t hesitate to get in touch if you have any questions about going abroad!</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Gemma Mcleod">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Gemma%20Mcleod_rdax_450x352.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Gemma%20Mcleod_rdax_450x352.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Gemma%20Mcleod_rdax_450x352.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Gemma%20Mcleod_rdax_450x352.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Gemma%20Mcleod_rdax_450x352.jpg"><img src="/img/450x/study/feature-images/GAA%20Gemma%20Mcleod_rdax_450x352.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Gemma Mcleod</h2>
                        <p><a href="mailto:g.mcleod.19@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Gemma</a></p>

<p><strong>Degree</strong>: Politics and International Relations</p>

<p><strong>Exchange Programme:</strong>&nbsp;International Exchange</p>

<p><strong>Destination</strong>:&nbsp;University of Florida, USA</p>

<p><strong>The Best Things About My Exchange:</strong> Making new friends from all over the world, becoming more confident about travelling by myself, learning from professors with different lived experiences, and, of course, the weather!</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Valentina Menendez Ron">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Valentina%20Menendez%20R_rdax_450x600.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Valentina%20Menendez%20R_rdax_450x600.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Valentina%20Menendez%20R_rdax_450x600.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Valentina%20Menendez%20R_rdax_450x600.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Valentina%20Menendez%20R_rdax_450x600.jpg"><img src="/img/450x/study/feature-images/GAA%20Valentina%20Menendez%20R_rdax_450x600.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Valentina Menendez Ron</h2>
                        <p><a href="mailto:v.menendezron.19@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Valentina</a></p>

<p><strong>Degree</strong>: Law and European legal studies</p>

<p><strong>Exchange Programme</strong>: Erasmus Study</p>

<p><strong>Destination</strong>:&nbsp;Aarhus Universitet</p>

<p><strong>My Advice:</strong> Going abroad is something surreal. It is as if you are living a parallel life from the one in Aberdeen – nobody knows you, so you can reinvent yourself (or not) if you want. And the best thing is that everybody is going through the same thing.</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Ellen Williamson">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Go%20Abroad%20Ambassador%20Ellen%20Williamson%20(1)_rdax_450x599.png"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Go%20Abroad%20Ambassador%20Ellen%20Williamson%20(1)_rdax_450x599.png"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Go%20Abroad%20Ambassador%20Ellen%20Williamson%20(1)_rdax_450x599.png"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Go%20Abroad%20Ambassador%20Ellen%20Williamson%20(1)_rdax_450x599.png"><source srcset="/img/250x/study/feature-images/Go%20Abroad%20Ambassador%20Ellen%20Williamson%20(1)_rdax_450x599.png"><img src="/img/450x/study/feature-images/Go%20Abroad%20Ambassador%20Ellen%20Williamson%20(1)_rdax_450x599.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Ellen Williamson</h2>
                        <p><a href="mailto:ellen.williamson@abdn.ac.uk?subject=Email%20from%20Website">Email Ellen</a></p>

<p><strong>Degeree</strong>: <span style="border-color:windowtext"><span style="line-height:107%">French and Art History</span></span></p>

<p><strong>Exchange Programme:</strong>&nbsp;Erasmus Traineeship</p>

<p><strong>Destination</strong>:&nbsp;<span style="border-color:windowtext"><span style="line-height:107%">Limoges, France </span></span></p>

<p><strong>My takeaways</strong>:&nbsp;The best bit about it is that you will come back feeling that you have achieved something you never thought you could and you will look back at it as being one of the best things you did.&nbsp;</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Megan Johnstone">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Megan%20Johnstone_rdax_450x716.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Megan%20Johnstone_rdax_450x716.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Megan%20Johnstone_rdax_450x716.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Megan%20Johnstone_rdax_450x716.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Megan%20Johnstone_rdax_450x716.jpg"><img src="/img/450x/study/feature-images/GAA%20Megan%20Johnstone_rdax_450x716.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Megan Johnstone</h2>
                        <p><a href="mailto:m.johnstone.20@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Megan</a></p>

<p><strong>Megan is our Go Abroad Champion for students facing Metal Health Challenges, ask Megan about her experiences abroad.</strong></p>

<p><strong>Degree</strong>: Philosophy, Theology and Religion</p>

<p><strong>Exchange Programme:</strong>&nbsp;International Exchange</p>

<p><strong>Destination</strong>:&nbsp;University of the Fraser Valley, British Columbia, Canada</p>

<p><strong>Why did I go on exchange:</strong>&nbsp;I wanted to take part in the go abroad program to experience new things and meet people from all over the world. I chose Canada for the beautiful mountains, glaciers, and lakes and to learn about a different way of life. My go abroad experience has been the highlight of my time at university and whilst studying at UFV I managed to take subjects specific to Canada that I would not have been able to take here, write articles for the university newspaper and work as the volleyball scorekeeper for the Canada West playoffs, all of which are experiences I would not have had without it. When my semester finished I was lucky enough to do a roadtrip through some of the USA and across Canada, starting in BC and ending in Ontario. I am excited to share everything I learned about the go abroad process and the positives of studying abroad with anyone considering taking part in the go abroad program.</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Croy Langlands">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/Croy%20Langlands_rdax_450x685.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/Croy%20Langlands_rdax_450x685.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/Croy%20Langlands_rdax_450x685.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/Croy%20Langlands_rdax_450x685.jpg"><source srcset="/img/250x/study/feature-images/Croy%20Langlands_rdax_450x685.jpg"><img src="/img/450x/study/feature-images/Croy%20Langlands_rdax_450x685.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Croy Langlands</h2>
                        <div class="RD_EditableElement" id="ACE8C60B86894453AED92493AD213031_1">
<p><a href="mailto:c.langlands.19@abdn.ac.uk?subject=Go%20Abroad%20Questions" target="_self">Email Croy</a></p>

<p><strong>Degree</strong>: Geography</p>

<p><strong>Exchange Programme:</strong> Erasmus Study and Traineeship</p>

<p><strong>Destination</strong>:&nbsp;University of Iceland and Traineeship in Malta</p>

<p><strong>Why did I go on exchange:</strong> <span class="--gg-530" data-automation-id="psScoreValue">Hi! Last year during Covid and Brexit and I did a semester abroad in Iceland. It was a great opportunity to connect with likeminded international students, explore a new country, and experience teaching at a different university. I finished my Erasmus with a host of new independence skills, confidence and an eagerness to travel. This year I've just finished an Erasmus Traineeship in Malta, where I worked for a kayak tour company, learning about the tourism industry, culture and protected areas. I enhanced my skills in the work place, particularly my confidence talking with and organising groups of people. If you're interested in doing a European exchange in Iceland or Malta, then I'm more than happy to answer any questions you might have :D</span></p>
</div>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Corina Taggart">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/GAA%20Corina%20Taggart_rdax_450x540.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/GAA%20Corina%20Taggart_rdax_450x540.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/GAA%20Corina%20Taggart_rdax_450x540.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/GAA%20Corina%20Taggart_rdax_450x540.jpg"><source srcset="/img/250x/study/feature-images/GAA%20Corina%20Taggart_rdax_450x540.jpg"><img src="/img/450x/study/feature-images/GAA%20Corina%20Taggart_rdax_450x540.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Corina Taggart</h2>
                        <p><a href="mailto:u07ct19@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Corina</a></p>

<p><strong>Degree</strong>: Economics</p>

<p><strong>Exchange Programme:</strong>&nbsp;International Exchange</p>

<p><strong>Destination</strong>:&nbsp;<span style="text-decoration-thickness:initial">Complutense University Madrid, Spain</span></p>

<p><strong>About me:</strong>&nbsp;I am a fourth year Economics student who studied in Madrid through third year. Besides my studies, I am bubbly and chatty and love to meet with friends over overpriced coffee or enjoying the nightlife. Moving abroad through the university allowed me to express my enjoyment for travelling, slowly ticking off the countries on my bucket-list. Related to travelling, I am a foodie enthusiast, whether that’s cooking for myself and friends, or trying any weird and wonderful food on the market. I am also keen to learn languages, and having been brought up in Spain, my knowledge of Spanish definitely sparked an interest in getting to know about other languages and cultures. I try to brush up on my Spanish at any given opportunity- a great excuse to go on holidays. I like to think I keep a well balanced social/ work life!</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Gabriel Brame">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/DSCF5638_Gabriel%20Brame_rdax_450x445.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/DSCF5638_Gabriel%20Brame_rdax_450x445.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/DSCF5638_Gabriel%20Brame_rdax_450x445.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/DSCF5638_Gabriel%20Brame_rdax_450x445.jpg"><source srcset="/img/250x/study/feature-images/DSCF5638_Gabriel%20Brame_rdax_450x445.jpg"><img src="/img/450x/study/feature-images/DSCF5638_Gabriel%20Brame_rdax_450x445.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Gabriel Brame</h2>
                        <p><a href="mailto:g.brame.22@abdn.ac.uk?subject=Go%20Abroad%20Questions">Email Gabriel</a></p>

<p><strong>Degree</strong>: <span id="docs-internal-guid-6ac9d492-7fff-c5ab-9dfa-9b04a8413709" style="font-style:normal; font-variant:normal; font-weight:400; text-decoration:none; vertical-align:baseline; white-space:pre-wrap">Psychology</span> (currently studying an MSc in Sustainability Transitions)</p>

<p><strong>Exchange Programme</strong>: Erasmus Study</p>

<p><strong>Destination</strong>:&nbsp;<span id="docs-internal-guid-7852f402-7fff-6ced-bf92-46d2793de10c" style="font-style:normal; font-variant:normal; font-weight:400; text-decoration:none; vertical-align:baseline; white-space:pre-wrap">University of Bergen, Norway</span></p>

<p><strong>Why I went abroad</strong>:&nbsp;&nbsp;Hi there! I'm Gabriel, a Master's student in Sustainability Transitions, previously an undergraduate in Psychology. I went abroad to Bergen, Norway in my second year of psychology and it turned out to be an absolutely fantastic decision. Going abroad is a great way to get to know a new country better and to make friends from vastly different backgrounds. You will never forget your exchange experience and I bet you'll keep the friends you make for a lifetime!</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Get in Touch</h2><div class="optional_content"><p><a id="Go Abroad Desk Further Info" name="Go Abroad Desk Further Info"></a></p></div>        <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Chat Face-to-Face">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/internationalcentre4x3_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/internationalcentre4x3_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/internationalcentre4x3_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/internationalcentre4x3_rdax_450x337.jpg"><source srcset="/img/250x/study/feature-images/internationalcentre4x3_rdax_450x337.jpg"><img src="/img/450x/study/feature-images/internationalcentre4x3_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Chat Face-to-Face</h3>
                        <p>Prefer to speak to our Ambassadors in person?</p>

<p>Visit the Go Abroad Desk in the International centre, 110 High Street.</p>

<p><strong>Mondays/Wednesdays/Fridays 14:00-16:00</strong></p>

<p><strong>Tuesdays/Thursdays 10:00-12:00</strong></p>

<p>The International Centre (IC) is an on-campus hub for anyone interested in the ‘international experience’ aspect of attending University. Offering advice, opportunities to socialise, and various different events and activities throughout the year.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/students/student-life/international-centre-3345.php#panel4050" target="_blank">Find out more about the IC</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Contact the Team">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/_a2_.JPG"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/_a2_.JPG"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/_a2_.JPG"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/_a2_.JPG"><source srcset="/img/250x/study/feature-images/_a2_.JPG"><img src="/img/450x/study/feature-images/_a2_.JPG" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Contact the Team</h3>
                        <p>Have a question for the Go Abroad Team?</p>

<p style="margin-left:0cm; margin-right:0cm"><strong>One-to-one virtual appointments</strong></p>

<p style="margin-left:0cm; margin-right:0cm">On Tuesdays 10:00-12:00 and Fridays 14:00-16:00 we offer bookable one-to-one virtual appointment slots with a member of the team -<a href="https://outlook.office365.com/owa/calendar/GoAbroadTeam1@365abdn.onmicrosoft.com/bookings/"> Go Abroad - appointment booking form</a>.&nbsp;You will receive a confirmation email once your slot has been booked, followed by a calendar invitation to an MSTeams Online Meeting for your time slot (you do not need login details to join the meeting). If you can no longer attend your meeting, please make sure to cancel the via the booking email or by emailing <a href="mailto:goabroad.outgoing@abdn.ac.uk?subject=cancel%20appointment" style="border-color: windowtext; text-decoration-line: underline; text-decoration-thickness: initial; text-decoration-color: initial;">goabroad.outgoing@abdn.ac.uk</a>.</p>

<p style="margin-left:0cm; margin-right:0cm"><strong>Email</strong></p>

<p style="margin-left:0cm; margin-right:0cm">Otherwise, the best way to contact the team is via email – <a href="mailto:goabroad.outgoing@abdn.ac.uk" style="border-color: windowtext; text-decoration-line: underline; text-decoration-thickness: initial; text-decoration-color: initial;">goabroad.outgoing@abdn.ac.uk</a>. Our email is monitored Monday to Friday 09:00-17:00.&nbsp;</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/study/index.php">Study Here</a></li>
            
            <li><a href="/study/undergraduate/index.php">Undergraduate</a></li>
            
            <li><a href="/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
            
            <li><a href="/study/undergraduate/engage-with-us-3070.php">Engage with us</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/study/undergraduate/go-abroad-tutors-3118.php">Go Abroad Tutors</a></li>
                
                <li><a href="/study/undergraduate/go-abroad-ambassadors-3119.php" class="current" aria-current="page">Go Abroad Ambassadors</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/study/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

    <script src="https://assets.app.futr.ai/webchat/futrwebchat.js" async></script>
    <script>
        window.futrWebchatSettings = [
            "n51ABtk8MqJ2co59TDT86z", {
                calloutLabel: "University of Aberdeen",
                calloutTitle: "Chat with us!",
                calloutExplainer: ""
            }
        ];
    </script>
    
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
