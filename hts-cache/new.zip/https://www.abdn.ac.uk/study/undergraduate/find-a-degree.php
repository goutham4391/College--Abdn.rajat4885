<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Entry Requirements | Study Here | The University of Aberdeen</title>
    <!-- Page ID : 1502 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
    <style>
        #futr-webchat-callout {
            background-color: #f4c900 !important;
            box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%) !important;
        }

        #futr-webchat-callout-explainer {
            font-size: 0.85em !important;
            opacity: 0.8 !important;
            margin-top: 1px !important;
        }

        #futr-roundel-closed > #roundel-logo {
            display: none;
        }

        #futr-roundel-closed > #roundel-custom-icon {
            font-weight: 400;
            font-family: 'Font Awesome 5 Pro';
            font-size: 20pt;
            color: #fff;
        }

        #futr-roundel-closed > #roundel-custom-icon::before {
            content: "\f086";
        }
    </style>
    
                    <link rel="stylesheet" href="/global/faqs/site/css/faq.css?cb=20221026" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>

                    <script src="/global/faqs/site/js/faq.functions.js?cb=20221026"></script>
                    </head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/study/" class="section_head_text">
                    Study Here                </a>
                <a href="https://www.abdn.ac.uk/study/enquire-now/" id="enquire_link" class="header_button_link">
Enquire Now <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a>            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="Study Here navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/study/undergraduate/index.php" class="current">Undergraduate</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-taught/index.php">Postgraduate Taught</a>
            </li>
            
            <li>
                <a href="/study/postgraduate-research/index.php">Postgraduate Research</a>
            </li>
            
            <li>
                <a href="/study/online/index.php">Online</a>
            </li>
            
            <li>
                <a href="/study/international/index.php">International</a>
            </li>
            
            <li>
                <a href="/study/funding/index.php">Scholarships</a>
            </li>
            
            <li>
                <a href="/study/student-life/index.php">Student Life</a>
            </li>
            
            <li>
                <a href="/study/open-days.php">Open Days and Events</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Entry Requirements</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/study/">Study Here</a></li>
            
            <li><a href="/study/undergraduate/index.php">Undergraduate</a></li>
            
            <li tabindex="0" aria-current="page">Entry Requirements</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">Entry Requirements</div>
                        <p>The University of Aberdeen recognises the disruption caused to education systems and learner journeys across the world by the Covid-19 pandemic. The University’s Admissions Selectors will be as flexible as possible while still ensuring that applicants are academically qualified for their chosen course of study.&nbsp;If you have any concerns, please email our <a href="mailto:study@abdn.ac.uk">Enquiry Team</a>&nbsp;to discuss your circumstances.</p>
                        </div>
                    </div>
                    
<div class="section">
    <div class="container">
    <h2>Entry Requirements (2023&nbsp;Entry)</h2>

<table border="0" cellpadding="10" cellspacing="0" class="faq_table" style="width:100%">
	<tbody>
		<tr>
			<th>Arts and Social Sciences</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<h3>Master of Arts (MA) in Arts &amp; Social Sciences</h3>

			<ul>
				<li>
				<p><a href="#Entry">MA - Minimum Entry Requirements</a><a name="top"></a></p>
				</li>
				<li>
				<p><a href="#Advanced">MA - Minimum Entry Requirements for Advanced Entry</a></p>
				</li>
			</ul>

			<p>Honours degrees in Scotland normally take four years to complete. In an arts or social science subject, you have a great deal of freedom to devise your own programme of study. Most first year classes are open to you even if you have not studied the subjects before, and you can usually go on to Honours in any subject that particularly interests you, even if it is not the subject you applied for via UCAS. All degrees have core courses, but your freedom to combine subjects is generally limited only by the timetable.</p>

			<h4>Changing Your Subject</h4>

			<p>The tradition in Scotland is to admit students to a degree programme rather than to a particular subject or degree. You do have to put specific subjects and course codes on your UCAS form, but essentially we admit you to the MA degree programme rather than specifically to an MA in Anthropology or History or Philosophy, for example. As a result, it is possible in most cases to change your Honours preference after you have begun your degree.</p>

			<h4>Specialised Years - Honours</h4>

			<p>Honours students can specialise in their third and fourth years in one particular subject (Single Honours), in two (Joint Honours) or in the case of Scottish Studies, three (General Honours). You can also take an Honours degree in which you add a 'minor' in a subject like Music to your 'major' subject. Honours degrees are classified, that is to say you will be awarded a first-class, upper-second, lower-second, or third-class degree.</p>

			<h4>Minimum Entry Requirements <a name="Entry"></a></h4>

			<p>Entry requirements for the MA are rarely subject-specific: we are more interested in your overall ability than in the precise content of your pre-university studies. In most cases you do not need a prior qualification in the subject to enter a first year degree, even if the subject in question is one that is on the school curriculum. There are some exceptions, but they are rare. When you apply, do not worry too much about getting your subject choice absolutely right on your application. If you find your interests changing, you will usually be able to change your degree intention accordingly.</p>

			<h5>Level One</h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>Type of Qualification</strong></td>
						<td nowrap="nowrap" style="width:320px"><strong>General&nbsp;Entry Requirements</strong></td>
						<td nowrap="nowrap" style="width:153px"><strong>Subject Requirements</strong></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top; width:91px">
						<p><strong>SQA - Scottish Qualifications</strong></p>
						</td>
						<td>
						<ul>
							<li>National 5 at minimum grade C, or Standard Grade at minimum grade 3 in English (or equivalent)</li>
							<li>National 5 Mathematics (or<strong>&nbsp;</strong>Applications of Mathematics) needed for entry to Accountancy, Finance and Economics</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS&nbsp;</strong></p>

						<ul>
							<li><strong>Standard</strong>: AABB. Applicants who achieve AABB or better over S4 and S5 are likely to be made an offer of admission. This may be unconditional or it may be conditional, dependent upon academic profile. Good performance in additional Highers / Advanced Highers may be required.</li>
							<li><strong>Minimum</strong>: BBB. Applicants who achieve the minimum of BBB over S4 and S5 are encouraged to apply and may be made a conditional offer. Good performance in additional Highers / Advanced Highers will normally be required.</li>
							<li><strong>Adjusted</strong>: BB. Applicants who achieve BB&nbsp;over S4 and S5, and who meet one or more Widening Access criteria, may be made a conditional offer. Good performance in additional Highers / Advanced Highers will be required.</li>
						</ul>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">online prospectus </a>for&nbsp;details.&nbsp;</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>GCE - General Certificate of Education</strong></td>
						<td>
						<ul>
							<li>GCSE in English or English Language at C or 4</li>
						</ul>

						<ul>
							<li>GCSE Maths at C or 4 needed for entry to Accountancy, Economics, Finance</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS&nbsp;</strong></p>

						<ul>
							<li><strong>Standard</strong>:&nbsp;BBB</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>:&nbsp;BBC</li>
						</ul>

						<ul>
							<li><strong>Adjusted</strong>:&nbsp;CCC, for applicants who meet one or more Widening Access&nbsp;criteria.</li>
						</ul>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/"><font>online prospectus </font></a>for&nbsp;details.&nbsp;</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>BTEC Level 3 Extended Diploma</strong></td>
						<td style="vertical-align:top; width:320px">
						<ul>
							<li>DDM in related subjects</li>
						</ul>

						<ul>
							<li>(NOTE: BTEC Level 3 Extended Certificate (Subsidiary Diploma) achieved at Distinction level, is normally acceptable in lieu of one A Level at grade B)</li>
						</ul>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/"><font>online prospectus </font></a>for&nbsp;details.&nbsp;</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top; width:320px">
						<ul>
							<li>O in English or in English Language</li>
							<li>A minimum of 5H with 3 at H2 and 2 at H3, or AAABB obtained at a single sitting. The grading within band B must be at B2 or above</li>
						</ul>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/"><font>online prospectus </font></a>for&nbsp;details.&nbsp;</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top; width:320px">
						<ul>
							<li>SL in English</li>
							<li>Minimum of 32 points including at least 5,5,5 at HL. For some degrees a specific subject is required. See online programme entry for details.</li>
						</ul>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/"><font>online prospectus </font></a>for&nbsp;details.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>EB - European Baccalaureate</strong></td>
						<td style="vertical-align:top; width:320px">
						<ul>
							<li>Pass First Foreign Language - English</li>
							<li>Minimum of 75% overall</li>
						</ul>
						</td>
						<td style="vertical-align:top; width:153px">&nbsp;</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>Higher National Diplomas</strong></td>
						<td style="vertical-align:top; width:320px">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation">Articulation routes information</a></li>
						</ul>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; width:91px"><strong>Higher National Certificates </strong></td>
						<td style="vertical-align:top; width:320px">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation">Articulation routes information</a></li>
						</ul>
						</td>
						<td style="vertical-align:top; width:153px">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h5>Level Two (Advanced Entry)<a name="Advanced"></a></h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap"><strong>Type of Qualification</strong></td>
						<td nowrap="nowrap"><strong>General Requirements</strong></td>
						<td nowrap="nowrap"><strong>Subject Requirements</strong></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>STANDARD OFFER HOLDERS ONLY. Advanced entry is possible in most school based subjects.</li>
							<li>A minimum of ABB overall in Adv H is required. Adv H at A in the subject selected for Single Honours, or AB in the subjects selected for Joint Honours.</li>
							<li>National 5 at&nbsp;grade C or above, <strong>or</strong> Standard&nbsp;Grade&nbsp;at grade&nbsp;3 or above in English</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/" target="_blank"><font>online prospectus </font></a>for&nbsp;details</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>STANDARD OFFER HOLDERS ONLY.</li>
							<li>A Level at A in the subject selected for Single Honours plus BB or AB in the subjects selected for Joint Honours, plus a further B</li>
							<li>GCSE in English or English Language</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/" target="_blank"><font>online prospectus </font></a>for&nbsp;details</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>SL in English</li>
							<li>Minimum of 36 (including 6,6,6 at Higher in subject(s) selected)</li>
						</ul>
						</td>
						<td style="vertical-align:top">&nbsp;</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>Higher National Diplomas</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h4>Offers of Admission</h4>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">Admission is competitive, and consequently precise entry requirements may vary from year to year.&nbsp;An applicant’s academic profile will normally be the most significant factor in our decision making. Additionally, certain features of the personal statement and reference may help to strengthen an applicant’s case. Where it is a school’s policy for an applicant to take one Higher in fourth year and three more in fifth year, we count all four.</p>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">Where applicants are taking Highers across fourth, fifth and sixth year we normally look for a better performance than the minimum. We do not double-count a Higher and an Advanced Higher in the same subject, but we do consider that a B-grade in Advanced Higher can represent an improvement on a B-grade at Higher, so an Advanced Higher may be used to upgrade a Higher.</p>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">Applicants choosing to resit a Higher in which they achieved a grade C or below in their first attempt will normally be required to achieve an A-grade in their second attempt. If the Higher at C was achieved in S4, this policy does not apply, even if the resit is not until S6.</p>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">We are keen to encourage people from the widest possible range of backgrounds to participate in university studies, and we appreciate that not all applicants have the same opportunity to meet our standard entry requirements. For this reason we take certain information into account when deciding on the exact grades we might require in any given case. This might include information about whether an applicant has had health problems or a disability, has been homeless, is a care leaver/estranged or a care giver, attends a school where a low proportion of pupils normally go on to higher education, lives in a relatively deprived area as defined by the Scottish Index of Multiple Deprivation, has attended or is eligible to attend widening-access programmes such as Aspire North, LEAPS, SWAP etc. Where information of this kind appears on the UCAS application, it may allow us to make an offer at our minimum level. <a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>

			<h4>Advanced Entry</h4>

			<p>The traditional four year MA Honours degree with its 'two-plus-two' structure (two pre-Honours years followed by a two-year Honours programme), allows you to experiment with new subjects in your pre-Honours years, and perhaps change your Honours intention, while still completing your degree in the normal time. However, if you are clear about what you want to study, and have (or are likely to get) good qualifications in the subject or subject area you have applied for, it is possible to complete an Honours degree in three years. In your first year, you would take a combination of first and second year subjects, and then proceed to third year in your second year of study. Direct entry to the second year of study is possible in most subject areas covered by the MA degree. To qualify for Advanced entry, prospective Single Honours students must hold an A grade pass at A Level, or an A grade pass at Advanced Higher, in the subject they wish to study for their degree. Prospective Joint Honours students may be admitted directly to the second year of the degree if they hold an A and B grade pass at A Level, or one A grade pass and one B grade pass at Advanced Higher in the subjects concerned.</p>

			<h4>Enhanced Study</h4>

			<p>You may have the opportunity to take Enhanced Study options as part of your degree and widen the breadth of your studies even more. <a href="https://www.abdn.ac.uk/study/undergraduate/enhanced-study-options-1518.php">More information on Enhanced Study</a>.</p>

			<h4 style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">Foundation Apprenticeships</h4>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">The University recognises that Skills Development Scotland, alongside other partners, is working with industry to increase the range of work-based learning opportunities for pupils in the senior phase of secondary schools. The development of Foundation Apprenticeships is one such initiative and this qualification will normally be considered in lieu of one SQA Higher at grade B across a range of degree programmes. You must still meet any specific subject requirements.</p>

			<h4 style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">Articulation routes</h4>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">The University welcomes applications for degree level study from students with HNC and HND qualifications, and has a number of college articulation routes in place which lead to advanced entry into our degree programmes. For full information contact your college, <a href="https://www.abdn.ac.uk/study/undergraduate/advanced-entry-from-college-2753.php">visit our website&nbsp;</a>or email <a href="mailto:study@abdn.ac.uk">study@abdn.ac.uk</a></p>

			<h4>Employment Prospects</h4>

			<p>'Arts' degrees are often thought of as educationally attractive but not strongly job-related. In fact, some degrees within the arts and social science area are strongly vocational: most graduates in Accountancy, Computing and Economics, for instance, will have no difficulty in finding a job, and will be employed because of the knowledge and skills they have learned at university; Mathematics graduates, too, are highly employable. As with most science graduates, however, the majority of graduates in arts and social science subjects go into careers in which they do not use their subject knowledge directly. They nevertheless have access to a wide range of career openings, because more than 40% of the vacancies notified to university careers services, or advertised in the broadsheet press, are for holders of degrees in any subject. Employers are looking for the qualities that any good MA graduate will have.</p>
			</td>
		</tr>
		<tr>
			<th>Sciences</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<h3>Bachelor of Science (BSc) in Sciences<a name="top"></a></h3>

			<p>The University is a major international centre for teaching and research in all divisions of scientific study, and Aberdeen has an unparalleled provision of buildings and equipment for science students.</p>

			<ul>
				<li>
				<p><a href="#entry">BSc - Minimum Entry Requirements</a></p>
				</li>
				<li>
				<p><a href="#advanced">BSc - Minimum Entry Requirements for Advanced Entry</a></p>
				</li>
				<li>
				<p><a href="#biomed">BSc Biomedical Sciences - Minimum Entry Requirements</a></p>
				</li>
				<li>
				<p><a href="#enhanced">MChem,MSci - Minimum Entry Requirements</a></p>
				</li>
			</ul>

			<h4>Flexibility and Breadth</h4>

			<p>The University of Aberdeen BSc degree structure is extremely flexible. When students apply, they are asked to nominate a specific degree title. However, admittance is actually to the general BSc Pure Science programme. Within this programme, students are free to change their degree intention to any of those listed in the BSc section of the prospectus. There are a few exceptions: the Biomedical Sciences, MChem and some MSci degrees have higher entry requirements than other science degrees, and consequently formal approval is required before changing degree intention to one of these degrees.</p>

			<p>In the first year of study, students typically take at least three subjects. One of these is continued in second year for half of the time, alongside either one of the other subjects studied in first year, or a selection of subjects, some of which may be new. At the end of second year the final choice of degree intention is made, based on the subjects studied so far, and the results obtained. In years three and four, students follow the specified curriculum for their final choice of degree subject.</p>

			<p>Each student has a Personal Tutor to guide them in their subject choices and to ensure that these choices comply with the degree regulations.</p>

			<h4>Qualifications</h4>

			<p>The Honours BSc requires four years of full-time study. The degree classification is based on the student's performance in the final year, and in some cases the third year as well.</p>

			<p>There are also a number of integrated Masters programmes (e.g. MChem and MSci) which require five years of full-time study. These degrees normally include an integral industrial placement. A student who leaves the University after one, two or three years of study can be re-admitted to study for a more advanced qualification.</p>

			<h4>Entry Requirements</h4>

			<p>Below you will find a full breakdown of our entry requirements. We look for a good level of proven academic ability overall, and strength in Science or Mathematics subjects. Beyond this we do not usually insist on specific subjects.</p>

			<p>In some cases, such as Chemistry and Mathematics, previous study of the subject is usually desirable in order to cope with the first year material. A student applying for one of these degrees who does not have the required background may still be offered a place, but in this case may be directed towards one of the other science degrees for which their background provides a better preparation.</p>

			<p><strong>Please Note: Computing, Geography, Geology, Information Systems, Psychology and Technology are acceptable as Science subjects for entry purposes.&nbsp;Higher Applications of Mathematics&nbsp;is acceptable as a Mathematics&nbsp;subject for entry purposes, except where Higher Mathematics is explicitly required.</strong></p>

			<h4>Minimum Entry Requirements - BSc</h4>

			<h5>Level One<a name="entry"></a></h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>General Requirements</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>Subject Requirements</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top">
						<p><strong>SQA - Scottish Qualifications</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>National 5 at grades C or above,&nbsp;OR Standard Grade at grade 3 or above,&nbsp;OR Int 2 in English, Mathematics (but <strong>not </strong>Applications of Mathematics) and in either Chemistry or Physics</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS</strong></p>

						<ul>
							<li><strong>Standard</strong>: AABB.&nbsp;Applicants who achieve AABB or better over S4 and S5 are likely to be made an offer of admission. This may be unconditional or it may be conditional, dependent upon academic profile. Good performance in additional Highers / Advanced Highers may be required.</li>
							<li><strong>Minimum</strong>: BBB. Applicants who achieve the minimum of BBB over S4 and S5 are encouraged to apply and may be made a conditional offer. Good performance in additional Highers / Advanced Highers will normally be required.</li>
							<li><strong>Adjusted</strong>: BB. Applicants who achieve BB (or below) over S4 and S5, and who meet one or more Widening Access criteria, may be made a conditional offer. Good performance in additional Highers / Advanced Highers will be required.</li>
						</ul>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>BB from two Science or Mathematics subjects from your senior phase of education (S4- S6). For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/"><font>online prospectus </font></a>for&nbsp;details</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - A Levels</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>GCSE at C (or Grade 4) or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS&nbsp;</strong></p>

						<ul>
							<li><strong>Standard</strong>:&nbsp;BBB</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>: BBC.</li>
						</ul>

						<ul>
							<li><strong>Adjusted</strong>:&nbsp;CCC, for applicants who meet one or more Widening Access criteria. Preferably one of the A Levels will be in the subject that is being studied.</li>
						</ul>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>BB from two Science or Mathematics subjects. For some degrees a specific subject is required, see&nbsp;our <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/"><font>online prospectus </font></a>for&nbsp;details</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>BTEC Level 3 Extended Diploma</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>DDM (Minimum)</li>
							<li>(NOTE: BTEC Level 3 Extended Certificate (Subsidiary Diploma) achieved at Distinction level, is normally acceptable in lieu of one A Level at grade B)</li>
							<li>GCSE at C (or Grade 4) or above in English or English Language, Mathematics and in either Chemistry or Physics or Dual Award Science</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>Main subjects to be in science or mathematics.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 5H with 3 at H2 and 2 at H3, OR&nbsp;AAABB including a minimum of H3 or BB from two science or mathematics subjects</li>
							<li>O in English, Mathematics and in either Chemistry or Physics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>H3 or BB from two science or mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 32 points</li>
							<li>SL or HL in English and Mathematics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>5 points at HL required from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>EB - European Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 75% overall</li>
							<li>Pass First Foreign Language</li>
						</ul>

						<p>&nbsp;</p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>Minimum of 75% in each of two sciences</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>National Diplomas</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
							<li>GCSE at C or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>Higher National Certificates </strong></td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>

						<p>&nbsp;</p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h5>Level Two (Advanced Entry)<a name="advanced"></a></h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>General Requirements</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>Subject Requirements</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>STANDARD OFFER HOLDERS ONLY. A minimum of 3AH at ABB</li>
							<li>National 5 at C or above (or equivalent) in English, Mathematics (but NOT Applications of Maths)&nbsp;and in either Chemistry or Physics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>2AH at AB from two Science or Mathematics subjects (including the subject(s) nominated for Honours)</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>STANDARD OFFER HOLDERS ONLY. A minimum of 3 A Levels at ABB</li>
							<li>GCSE at C&nbsp;(or Grade 4)&nbsp;or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>AB from two Science or Mathematics subjects (including the subject(s) nominated for Honours</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 34 points</li>
							<li>SL or HL in English and Maths</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>6 at HL in the subject(s) nominated for Honours</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>Higher National Diplomas </strong></td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
							<li>National 5 at grades A, B or C,&nbsp;OR S Grade at levels 1, 2 or 3,&nbsp;OR Int 2 in English, Mathematics and in either Chemistry or Physics</li>
						</ul>

						<p>or</p>

						<ul>
							<li>GCSE at C (or Grade 4)&nbsp;or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li><a href="http://www.abdn.ac.uk/study/articulation"><font>Articulation routes information</font></a></li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h4>Minimum Entry Requirements - BSc Biomedical Sciences</h4>

			<h5>Level One <a name="biomed"></a></h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>General Requirements</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>Subject Requirements</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top">
						<p><strong>SQA - Scottish Qualifications</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>National 5 at A, B or C, or S at levels 1, 2 or 3, or Int 2 in English, Mathematics (NOT Applications of Maths) and in either Chemistry or Physics</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS&nbsp;</strong></p>

						<ul>
							<li>A minimum of 4H at AAAB (C or B at AH may substitute for B or A at H respectively) obtained at a single sitting or minimum of 5H at AAAAB obtained over two sittings</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>AB from Chemistry and another Science or Mathematics Subject</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>GCSE at C (or Grade 4)&nbsp;or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science&nbsp;</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS</strong></p>

						<ul>
							<li>A minimum of 3 A Levels at ABB</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>AB from Chemistry and another Science or Mathematics Subject</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 5H with 4 at H2 and 1 at H3, with H2 and H3 from Chemistry and another Science or Mathematics subject, or AAABB including AB from
							<p>Chemistry and another Science or Mathematics subject. The grading within band B must be B2 or above</p>
							</li>
							<li>O in English, Mathematics and in either Chemistry or Physics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>H2 from Chemistry and another Science or Mathematics Subject</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 34 points</li>
							<li>SL or HL in English and Mathematics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>6 points at HL required from Chemistry and another Science or Mathematics Subject</li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h5>Level Two (Advanced Entry)</h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>General Requirements</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>Subject Requirements</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 3AH at AAB</li>
							<li>National 5 at minimum grade C, or Standard Grade at minimum grade&nbsp;3, or Int 2 in the following:&nbsp;English, Mathematics (but NOT Applications of Maths) and in either Chemistry or Physics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>2AH at AB from Chemistry and Biology</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 3 A Levels at AAB. A Level subjects should include Chemistry, Biology and (normally) Physics</li>
							<li>GCSE at C&nbsp;(or&nbsp;Grade 4)&nbsp;or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>AB from Chemistry and Biology</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 36 points</li>
							<li>SL or HL in English and Mathematics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>6 points minimum at HL required from Chemistry and Biology</li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h4>Minimum Entry Requirements - MChem, MSci</h4>

			<h5>Level One</h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>General Requirements</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>Subject Requirements</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>National 5 at minimum grade C, or Standard Grade&nbsp;at minimum grade&nbsp;3, or Int 2 in the following: English, Mathematics (but NOT Applications of Maths)&nbsp;and in either Chemistry or Physics</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS</strong></p>

						<ul>
							<li>A minimum of 4H at AAAB (C or B at AH may substitute for B or A at H respectively)</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - Highers at AB from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Sci - Highers at AB from Chemistry and Biology</li>
							<li>For all other MSci - Highers at AB from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>GCSE at C (or Grade 4)&nbsp;or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS</strong></p>

						<ul>
							<li>A minimum of 3 A Levels at ABB</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - A levels at AB from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Sci - A levels at AB from Chemistry and Biology</li>
							<li>For all other MSci - A levels at AB from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 5H with 4 at H2 and 1 at H3, with H2 and H3 from Chemistry and another Science or Mathematics subject,&nbsp;OR AAABB including AB from
							<p>Chemistry and another Science or Mathematics subject. The grading within band B must be B2 or above</p>
							</li>
							<li>O in English, Mathematics and in either Chemistry or Physics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - H2 from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Si - H2 from Chemistry and Biology</li>
							<li>For all other MSci - H2 from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 34 points</li>
							<li>SL or HL in English and Mathematics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - 6 points at HL required from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Sci - 6 points at HL from Chemistry and Biology</li>
							<li>For all other MSci - 6 points at HL from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p style="text-align:right"><a href="#top">[top]</a></p>

			<h5>Sciences: Level Two (Advanced Entry)<a name="enhanced"></a></h5>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>General Requirements</strong></p>
						</td>
						<td nowrap="nowrap">
						<p><strong>Subject Requirements</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 3AH at AAB</li>
							<li>National 5 at minimum grade C, or Standard Grade at minimum&nbsp;grade 3, or Int 2 in the following: English, Mathematics (but NOT Applications of Maths) and in either Chemistry or Physics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - 2 AH at AB from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Sci - 2 AH at AB from Chemistry and Biology</li>
							<li>For all other MSci - 2 AH at AB from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 3 A Levels at AAB. A Level subjects should include Chemistry, Biology and (normally) Physics</li>
							<li>GCSE at C or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - A levels at AB from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Sci - A levels at AB from Chemistry and Biology</li>
							<li>For all other MSci - A levels at AB from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 36 points</li>
							<li>SL or HL in English and Mathematics</li>
						</ul>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>For MChem - 6 points at HL required from Chemistry and another Science</li>
							<li>For MSci Biomedical / Medical Sci - 6 points at HL from Chemistry and Biology</li>
							<li>For all other MSci - 6 points at HL from two Science or Mathematics subjects</li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<p>Please note that the stated Entry Requirements do not guarantee entry. <strong>Computing, Geography, Geology, Information Systems, Psychology and Technology are acceptable as Science subjects for entry purposes. Higher Applications of Mathematics&nbsp;is acceptable as a Mathematics&nbsp;subject for entry purposes, except where Higher Mathematics&nbsp;is explicitly required.</strong></p>

			<h4>Offers of Admission</h4>

			<p>Admission is competitive, and consequently precise entry requirements may vary from year to year. An applicant’s academic profile will normally be the most significant factor in our decision making. Additionally, certain features of the personal statement and reference may help to strengthen an applicant’s case. Where it is a school’s policy for an applicant to take one Higher in fourth year and three more in fifth year, we count all four but the applicant must include two science or mathematics subjects.</p>

			<p>Where applicants are taking Highers across fourth, fifth and sixth year we normally look for a better performance than the minimum. We do not double-count a Higher and an Advanced Higher in the same subject, but we do consider that a B-grade in Advanced Higher can represent an improvement on a B-grade at Higher, so an Advanced Higher may be used to upgrade a Higher.</p>

			<p>Applicants choosing to resit a Higher in which they achieved a grade C or below in their first attempt will normally be required to achieve an A-grade in their second attempt. If the Higher at C was achieved in S4, this policy does not apply, even if the resit is not until S6. We are keen to encourage people from the widest possible range of backgrounds to participate in university studies, and we appreciate that not all applicants have the same opportunity to meet our typical entry requirements.</p>

			<p>We are keen to encourage people from the widest possible range of backgrounds to participate in university studies, and we appreciate that not all applicants have the same opportunity to meet our standard entry requirements. For this reason we take certain information into account when deciding on the exact grades we might require in any given case. This might include information about whether an applicant has had health problems or a disability, has been homeless, is a care leaver/estranged or a care giver, attends a school where a low proportion of pupils normally go on to higher education, lives in a relatively deprived area as defined by the Scottish Index of Multiple Deprivation, has attended or is eligible to attend widening-access programmes such as Aspire North, LEAPS, SWAP etc. Where information of this kind appears on the UCAS application, it may allow us to make an offer at our minimum level. <a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and Adjusted entry qualifications.</font></a></p>

			<h4>Advanced Entry</h4>

			<p>The four year length of the degree programme provides the opportunity for the breadth and flexibility that is such a significant feature of the Aberdeen Honours degree. However, for those who are well-qualified, and who are clear about their degree intention, it is possible to complete an Honours degree in three years rather than four. Such students effectively join the second year of the degree programme, and during this year they study the required second year modules for their nominated degree subject, alongside a selection of other first and second year modules.</p>

			<p>Good entry qualifications are needed, at least up to the level of GCE A Level, or SQA Advanced Higher, particularly in subjects that are essential for the intended degree and that would otherwise have been studied in first year. Some opportunities for third year entry also exist for those with qualifications up to the level of a good HND, provided the core content of the first two years of the degree curriculum has been covered adequately.</p>

			<h4>Scottish Baccalaureate</h4>

			<p>The Scottish Baccalaureate qualification is a good preparation for entry to university. The qualification will be considered alongside Advanced Highers, for direct entry into year two across a range of degree programmes.</p>

			<h4>Enhanced Study</h4>

			<p>You may have the opportunity to take Enhanced Study options as part of your degree and participate in co-curricular activities. <a href="https://www.abdn.ac.uk/study/undergraduate/enhanced-study-options-1518.php"><font>More information on Enhanced Study</font></a>..</p>

			<h4>Foundation Apprenticeships</h4>

			<p>The University recognises that Skills Development Scotland, alongside other partners, is working with industry to increase the range of work-based learning opportunities for pupils in the senior phase of secondary schools. The development of Foundation Apprenticeships is one such initiative and this qualification will normally be considered in lieu of one SQA Higher at grade B across a range of degree programmes.&nbsp;You must still meet any specific subject requirements.</p>

			<h4>Employment Prospects</h4>

			<p>Most science graduates, regardless of their university, are able to find some kind of employment. The important question is not “Will I get a job after graduating?” but “What kind of job can I get?” As a science graduate from Aberdeen you will be well prepared for a wide range of high-quality employment opportunities. With a good Honours classification you will also be qualified for study towards a higher degree or PhD study.</p>

			<p>Good Aberdeen graduates are highly regarded, and consequently many major employers in industry and commerce target the University in their annual recruiting exercises. An extremely high percentage of science graduates secure good jobs or further study/training opportunities within six months of graduation.</p>
			</td>
		</tr>
		<tr>
			<th>Engineering</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<p>Our philosophy is one of world-class teaching in an atmosphere of research. Staff in the School have won major national awards, and strong links with industry ensure that teaching is in line with the requirements of today's companies.</p>

			<h3>Honours Degrees of MEng and BEng</h3>

			<p>The MEng is a five-year Honours programme and the BEng is a four-year Honours programme, both of which are fully accredited by the Engineering Institutions. The first two years of our programmes cover general engineering, with elements of chemical, mechanical, petroleum and electrical/electronics, as well as civil. This approach gives Aberdeen graduates a broad understanding of engineering principles, which we know is invaluable to their future careers. Similarly highly regarded is the particular emphasis on management and project management. Again, we know from working with industry that this knowledge is vital for new graduates working in an engineering capacity. In the later years you specialise, following your chosen discipline in greater depth including design applications.</p>

			<p><strong>Note: </strong>Higher Applications of Mathematics&nbsp;is NOT acceptable where Higher Mathematics&nbsp;is explicitly required.</p>

			<h4>Minimum Entry Requirements</h4>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap">
						<p><strong>Type of Qualification</strong></p>
						</td>
						<td nowrap="nowrap"><strong>BEng - First Year Entry</strong></td>
						<td nowrap="nowrap">
						<p><strong>MEng - First Year Entry</strong></p>
						</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>National 5 (or equivalent)&nbsp;at grades A, B or C in English.&nbsp;</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS</strong></p>

						<ul>
							<li><strong>Standard</strong>: ABBB (Mathematics and Physics or Engineering Science required) Applicants who achieve the Standard entry requirements over S4 and S5 will be made either an unconditional or conditional offer of admission.</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>: BBB (Good performance required in Mathematics and Physics). Applicants who achieve our Minimum entry requirements over S4 and S5 are encouraged to apply and will be considered. Good performance in additional Highers / Advanced Highers will normally be required in order to receive an offer of admission.</li>
						</ul>

						<ul>
							<li><strong>Adjusted: BB </strong>(Good performance required in Mathematics). Applicants who meet one or more Widening Access criteria and who achieve a good performance in Maths and one other subject may be made an adjusted offer of entry. Good performance in additional Highers / Advanced Highers will be required in order to receive an offer of admission</li>
						</ul>

						<p><strong>Note: For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and Adjusted entry qualifications.</font></a></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>National 5 (or equivalent)&nbsp;at grades A, B or C in English.</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS</strong></p>

						<ul>
							<li><strong>Standard</strong>:&nbsp;AABB (Mathematics and Physics or Engineering Science required.) Applicants who achieve the Standard entry requirements over S4 and S5 will be made either an unconditional or conditional offer of admission</li>
						</ul>

						<p><strong>Note:<br />
						For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>GCSE English at C (or Grade 4), or above.</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS</strong></p>

						<ul>
							<li><strong>Standard</strong>: BBB Good performance required in Mathematics, plus at least one from Physics, Design &amp; Technology, Engineering or Chemistry) Applicants who are predicted to achieve the Standard entry requirements are encouraged to apply and may be made a offer of admission.</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>: BBC (Good performance required in Mathematics, plus at least one from Physics, Design &amp; Technology, Engineering or Chemistry.) Applicants who are predicted to achieve the Minimum entry requirements are encouraged to apply and will be considered.</li>
						</ul>

						<ul>
							<li><strong>Adjusted</strong>: BB (Good performance required in Mathematics) Applicants who meet one or more Widening Access criteria and who are predicted to achieve a good performance in Mathematics and one other subject may be made an adjusted offer of entry.</li>
						</ul>

						<p><strong>Note: For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and Adjusted entry qualifications.</font></a></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>GCSE English at C.</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS</strong></p>

						<ul>
							<li><strong>Standard</strong>: ABB. (AB required, to include Mathematics, plus at least one from Physics, Design &amp; Technology, Engineering or Chemistry) Applicants who are predicted to achieve the Standard entry requirements are encouraged to apply and may be made a conditional offer of admission.</li>
						</ul>

						<p><strong>Note:<br />
						For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 5H with 3 at H2 and 2 at H3 (including H2 and H3 in Mathematics and Physics) OR AAABB including Mathematics and Physics at AB. B grade must be at B2 or above. English at Standard Level also required.</li>
						</ul>

						<p><strong>Note:<br />
						For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 5H with 4 at H2 and 1 at H3 including H2 and H3 in Mathematics and Physics OR AAAAB including AB in Mathematics and Physics. Mathematics at a H2 or an A. Grade B's must be at B2 or above.</li>
						</ul>

						<p><strong>Note: For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>32 points including Mathematics and Physics at HL (5 or above) and English at Standard Level.</li>
						</ul>

						<p><strong>Note:<br />
						For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>34 points including Mathematics and Physics at HL (6 or above) and English at Standard Level.</li>
						</ul>

						<p><strong>Note:<br />
						For entry to Chemical and Petroleum Engineering an SQA Higher or GCE A Level or equivalent qualification in Chemistry is required for entry to year 1, in addition to the general Engineering requirements noted above.</strong></p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top">
						<p><strong>BTEC Level 3 Extended</strong></p>

						<p><strong>Diploma</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>DDM. Maths and Physics required (Petroleum and Chemical Engineering degrees also require Chemistry).</li>
							<li>GCSE at C (or Grade 4)or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science.</li>
						</ul>

						<p><strong>Note: BTEC in Applied Sciences is not normally sufficient on its own for entry into any of our Engineering programmes</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>DDD. Maths and Physics required (Petroleum and Chemical Engineering degrees also require Chemistry).</li>
							<li>GCSE at C (or Grade 4) or above in English or English Language, Mathematics and in either Chemistry, or Physics or Dual Award Science.</li>
						</ul>

						<p><strong>Note: BTEC in Applied Sciences is not normally sufficient on its own for entry into any of our Engineering programmes</strong></p>
						</td>
					</tr>
				</tbody>
			</table>

			<h4>Offers of Admission</h4>

			<p>Applicants should note that achieving the minimum entrance requirements may not on its own&nbsp;guarantee an offer of admission. Consequently, we may need to ask for more than the minimum. An applicant’s academic profile will normally be the most significant factor in our decision making. Additionally, certain features of the personal statement may help to strengthen an applicant’s case.</p>

			<h4>Foundation Apprenticeships</h4>

			<p>The University recognises that Skills Development Scotland, alongside other partners, is working with industry to increase the range of work-based learning opportunities for pupils in the senior phase of secondary schools. The development of Foundation Apprenticeships is one such initiative and this qualification will normally be considered in lieu of one SQA Higher at grade B across a range of degree programmes.&nbsp;You must still meet any specific subject requirements.</p>
			</td>
		</tr>
		<tr>
			<th>Law</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<p>Law has been taught at the University of Aberdeen since its foundation in 1495; today the Law School continues to build on this strong traditional foundation to offer a modern, flexible degree, which provides an excellent academic training.</p>

			<h3>Minimum Entry Requirements for the Bachelor of Laws (LLB)</h3>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap"><strong>Type of Qualification</strong></td>
						<td nowrap="nowrap"><strong>General Requirements</strong></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>&nbsp;National 5 English at C or better is required.</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS</strong></p>

						<ul>
							<li><strong>Standard</strong>: AAAB or AABBB. Applicants who have achieved AAAB (or better), are encouraged to apply and will be considered. Good performance in additional Highers / Advanced may be required.</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>: BBBB. Applicants who have achieved BBBB (or are on course to achieve this by the end of S5) are encouraged to apply and will be considered. Good performance in additional Highers / Advanced Highers will normally be required.</li>
						</ul>

						<ul>
							<li><strong>Adjusted</strong>: BBBC. Applicants who have achieved BBBC, and who meet one of the Widening Access criteria are encouraged to apply and will be considered. Good performance in additional Highers / Advanced Highers will be required.</li>
						</ul>

						<p>Higher English is highly desirable. Higher ESOL is also recognised in lieu of Higher English where the mother tongue is not English.&nbsp;</p>

						<p>Where a combination of H and AH is offered, individual subjects are counted at one level only.</p>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>&nbsp;GCSE in English or English Language required.</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS</strong></p>

						<ul>
							<li><strong>Standard</strong>: ABB&nbsp;</li>
							<li>English is highly desirable.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>5H at H2&nbsp;obtained in&nbsp;a single sitting. O in English required.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>34 points including an average of 5 at HL; English is highly desirable</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top">
						<p><strong>BTEC Level 3 Extended Diploma</strong></p>
						</td>
						<td style="vertical-align:top">
						<p style="margin-bottom:8pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:107%"><span style="line-height:107%">A BTEC Level 3 Extended Diploma is <strong>not normally </strong>sufficient on its own for entry into our LLB degree programmes, although those with a relevant BTEC (Law-related) at a minimum of DDD may be considered.</span></span></p>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<th>Education</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<p>The School of Education has a long and distinguished record in the training of teachers. Staff are recognised nationally and internationally for their development work in particular fields.</p>

			<h3>Minimum Entry Requirements for the MA (Hons) in Primary Education</h3>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td><strong>Type of Qualification</strong></td>
						<td><strong>General Requirements</strong></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top">
						<p><strong>SQA - Scottish Qualifications</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>4 Highers at ABBB obtained from S4 and S5.</li>
						</ul>

						<p>Those seeking to qualify over S5 and S6 will be expected to exceed this minimum. Mathematics and English required, as stated below.</p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top">
						<p><strong>GCE - General Certificate of Education</strong></p>
						</td>
						<td style="vertical-align:top">
						<ul>
							<li>A Levels: BBB.</li>
						</ul>

						<p>&nbsp; Mathematics and English required, as stated below.</p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>International Baccalaureate (IB)</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>32 points including 5, 5, 5 at HL</li>
						</ul>

						<p>Mathematics and English required, as stated below.</p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>Irish Leaving Certificate/ Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>A minimum of 4H, with one&nbsp;at H2 and three&nbsp;at H3&nbsp;OR ABBB all obtained in a single sitting, including English and 2 at Ordinary Level, including Maths which must be at Grade B or above. The grading within Band B must be at B2 or above.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>BTEC Level 3 Extended Diploma</strong></td>
						<td style="vertical-align:top"><span style="line-height:107%">We are unable to accept the BTEC qualification because the General Teaching Council for Scotland (GTCS) requires evidence of subject spread at SCQF Level 6.</span></td>
					</tr>
				</tbody>
			</table>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">&nbsp;</p>

			<h4 style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">HNC and HND</h4>

			<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">Qualifications such as Early Education and Childcare will be accepted as one subject alongside 3 additional subjects at Higher Level or equivalent. <strong>We require a minimum of 4 separate SCQF Level 6 subjects.</strong> So an HNC or an HND in any subject counts as one. Three more SCQF Level 6 subjects are required. &nbsp;This must include Higher English at Grade B (or an equivalent as detailed below), plus two further separate subjects at SCQF Level 6. If these are Highers, grade C or above is required. Where a FA is presented, this will count as an SCQF Level 6 subject at grade B. In addition, a Maths qualification, as detailed below, must be achieved.</p>

			<p><strong>UNIVERSITY GRADUATES</strong></p>

			<p>Graduates wishing&nbsp;to apply for primary teaching training must apply for the Professional Graduate Diploma in Education (PGDE). PGDE Courses in both primary and secondary education are available and are professionally accredited by the General Teaching Council for Scotland (GCTS). More information on the PGDE can be found <a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/991/primary-education/" rel="noopener" target="_blank">here</a>.</p>

			<h4>English Minimum</h4>

			<ul>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">SQA Higher grade award in English at Grade B or above; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">GCSE English Language <strong>AND </strong>English Literature, at Level 6 (previously Grade B) or above <strong>IN BOTH</strong>; <strong>or&nbsp;</strong>A Level English, Grade C or above; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">O Level English Language <strong>AND </strong>English Literature, Grade B or above or pass <strong>IN BOTH</strong>; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">International Baccalaureate English at HL Grade 5; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">Irish Leaving Certificate English at Higher Grade 3 or above or Higher Grade B3 or above; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">National Course award (Higher Still) in English and Communication at Grade B or above; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">National Units – Communication (NC) at Higher level and Literature 1 at Higher level **; or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">University of Aberdeen Online English (see below) or</li>
				<li style="font-style: normal; font-weight: normal; margin-top: 0cm; margin-bottom: 0pt;">English of an equivalent academic standard from <strong><em>outside </em></strong>the UK.</li>
			</ul>

			<h5>*Higher ESOL only acceptable for entry to PGDE Secondary, <strong>NOT</strong> PGDE Primary or undergraduate Primary.<br />
			<em>** Previously known as National Certificate Modules Communication 4 &amp; Literature 1</em></h5>

			<h4>Mathematics Minimum</h4>

			<ul>
				<li>National 5 Mathematics at Grade C or above; or</li>
				<li>National 5 Applications of Mathematics (previously known as Lifeskills Maths) at Grade C or above; or</li>
				<li>Core Maths 4 Pass; or</li>
				<li>GCSE Mathematics at Level 4, or Grade C or above or Pass; or</li>
				<li>O Level Mathematics at Grade C or above or Pass; or</li>
				<li>International Baccalaureate Maths at SL Grade 4; or</li>
				<li>Irish Leaving Certificate Mathematics at Ordinary Grade 3 or above or Ordinary Grade B or above; or</li>
				<li>National Course Award Intermediate Level 2 Mathematics at Grade C or above; or</li>
				<li>SCE Standard grade (credit level) award in Mathematics at Grade 2 or above; or</li>
				<li>SCE Ordinary grade award in Mathematics at Grade C or above or Pass; or</li>
				<li>Open University Course – MU123 Discovering Mathematics#, Pass; or</li>
				<li>University of Aberdeen Online Maths (see below) or</li>
				<li>Mathematics of an equivalent academic standard from <strong><em>outside </em></strong>the UK</li>
			</ul>

			<h5>#Please note that with regard to OU MU123 – the course generally starts in January each year with exam results issued in the December of the same year.</h5>

			<p>The following are <strong>not accepted</strong> as a Mathematics qualification at the University of Aberdeen: Standard Grade 3 or below, GCSE Grade D or below, CSE Grade 1, O Level Grade 3.</p>

			<p>The University will consult UK ENIC (The UK National Information Centre for global qualifications and skills), to determine whether or not qualifications achieved outside the UK meet the entry requirements detailed above.</p>

			<p><strong>University of Aberdeen Online English and Mathematics</strong></p>

			<p>The University of Aberdeen has launched online access courses, in English and in Mathematics. &nbsp;English is at SCQF Level 6 – the equivalent to Higher English and there are three Maths courses – SCQF Level 5, Level 6 and Level 7. All are accepted by the University of Aberdeen for entry to teacher training.</p>

			<p>For MA Primary we would require Aberdeen Online Access English (SCQF6) at grade B3 or above and Aberdeen Online Access Maths (SCQF 5) at grade C3 or above.</p>

			<p><font>Full information on the Online provision, including costs, can be found at </font><a href="http://www.abdn.ac.uk/study/online/access-courses.php"><font>www.abdn.ac.uk/study/online/access-courses.php</font></a></p>

			<h4>Foundation Apprenticeships</h4>

			<p>The University recognises that Skills Development Scotland, alongside other partners, is working with industry to increase the range of work-based learning opportunities for pupils in the senior phase of secondary schools. The development of Foundation Apprenticeships is one such initiative and this qualification will normally be considered in lieu of one SQA Higher at grade B across a range of degree programmes.&nbsp;You must still meet any specific subject requirements.</p>

			<h4>Accreditation</h4>

			<p>The Master of Arts (MA) in Education (Hons) programme is accredited by the General Teaching Council for Scotland (GTCS) and allows graduates to apply for provisional registration as a primary teacher.</p>
			</td>
		</tr>
		<tr>
			<th>Divinity and Theology</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<p>Theological study and learning go back beyond the foundation of the University in 1495. The School is situated in the beautiful and historic buildings of King's College.</p>

			<h3>Degrees in Divinity and Theology</h3>

			<p>The School offers three degrees at the undergraduate level: <strong>Bachelor of Divinity (BD), Bachelor of Theology (BTh), Master of Arts (MA) in Theology and Re</strong><strong>ligion.</strong>&nbsp;Each may be taken as a non-Honours or as an Honours degree.</p>

			<h4>Bachelor of Divinity (BD)</h4>

			<p>The BD is designed for students who wish specialised and comprehensive study of the Christian tradition, or who are preparing for a future in full-time ministry.&nbsp;The study of the biblical languages (Hebrew and Greek) by candidates for this degree is encouraged, but not compulsory. The designated degree of BD normally takes three years and the Honours degree normally takes&nbsp;four years.</p>

			<h4>Bachelor of Theology (BTh)</h4>

			<p>The BTh is designed to be more flexibly structured than the BD. It provides flexibility of course choice and the chance to combine the study of Theology with subjects in other disciplines in the early years of the programme. It is particularly suited to the needs of those considering teaching religious and moral education in schools. The BTh can be taken via distance learning.</p>

			<h4>Master of Arts (MA) in Theology and Religion</h4>

			<p>The MA in Theology and Religion&nbsp;includes both the study of Christian faith, life and doctrine, and the wider study of religion and religious traditions from around the world. The study of the Christian tradition attends to its historical, cross-cultural and contemporary contexts, whereas the comparative study of world religions includes an interdisciplinary investigation and interpretation of the origin, function and mean of religion and religious practice.</p>

			<h4>Minimum Entry Requirements for the Bachelor of Divinity (BD) and the Bachelor of Theology (BTh)</h4>

			<p>(For the MA in Theology and Religion, see Arts and Social Sciences above.)</p>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap"><strong>Type of Qualification</strong></td>
						<td nowrap="nowrap"><strong>General Requirements</strong></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>National 5 at minimum grade C, or Standard Grade at minimum grade 3 in English (or equivalent)</li>
						</ul>

						<p style="margin-left:40px"><strong>HIGHERS&nbsp;</strong></p>

						<ul>
							<li><strong>Standard</strong>: AABB.&nbsp;Applicants who achieve AABB or better over S4 and S5 are likely to be made an offer of admission. This may be unconditional or it may be conditional, dependent upon academic profile. Good performance in additional Highers / Advanced Highers may be required.</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>: BBB.&nbsp;Applicants who achieve the minimum of BBB over S4 and S5 are encouraged to apply and may be made a conditional offer. Good performance in additional Highers / Advanced Highers will normally be required.</li>
						</ul>

						<ul>
							<li><strong>Adjusted</strong>: BB.&nbsp;Applicants who achieve BB&nbsp;over S4 and S5, and who meet one or more Widening Access</li>
							<li>criteria, may be made a conditional offer. Good performance in additional Highers / Advanced Highers will be required.</li>
						</ul>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>

						<p><strong>Advanced Entry</strong> - For those seeking entry into second year classes, with a view to taking an accelerated Honours degree, the normal requirement will be BC at H plus A at AH or 2AH at AB. This must include AH at A in Religious Studies. Where a combination of H and AH has been studied, individual subjects will be counted at one level only.</p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - <span style="line-height:107%">General Certificate of Education</span></strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>GCSE in English or English Language</li>
						</ul>

						<p style="margin-left:40px"><strong>A LEVELS&nbsp;</strong></p>

						<ul>
							<li><strong>Standard</strong>: 3 A Levels at BBB</li>
						</ul>

						<ul>
							<li><strong>Minimum</strong>: 3 A Levels at BBC.</li>
						</ul>

						<ul>
							<li><strong>Adjusted</strong>: 3 A Levels at CCC, for applicants who meet one or more Widening Access criteria. Preferably one of the A Levels will be in the subject that is being studied.</li>
						</ul>

						<p><a data-mce-href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" href="https://www.abdn.ac.uk/study/undergraduate/contextual-admissions--2847.php" target="_blank"><font>More information on our definition of Standard, Minimum and&nbsp;Adjusted&nbsp;entry qualifications.</font></a></p>

						<p><strong>Advanced Entry</strong> - For those seeking entry into second year classes, with a view to taking an accelerated Honours degree, the normal requirement must include A Level at A in Religious Studies.</p>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>O in English or in English Language</li>
							<li>A minimum of 5H with 3 at H2 and 2 at H3, or AAABB obtained at a single sitting. The grading within band B must be at B2 or above..</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>Minimum of 32 points at least 5,5,5 at HL.</li>
							<li>SL in English required.</li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<th>Music</th>
		</tr>
		<tr>
			<td style="vertical-align:top">
			<p>Our music staff possess a wide range of research expertise encompassing aspects of performance, composition and musicology. Facilities for music students are first-class, including electroacoustic music studios, a collection of historical instruments and a world music centre. Our full time degree programmes comprise the following:</p>

			<ul>
				<li>BMus with Honours</li>
				<li>BMus with Honours (Music Education)</li>
			</ul>

			<h3>Degree Options</h3>

			<p>Following core music studies, in which students are able to develop skills in performance, composition, musicianship and music history, one of three Honours programmes is chosen. BMus with Honours is a music degree; the BMus with Honours (Music Education) programme leads to a qualification to teach music in secondary schools and the BMus with Honours (Community Music) applies musical skills while working in a range of communities.</p>

			<p><strong>Please note:</strong> for entry to the <strong>BMus (Music Education)</strong> with honours programme the following are requirements set by the General Teaching Council of Scotland (GTCS):<br />
			<br />
			ENGLISH MINIMUM<br />
			Higher English at grade C&nbsp;or above, or GCSE English Language <strong>and </strong>English Literature at grade 4/C or above or equivalent.<br />
			<br />
			MATHEMATICS MINIMUM<br />
			National 5 Maths at grade C or above, or Applications of Maths (previously known as Lifeskills Mathematics) at grade C or above; Standard Grade Mathematics at grade 1 or 2, or GCSE Mathematics at grade 4/C&nbsp;or above, or equivalent.</p>

			<h3>Minimum Entry Requirements for the Bachelor of Music (BMus)</h3>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<thead>
					<tr>
						<td nowrap="nowrap"><strong>Type of Qualification</strong></td>
						<td nowrap="nowrap"><strong>General Requirements</strong></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="vertical-align:top"><strong>SQA - Scottish Qualifications</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>Minimum 4 Highers at ABBB in four distinct disciplines (Music cannot be double counted). Music at Higher Grade A preferable</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>GCE - General Certificate of Education</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>Minimum of 3&nbsp;A Levels at BBB. Music A Level at minimum Grade B. Minimum of 3 additional GCSE passes.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>ILC - Irish Leaving Certificate / Ardteistimeireacht</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>&nbsp;A minimum of 3H at H2 or BBB.</li>
						</ul>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><strong>IB - International Baccalaureate</strong></td>
						<td style="vertical-align:top">
						<ul>
							<li>32&nbsp;points including at least a Grade 6 at Music at HL</li>
						</ul>
						</td>
					</tr>
				</tbody>
			</table>

			<h3>Music Qualifications</h3>

			<p>Candidates should demonstrate musical attainment and potential. Candidates should have Grade VIII Associated Board (or equivalent) in their main instrument/voice or who show great potential and intend to take Grade VIII. Competence on piano is required for those who intend to take BMus Music Education.</p>
			</td>
		</tr>
	</tbody>
</table>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Applying to study Medicine">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/applyingmed4_3_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/applyingmed4_3_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/applyingmed4_3_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/applyingmed4_3_rdax_450x338.jpg"><source srcset="/img/250x/study/feature-images/applyingmed4_3_rdax_450x338.jpg"><img src="/img/450x/study/feature-images/applyingmed4_3_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Applying to study Medicine</h2>
                        <ul>
<li>About the Medical School and degree programme</li>
<li>Entry Requirements</li>
<li>Application Process</li>
<li>Further information</li>
</ul>                                                    <div class="feature_more">
                                <a href="http://www.abdn.ac.uk/smd/medicine/" target="_blank">Visit the&nbsp;School of Medicine&nbsp;website</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Applying to study Dentistry">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/study/feature-images/suttie_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/study/feature-images/suttie_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/study/feature-images/suttie_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/study/feature-images/suttie_rdax_450x337.jpg"><source srcset="/img/250x/study/feature-images/suttie_rdax_450x337.jpg"><img src="/img/450x/study/feature-images/suttie_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Applying to study Dentistry</h2>
                        <ul>
	<li>About the Institute of Dentistry and degree programme</li>
	<li>Entry Requirements</li>
	<li>Application Process</li>
	<li>Further Information</li>
</ul>                                                    <div class="feature_more">
                                <a href="http://www.abdn.ac.uk/dental/" target="_blank">Find out more about studying Dentistry</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>

<div class="section">
    <div class="container">
    <p>Our staff and students are answering your questions about studying in Aberdeen:</p>

<p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" frameborder="0" height="315" src="https://www.youtube.com/embed/5YCo8gf6eZ8" title="Where Do I Find Entry Requirement Information?" width="560"></iframe></p>

<hr />
<p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" frameborder="0" height="315" src="https://www.youtube.com/embed/3nzWxzeTCrM" title="I Qualify for the REACH/LEAPS Programme. Where Do I Find Further Information?" width="560"></iframe></p>
    </div>
</div>
            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/study/index.php">Study Here</a></li>
            
            <li><a href="/study/undergraduate/index.php">Undergraduate</a></li>
            
            <li><a href="/study/undergraduate/find-a-degree.php" class="current" aria-current="page">Entry Requirements</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/study/undergraduate/widening-access-criteria--2848.php">Widening access criteria</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/study/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

    <script src="https://assets.app.futr.ai/webchat/futrwebchat.js" async></script>
    <script>
        window.futrWebchatSettings = [
            "n51ABtk8MqJ2co59TDT86z", {
                calloutLabel: "University of Aberdeen",
                calloutTitle: "Chat with us!",
                calloutExplainer: ""
            }
        ];
    </script>
    
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                
    <script>
        showHideFAQSetup();
    </script>
        </body>
</html>
