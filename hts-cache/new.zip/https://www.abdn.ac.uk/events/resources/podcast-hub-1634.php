<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Podcast Hub | What's On | The University of Aberdeen</title>
    <!-- Page ID : 1634 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/events/" class="section_head_text">
                    What's On                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="What's On navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/events/listings.php">Events</a>
            </li>
            
            <li>
                <a href="/events/conferences/index.php">Conferences and Short Courses</a>
            </li>
            
            <li>
                <a href="/events/resources/index.php" class="current">Resources and Podcasts</a>
            </li>
            
            <li>
                <a href="/events/uni-versal/index.php">UNI-Versal</a>
            </li>
            
            <li>
                <a href="/events/international-womens-day-1953.php">International Women's Day</a>
            </li>
            
            <li>
                <a href="/events/bhm/index.php">Black History Month</a>
            </li>
            
            <li>
                <a href="/events/pride-month-1692.php">Pride Month</a>
            </li>
            
            <li>
                <a href="/events/mailing-list.php">Mailing List</a>
            </li>
            
            <li>
                <a href="/events/contact.php">Contact</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Podcast Hub</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/events/">What's On</a></li>
            
            <li><a href="/events/resources/index.php">Resources and Podcasts</a></li>
            
            <li tabindex="0" aria-current="page">Podcast Hub</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">Podcast Hub</div>
                        <h2 style="margin-bottom:8pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><font><font><font>Podcasts brought to you by the University of Aberdeen</font></font></font></h2>

<h5 style="margin-bottom:8pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><font><font><font>Please send any&nbsp;podcast enquires to </font></font></font><a href="mailto:podcasts@abdn.ac.uk?subject=Podcast%20enquiry%20(Podcast%20Hub%20Webpage)">podcasts@abdn.ac.uk</a><font><font><font>. </font></font></font></h5>
                        </div>
                    </div>
                    <div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Podcast from the University of Aberdeen">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/Podcast%20hub_rdax_450x450.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/Podcast%20hub_rdax_450x450.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/Podcast%20hub_rdax_450x450.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/Podcast%20hub_rdax_450x450.png"><source srcset="/img/250x/events/feature-images/Podcast%20hub_rdax_450x450.png"><img src="/img/450x/events/feature-images/Podcast%20hub_rdax_450x450.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Podcast from the University of Aberdeen</h2>
                        <p>Check back for more podcasts coming soon.</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: From the Old Brewery">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/From%20the%20Old%20Brewery_rdax_450x450.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/From%20the%20Old%20Brewery_rdax_450x450.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/From%20the%20Old%20Brewery_rdax_450x450.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/From%20the%20Old%20Brewery_rdax_450x450.png"><source srcset="/img/250x/events/feature-images/From%20the%20Old%20Brewery_rdax_450x450.png"><img src="/img/450x/events/feature-images/From%20the%20Old%20Brewery_rdax_450x450.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>From the Old Brewery</h2>
                        <p><span style="line-height:107%">A Podcast series from the PGR Community at the School of Language, Literature, Music, and Visual Culture, University of Aberdeen.</span></p>                                                    <div class="feature_more">
                                <a href="/events/resources/from-the-old-brewery-1859.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: G&agrave;idhlig na Cagailte">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/2.%20Updated%20Podcast%20image%20for%20web_rdax_450x450.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/2.%20Updated%20Podcast%20image%20for%20web_rdax_450x450.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/2.%20Updated%20Podcast%20image%20for%20web_rdax_450x450.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/2.%20Updated%20Podcast%20image%20for%20web_rdax_450x450.png"><source srcset="/img/250x/events/feature-images/2.%20Updated%20Podcast%20image%20for%20web_rdax_450x450.png"><img src="/img/450x/events/feature-images/2.%20Updated%20Podcast%20image%20for%20web_rdax_450x450.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>G&agrave;idhlig na Cagailte</h2>
                        <p style="margin: 0cm 0cm 8pt;"><font color="#000000"><span style="font-family: Calibri;"><font>'S e sreath de ch&ograve;mhraidhean air caochladh chuspairean eadar fileantaich sa Gh&agrave;idhlig a th’ anns a’ phod-chraoladh seo, a bheir taic agus misneachd do luchd-ionnsachaidh adhartach.</font></span></font></p>                                                    <div class="feature_more">
                                <a href="http://www.abdn.ac.uk/gaidhlig-na-cagailte">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Accounting for Sustainability">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/GBS%20Podcast%202500x2500%20KL_1121_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/GBS%20Podcast%202500x2500%20KL_1121_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/GBS%20Podcast%202500x2500%20KL_1121_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/GBS%20Podcast%202500x2500%20KL_1121_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/GBS%20Podcast%202500x2500%20KL_1121_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/GBS%20Podcast%202500x2500%20KL_1121_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Accounting for Sustainability</h2>
                        <p style="margin-bottom:8pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:107%">Join </span>Dr. Thereza Raquel Sales de Aguiar&nbsp;<span style="line-height:107%">as she interviews fellow academics, environmentalists and careers specialists on the future sustainability of accounting and what this means for the next generation of accountants and business leaders.</span></p>                                                    <div class="feature_more">
                                <a href="/events/resources/accounting-for-sustainability-1837.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Ask Aberdeen">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/Ask%20Aberdeen%20180x180%20thumbnail-01_rdax_450x451.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/Ask%20Aberdeen%20180x180%20thumbnail-01_rdax_450x451.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/Ask%20Aberdeen%20180x180%20thumbnail-01_rdax_450x451.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/Ask%20Aberdeen%20180x180%20thumbnail-01_rdax_450x451.png"><source srcset="/img/250x/events/feature-images/Ask%20Aberdeen%20180x180%20thumbnail-01_rdax_450x451.png"><img src="/img/450x/events/feature-images/Ask%20Aberdeen%20180x180%20thumbnail-01_rdax_450x451.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Ask Aberdeen</h2>
                        <p>Thinking about applying to university?<br />
Join our hosts as they interview students and staff alike, asking the questions you want to hear answers to, and find out more about the University of Aberdeen.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/ask-aberdeen.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Celebrating Women in Engineering ">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/Women%20in%20Engineering%20square%20pic_rdax_450x449.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/Women%20in%20Engineering%20square%20pic_rdax_450x449.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/Women%20in%20Engineering%20square%20pic_rdax_450x449.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/Women%20in%20Engineering%20square%20pic_rdax_450x449.jpg"><source srcset="/img/250x/events/feature-images/Women%20in%20Engineering%20square%20pic_rdax_450x449.jpg"><img src="/img/450x/events/feature-images/Women%20in%20Engineering%20square%20pic_rdax_450x449.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Celebrating Women in Engineering </h2>
                        <p style="margin: 0cm 0cm 8pt;"><font><font><font>Celebrating International&nbsp;Women in Engineering Day - 23 June</font></font></font></p>                                                    <div class="feature_more">
                                <a href="/events/resources/celebrating-women-in-engineering-1700.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Culture in Everyday Life">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/EI%20PODCAST%20Thumb%20image%20square_rdax_450x450.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/EI%20PODCAST%20Thumb%20image%20square_rdax_450x450.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/EI%20PODCAST%20Thumb%20image%20square_rdax_450x450.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/EI%20PODCAST%20Thumb%20image%20square_rdax_450x450.png"><source srcset="/img/250x/events/feature-images/EI%20PODCAST%20Thumb%20image%20square_rdax_450x450.png"><img src="/img/450x/events/feature-images/EI%20PODCAST%20Thumb%20image%20square_rdax_450x450.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Culture in Everyday Life</h2>
                        <p>The series features lectures from the Elphinstone Institute Archives delivered by scholars working in the fields of Ethnology,&nbsp;Folklore, and Ethnomusicology.&nbsp;</p>                                                    <div class="feature_more">
                                <a href="/events/resources/culture-in-everyday-life-1668.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Breaking the Ice Ceiling">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/ice2.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/ice2.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/ice2.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/ice2.png"><source srcset="/img/250x/events/feature-images/ice2.png"><img src="/img/450x/events/feature-images/ice2.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Breaking the Ice Ceiling</h2>
                        <p>Breaking the Ice Ceiling is a podcast of conversations with women changing the world, hosted by <span style="text-transform: none; text-indent: 0px; letter-spacing: normal; font-style: normal; font-weight: 400; word-spacing: 0px; float: none; display: inline !important; white-space: normal; orphans: 2; widows: 2; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Geologist</span> Dr Clare Bond.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/breaking-the-ice-ceiling-1675.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Caf&eacute; Connect">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/CAFE%20CONNECT%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/CAFE%20CONNECT%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/CAFE%20CONNECT%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/CAFE%20CONNECT%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/CAFE%20CONNECT%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/CAFE%20CONNECT%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Caf&eacute; Connect</h2>
                        <p>Caf&eacute; Connect brings you the latest research from the University of Aberdeen. In this podcast series we meet different researchers who will talk about their work and its relevance to our everyday lives.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/cafe-connect-1650.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Worship from Kings College Chapel">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/WORSHIP%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/WORSHIP%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/WORSHIP%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/WORSHIP%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/WORSHIP%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/WORSHIP%20PODCAST%20THUMB%20IMAGE%20SQUARE_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Worship from Kings College Chapel</h2>
                        <p>A series of short meditative worship services recorded in Kings College Chapel at the University of Aberdeen.&nbsp;</p>                                                    <div class="feature_more">
                                <a href="/events/resources/worship-from-kings-college-chapel-1651.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Rowett Conversations">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/Rowett%20and%20lavender_extended%20No%20lamp%20facebook_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/Rowett%20and%20lavender_extended%20No%20lamp%20facebook_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/Rowett%20and%20lavender_extended%20No%20lamp%20facebook_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/Rowett%20and%20lavender_extended%20No%20lamp%20facebook_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/Rowett%20and%20lavender_extended%20No%20lamp%20facebook_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/Rowett%20and%20lavender_extended%20No%20lamp%20facebook_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Rowett Conversations</h2>
                        <p>Following International Women’s day 2021,&nbsp;three of the first women professors at the Institute share their career journey to&nbsp;becoming experts in their fields and how you can pursue a career in science.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/rowett-conversations-1653.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: 525 Years in the Pursuit of Truth">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/DSC_1659_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/DSC_1659_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/DSC_1659_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/DSC_1659_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/DSC_1659_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/DSC_1659_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>525 Years in the Pursuit of Truth</h2>
                        <p>In celebration of the 525th year since its founding in 1495, we explore the fascinating history of the University of Aberdeen.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/525-years-in-the-pursuit-of-truth-a-new-history-of-the-university-of-aberdeen-1654.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Explorathon Research Lunch Bytes">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/Square%20orion-nebula-11107_1920_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/Square%20orion-nebula-11107_1920_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/Square%20orion-nebula-11107_1920_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/Square%20orion-nebula-11107_1920_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/Square%20orion-nebula-11107_1920_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/Square%20orion-nebula-11107_1920_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Explorathon Research Lunch Bytes</h2>
                        <p>Take a break and listen to talks about the latest research projects coming from the University of Aberdeen. This podcast series&nbsp;was part of European Researchers' Night 2020.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/explorathon-1676.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: BeWell">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/BeWell%20Podcast%20Series%20-No%20text_rdax_450x450.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/BeWell%20Podcast%20Series%20-No%20text_rdax_450x450.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/BeWell%20Podcast%20Series%20-No%20text_rdax_450x450.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/BeWell%20Podcast%20Series%20-No%20text_rdax_450x450.jpg"><source srcset="/img/250x/events/feature-images/BeWell%20Podcast%20Series%20-No%20text_rdax_450x450.jpg"><img src="/img/450x/events/feature-images/BeWell%20Podcast%20Series%20-No%20text_rdax_450x450.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>BeWell</h2>
                        <p>The BeWell Podcast series will focus on a variety of topical wellbeing issues based on identified student pressure points and national health and wellbeing campaigns.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/bewell-1649.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Beyond COP26: Lessons from South Africa">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/Beyond%20Cop26%20Podcast_Podcast%20Square.png"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/Beyond%20Cop26%20Podcast_Podcast%20Square.png"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/Beyond%20Cop26%20Podcast_Podcast%20Square.png"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/Beyond%20Cop26%20Podcast_Podcast%20Square.png"><source srcset="/img/250x/events/feature-images/Beyond%20Cop26%20Podcast_Podcast%20Square.png"><img src="/img/450x/events/feature-images/Beyond%20Cop26%20Podcast_Podcast%20Square.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Beyond COP26: Lessons from South Africa</h2>
                        <p>This work reflects on COP 26 and explore the role of participatory action research in addressing water challenges in rural communities.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/participatory-water-governance-in-south-africa-2299.php">Listen now</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: AMND in Focus">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/events/feature-images/AMND-in-Focus-450x450px.jpg"><source media="(min-width: 640px)" srcset="/img/450x/events/feature-images/AMND-in-Focus-450x450px.jpg"><source media="(min-width: 481px)" srcset="/img/200x/events/feature-images/AMND-in-Focus-450x450px.jpg"><source media="(min-width: 251px)" srcset="/img/450x/events/feature-images/AMND-in-Focus-450x450px.jpg"><source srcset="/img/250x/events/feature-images/AMND-in-Focus-450x450px.jpg"><img src="/img/450x/events/feature-images/AMND-in-Focus-450x450px.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>AMND in Focus</h2>
                        <p>A podcast collaboration between the University of Aberdeen and the Aberdeen Maternity and Neonatal Databank&nbsp;aiming to act as an educational resource.</p>                                                    <div class="feature_more">
                                <a href="/events/resources/amnd-in-focus.php">Listen to the AMND podcast</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/events/index.php">What's On</a></li>
            
            <li><a href="/events/resources/index.php">Resources and Podcasts</a></li>
            
            <li><a href="/events/resources/podcast-hub-1634.php" class="current" aria-current="page">Podcast Hub</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/events/resources/bewell-1649.php">BeWell</a></li>
                
                <li><a href="/events/resources/cafe-connect-1650.php">Café Connect</a></li>
                
                <li><a href="/events/resources/worship-from-kings-college-chapel-1651.php">Worship from Kings College Chapel</a></li>
                
                <li><a href="/events/resources/rowett-conversations-1653.php">Rowett Conversations</a></li>
                
                <li><a href="/events/resources/525-years-in-the-pursuit-of-truth-a-new-history-of-the-university-of-aberdeen-1654.php">525 Years in the Pursuit of Truth:  A New History of The University of Aberdeen</a></li>
                
                <li><a href="/events/resources/culture-in-everyday-life-1668.php">Culture in Everyday Life</a></li>
                
                <li><a href="/events/resources/breaking-the-ice-ceiling-1675.php">Breaking the Ice Ceiling</a></li>
                
                <li><a href="/events/resources/explorathon-1676.php">Explorathon</a></li>
                
                <li><a href="/events/resources/ask-aberdeen.php">Ask Aberdeen</a></li>
                
                <li><a href="/events/resources/celebrating-women-in-engineering-1700.php">Celebrating Women in Engineering</a></li>
                
                <li><a href="/events/resources/accounting-for-sustainability-1837.php">Accounting for Sustainability</a></li>
                
                <li><a href="/events/resources/from-the-old-brewery-1859.php">From the Old Brewery</a></li>
                
                <li><a href="/events/resources/amnd-in-focus.php">AMND in Focus</a></li>
                
                <li><a href="/events/resources/participatory-water-governance-in-south-africa-2299.php">Beyond COP26: Lessons from South Africa on water and community health</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/events/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
