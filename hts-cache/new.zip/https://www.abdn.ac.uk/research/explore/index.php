<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Explore our Research | Research | The University of Aberdeen</title>
    <!-- Page ID : 548 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/tabcordion.css?cb=20221026" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/research/" class="section_head_text">
                    Research                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="Research navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/research/explore/index.php" class="current">Explore our Research</a>
            </li>
            
            <li>
                <a href="/research/impact/index.php">Impact</a>
            </li>
            
            <li>
                <a href="/research/institutes-centres/index.php">Institutes and Centres</a>
            </li>
            
            <li>
                <a href="/research/facilities/index.php">Facilities</a>
            </li>
            
            <li>
                <a href="/research/support/index.php">Support</a>
            </li>
            
            <li>
                <a href="/research/jobs/index.php">Jobs</a>
            </li>
            
            <li>
                <a href="/research/cop26.php">COP26</a>
            </li>
            
            <li>
                <a href="/research/ref-2021.php">REF 2021</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Explore our Research</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/research/">Research</a></li>
            
            <li tabindex="0" aria-current="page">Explore our Research</li>
                </ol>
</div>

        </div>
    </div><style>
@media screen and (min-width: 1200px) {
    .hero_header.has_full_image {
        background-image: url('/img/2000x/research/feature-images/Gold%2032-9.jpg');
    }
}
</style>

<div class="hero_header theme_velvet_dark  has_full_image">
    <div class="hero_header_inner">
                <div class="hero_header_image_area" style="background-image: url('/img/1200x/research/feature-images/Gold%2016-9.jpg')"></div>
        
        <div class="hero_header_text_area">
            <div class="hero_container">

                
                <h2>Where great minds solve world challenges</h2>
                
                                <div class="btn-group">
                                        </div>
                            </div>
        </div>
    </div>
</div>
    </header>

<main id="main" class="full_width has_hero_header" tabindex="-1">
    
        <div class="section">
          <div class="container">
        
            <div class="h1">Explore our Research</div>
            <p>Our research is where great minds work together. It is challenge-led and impactful, and often requires&nbsp;an interdisciplinary approach to address the great research challenges of our age: energy transition, social inclusion and cultural diversity, data and artificial intelligence, environment and biodiversity, and health, nutrition and wellbeing.</p>

<p>These interdisciplinary challenges represent research areas of historic and emerging excellence that are capable of supporting a diverse research portfolio and delivering globally excellent and measurable benefits to society, the economy and health. Additionally, these&nbsp;challenges&nbsp;reflect the work we do in supporting the UN’s <a href="https://www.abdn.ac.uk/about/sustainable/index.php">Sustainable&nbsp;Development Goals</a> in partnership with a range of stakeholders.</p>
            </div>
        </div>
        <div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Interdisciplinary Research Projects Database">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/research/feature-images/research2_rdax_450x300.jpg"><source media="(min-width: 640px)" srcset="/img/450x/research/feature-images/research2_rdax_450x300.jpg"><source media="(min-width: 481px)" srcset="/img/200x/research/feature-images/research2_rdax_450x300.jpg"><source media="(min-width: 251px)" srcset="/img/450x/research/feature-images/research2_rdax_450x300.jpg"><source srcset="/img/250x/research/feature-images/research2_rdax_450x300.jpg"><img src="/img/450x/research/feature-images/research2_rdax_450x300.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Interdisciplinary Research Projects Database</h2>
                        <p>One of the main strands of our&nbsp;<a href="https://www.abdn.ac.uk/2040/">Aberdeen 2040</a>&nbsp;plan is to address urgent and wide-ranging challenges in the interdisciplinary areas of Energy Transition;&nbsp;Social Inclusion and Cultural Diversity;&nbsp;Environment and Biodiversity;&nbsp;Data and Artificial Intelligence;&nbsp;and Health, Nutrition and Wellbeing.</p>

<p>In this new database, you can explore&nbsp;some of the fascinating and wide-ranging early-stage research being funded in these critical areas.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/research/explore/projects/">Explore the database</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>

    <div class="section stats_section theme_dark_grey stats_have_image" style="background-image: url(/img/2000x/research/feature-images/research-stats-background.jpg);">
        <div class="container">
    <h2 class="optional_heading">Our Interdisciplinary Challenges</h2>
    <div class="stats_wrapper">
    
            <a href="/research/explore/energy-transition-573.php" class="stat">
            
            <div class="stat_teaser">Energy Transition</div>
            
            <div class="stat_highlight">
            
                <img src="/research/feature-images/energy_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_heading">Leading energy transition</div>
            
            <div class="stat_content"><p>For more than 40 years we've combined our academic excellence with industry expertise, to innovate and positively affect the future of global energy.</p></div>
            
            </a>
            
            <a href="/research/explore/social-inclusion-577.php" class="stat">
            
            <div class="stat_teaser">Social Inclusion and Cultural Diversity</div>
            
            <div class="stat_highlight">
            
                <img src="/research/feature-images/group_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_heading">Heritage and culture</div>
            
            <div class="stat_content"><p>In a rapidly changing world, we aim to be open to other perspectives and understand how culture and diversity shape human experience.</p></div>
            
            </a>
            
            <a href="/research/explore/environment-biodiversity-574.php" class="stat">
            
            <div class="stat_teaser">Environment and Biodiversity</div>
            
            <div class="stat_highlight">
            
                <img src="/research/feature-images/environment_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_heading">Nature on our doorstep</div>
            
            <div class="stat_content"><p>By making the most of our proximity to nature, our researchers are addressing major environmental challenges both close to home and far afield.</p></div>
            
            </a>
            
            <a href="/research/explore/data-ai-572.php" class="stat">
            
            <div class="stat_teaser">Data and Artificial Intelligence</div>
            
            <div class="stat_highlight">
            
                <img src="/research/feature-images/Ai_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_heading">Anticipating the future</div>
            
            <div class="stat_content"><p>We have carried out research in data science and AI for more than 30 years, discovering new ways to improve health and daily life with this technology.</p></div>
            
            </a>
            
            <a href="/research/explore/health-nutrition-576.php" class="stat">
            
            <div class="stat_teaser">Health, Nutrition and Wellbeing</div>
            
            <div class="stat_highlight">
            
                <img src="/research/feature-images/health_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_heading">500 years of advancing health</div>
            
            <div class="stat_content"><p>Our interdisciplinary strengths, healthcare expertise and industry collaborations underpin our commitment to addressing major health challenges with our research.</p></div>
            
            </a>
            
            </div>
        </div>
    </div>
    <div class="section">
  <div class="container">
          <h2 class="optional_heading">Interdisciplinary Research Directors</h2>          <div class="tabs_wrapper">
              <section id="tab_group_791" class="tab_group">
                  <dl class="accordion tabcordion" data-tabcordion='{"urlFragments" : true, "forceAccordion" : true, "openFirstPanel" : false}'>
  
          <dt>
              <a href="#panel907">David Burslem - Director of the Interdisciplinary Centre for Environment and Biodiversity</a>
          </dt>
          <dd id="panel907">
          <p><picture class="imgproxy" style="float:left; margin-left:5px; margin-right:5px"><source media="(min-width: 1200px)" srcset="/img/1200x/research/content-images/DavidBurslem2.jpg"><source media="(min-width: 720px)" srcset="/img/1200x/research/content-images/DavidBurslem2.jpg"><source media="(min-width: 481px)" srcset="/img/780x/research/content-images/DavidBurslem2.jpg"><source media="(min-width: 251px)" srcset="/img/481x/research/content-images/DavidBurslem2.jpg"><source srcset="/img/200x/research/content-images/DavidBurslem2.jpg"><img src="/img/1200x/research/content-images/DavidBurslem2.jpg" alt="" width="350" height="350" loading="lazy"></picture>David Burslem is an inter-disciplinary ecologist and conservation biologist interested in research that addresses the maintenance of ecosystems with high biodiversity and ecological functioning in the face of global change. He joined the University of Aberdeen in 1995 following undergraduate and PhD training in biological sciences at the Universities of Oxford and Cambridge. He was appointed to a personal chair in the School of Biological Sciences in 2013, Keeper of the Cruickshank Botanic Garden in 2016 and Interdisciplinary Director for Environment and Biodiversity in 2022. He has held appointments as Councillor and Trustee of the British Ecological Society, Vice-President of the Botanical Society of Scotland and editorial roles on Journal of Ecology, Plant Ecology and Diversity, and Ecological Reviews. He currently serves as a trustee of the Scottish Forestry Trust and on the advisory group of the Northeast Scotland Biological Records Centre (NESBREC).</p>

<p>David’s research has focussed on the generation and maintenance of biodiversity in ecological communities, ranging from fundamental studies of tropical plant evolution to analyses that generate the evidence base for interventions in species conservation and ecosystem management. Most of his research has been conducted within an inter-disciplinary framework that involves collaborations with partners in government, non-governmental organisations, and industry. Recent highlights include high-profile research demonstrating the importance of active interventions to restore tropical forests as reservoirs of carbon, and biodiversity studies contributing to the formal protection of more than 300,000 hectares of forest in Borneo. David’s research group has been funded continuously by UK research councils, European Union, charitable trusts and industrial partners for more than 25 years.</p>

<blockquote>
<p>“The inter-related crises of biodiversity loss and climate change threaten planetary life-support systems, including the capacity of environments to deliver safe and affordable amounts of food, clean air and space for people and nature to coexist.”</p>

<p>“The solutions to these problems will require research across traditional disciplinary boundaries, and active engagement between academic communities and external partners to their real-world applicability.”</p>

<p>“The University of Aberdeen has a long track-record of world-leading research on biodiversity and environmental sustainability, which is reflected in the commitments to the UN Sustainable Development Goals that are embedded in Aberdeen 2040.”</p>

<p>“I am delighted to be working alongside colleagues at the University and our external partners to facilitate the coordination and expansion of our interdisciplinary teaching and research on environment and biodiversity.”</p>
</blockquote>
          </dd>
          
          <dt>
              <a href="#panel792">John Underhill - Director of the Interdisciplinary Centre for Energy Transition</a>
          </dt>
          <dd id="panel792">
          <p><picture class="imgproxy" style="float:left; margin-left:5px; margin-right:5px"><source media="(min-width: 1200px)" srcset="/img/1200x/research/content-images/John_Underhill.jpg"><source media="(min-width: 720px)" srcset="/img/1200x/research/content-images/John_Underhill.jpg"><source media="(min-width: 481px)" srcset="/img/780x/research/content-images/John_Underhill.jpg"><source media="(min-width: 251px)" srcset="/img/481x/research/content-images/John_Underhill.jpg"><source srcset="/img/200x/research/content-images/John_Underhill.jpg"><img src="/img/1200x/research/content-images/John_Underhill.jpg" width="350" height="350" alt="Photo of John Underhill" loading="lazy"></picture>John Underhill is the Academic Executive Director of the UK Centre for Doctoral Training (CDT) entitled GeoNetZero (GNZ).&nbsp; Supported by UK Research and Innovation (UKRI), the latter is a &pound;5M industry-academic collaboration between 12 Universities and 8 industry partners that is exploring the role of Geoscience for the Low Carbon Energy Transition and Challenge to meet Net Zero emission targets.</p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">He has been the recipient of numerous awards including the Geological Society’s Lyell Medal Silver Medal of the Geological Society’s Energy Group, the Clough Medal of the Edinburgh Geological Society, and European Association of Geoscientists and Engineers (EAGE) Alfred Wegener and Distinguished Lecturer Awards and the American Association of Petroleum Geologists (AAPG) George C. Matson, Grover E. Murray Distinguished Educator, and Ziad Beydoun awards.&nbsp; </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">He was President of the European Association of Geoscientists &amp; Engineers (EAGE) in 2011-12. John has previously held professorial posts at The University of Edinburgh and Heriot Watt University, where he was their Chief Scientist. John was also a member of the UK Energy Minister's Technology Leadership Board (TLB) and currently populates the UK Exploration Task Force (XTF) and the Scottish Government’s Science Advisory Council (SSAC). </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">Away from academic life, John was a professional football referee on the FIFA circuit, which saw him officiate on European Champions League, internationals and Scottish Premier League games including those at Pittodrie, between 1994-2008.</span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">&nbsp;</p>

<blockquote>
<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“The Energy Transition is one of the most significant global challenges that we face. Put simply, how do we ensure the lights remain on, domestic energy supplies continue, and heating needs are met whilst simultaneously decarbonising industry, transport and other sectors?</span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“It is a privilege to have the opportunity to join the University of Aberdeen as Director of the Interdisciplinary Centre for Energy Transition and lead its efforts to address, critically evaluate and seek the right solutions that ensure we retain energy supply as we decarbonise. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“I see the Centre being a catalyst for change whereby the University can draw and build upon its expertise, collaborate across the research and training landscape and partner with Industry, Government and other stakeholders in the local, national and international communities.</span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“Having been pivotal for the energy industry and wealth creation and quality of life that the UK has enjoyed over the past half century, the city of Aberdeen and greater north east region is uniquely placed to help shape and deliver the transition that it is required. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“I am absolutely delighted to take on this leadership role at such an esteemed University, and look forward to working towards the goal of a just, fair and affordable transition that protects jobs and livelihoods on the journey to meet net zero emission targets.”</span></p>
</blockquote>
          </dd>
          
          <dt>
              <a href="#panel793">Eleonora Belfiore - Director of the Interdisciplinary Centre for Social Inclusion and Cultural Diversity</a>
          </dt>
          <dd id="panel793">
          <p><picture class="imgproxy" style="float:left; margin-left:5px; margin-right:5px"><source media="(min-width: 1200px)" srcset="/img/1200x/research/content-images/Eleonora_Belfiore.jpg"><source media="(min-width: 720px)" srcset="/img/1200x/research/content-images/Eleonora_Belfiore.jpg"><source media="(min-width: 481px)" srcset="/img/780x/research/content-images/Eleonora_Belfiore.jpg"><source media="(min-width: 251px)" srcset="/img/481x/research/content-images/Eleonora_Belfiore.jpg"><source srcset="/img/200x/research/content-images/Eleonora_Belfiore.jpg"><img src="/img/1200x/research/content-images/Eleonora_Belfiore.jpg" width="350" height="350" alt="Photo of Eleonora Belfiore" loading="lazy"></picture><span style="line-height:115%">Eleonora Belfiore joins Aberdeen from Loughborough University, where she was Professor of Communication and Media Studies and Co-Director of the Centre for Research in Communication and Culture, having previously been Reader in Cultural Policy Studies at Warwick University. She has published extensively on cultural politics and policy, and particularly the place that notions of the ‘social impacts’ of the arts have had in British cultural policy discourses. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">She is one of the world leading scholars in cultural value research, and was Co-Director of Studies of the Warwick Commission on the Future of Cultural Value (2013-5), and co-author of its influential final report, Enriching Britain: Culture, creativity and growth, published in February 2015. For Palgrave, she edits the book series New Directions in Cultural Policy Research, which has published 16 volumes to date, and she is Co-Editor in Chief journal Cultural Trends. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">Eleonora is developing new research on the labour conditions of socially engaged arts practice supported by a British Academy/Leverhulme grant. She is also Co-investigator in a project on the creative industries and development in Ghana funded by Danida, the Danish International Development Agency. Eleonora is committed to the promotion of equality, diversity and inclusion in Higher Education, and she is one of the founding members of the Women In Academia Support Network, a trans-inclusive and intersectional charity that brings together over 12,000 women and non-binary members from across the world to support one another and pushes for gender parity and more equitable working conditions in Higher Education.</span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">&nbsp;</p>

<blockquote>
<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“I am absolutely thrilled to join the University of Aberdeen at such an exciting point in the development of its new research vision and strategy. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“The establishment of five ambitious, interdisciplinary research centres to deal with the great challenges that face the world, our climate, our economy and our society as we slowly begin to emerge from a long pandemic is a bold and important move. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“I feel privileged to be part of this vision, and to lead the Interdisciplinary Centre for Social Inclusion and Cultural Diversity, working with colleagues across the University to realise the potential of the Arts, Humanities and Social Sciences to lead to progressive change in our society. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“As a scholar passionate about the connection between culture, society and public policy, the focus of the Centre on inclusion and diversity is a perfect match for the values that have driven my work to date. </span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><span style="line-height:115%">“I look forward to the opportunity to position the Centre as an internationally recognised home for interdisciplinary, co-produced and society oriented research that aspires to create social change in collaboration with local, national and international partners.”</span></p>
</blockquote>
          </dd>
          
          <dt>
              <a href="#panel794">Georgios Leontidis - Director of the Interdisciplinary Centre for Data and Artificial Intelligence</a>
          </dt>
          <dd id="panel794">
          <p><picture class="imgproxy" style="float:left; margin-left:5px; margin-right:5px"><source media="(min-width: 1200px)" srcset="/img/1200x/research/content-images/Georgios_Leontidis.jpg"><source media="(min-width: 720px)" srcset="/img/1200x/research/content-images/Georgios_Leontidis.jpg"><source media="(min-width: 481px)" srcset="/img/780x/research/content-images/Georgios_Leontidis.jpg"><source media="(min-width: 251px)" srcset="/img/481x/research/content-images/Georgios_Leontidis.jpg"><source srcset="/img/200x/research/content-images/Georgios_Leontidis.jpg"><img src="/img/1200x/research/content-images/Georgios_Leontidis.jpg" width="350" height="350" alt="Photo of Georgios Leontidis" loading="lazy"></picture><span style="line-height:115%">Georgios is a TEDx speaker, an Engineer and Computer Scientist and holds MSc and PhD degrees in Machine Learning. He joined the University of Aberdeen in March 2020, after spending several years at the University of Lincoln’s School of Computer Science. While at Lincoln he held several internal roles and positions and played an instrumental role in enhancing the reputation of the School and expanding the Machine Learning Research Group, via attracting prestigious grants and studentships. Georgios also spent time in industry working as a Senior Data Scientist in IBA Dosimetry GmbH in Germany.&nbsp;</span></p>

<p><span style="line-height:115%">Georgios has been conducting world-leading activity on foundational elements of Machine Learning for more than a decade, being active in the international community both as an author and senior programme committee for flagship AI venues including NeurIPS, AAAI and IJCAI. &nbsp;Alongside his core discipline research activities on deep learning, capsule neural networks, domain adaptation, and self-supervised learning, Georgios has been conducting cutting-edge research across several interdisciplinary applications, such as agri-food on soft-fruit yield forecasting, data sharing, and supply chain optimisation, nuclear reactor perturbation analysis and anomaly detection, gas turbine availability, medical image analysis, intelligent refrigeration systems optimisation, environmental data imputation, computer vision, etc, all of which have received funding from several sources including EPSRC, NERC, EU-FP7, EU-H2020, Innovate UK, and industry.&nbsp;</span></p>

<p><span style="line-height:115%">A member of the Full Peer Review College of EPSRC, and a Panel College member of the UKRI Future Leaders Fellow, Georgios was invited and participated in AI workshops organised by UKRI as part of its AI review exercise and was a member of the UK AI council’s data sharing working group. He recently co-organised with SICSA a pan-Scotland AI all-hands event and has been supporting several aspects of the development of Scotland’s AI playbook. He is currently a Senior Expert with the NERC Constructing a Digital Environment Expert Network and his recent TEDx talk focused on how Data &amp; AI can help our sustainable future.</span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">&nbsp;</p>

<blockquote>
<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“Data and Artificial Intelligence (AI) technologies are uniquely placed to provide solutions to complex societal challenges requiring interdisciplinary approaches spanning multiple disciplines – from computer science and engineering, to social sciences, psychology, business, healthcare and education.&nbsp;</span></em></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“Developing well-performing, fair, trustworthy and cyber-secure AI systems with a proper governance structure and a suitable policy framework, while dealing with vast amount of multimodal data, remains an open and multi-faceted challenge that is highly underestimated.&nbsp;</span></em></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“Through its Aberdeen 2040 strategy, the University is well placed to use its remarkable amount of academic expertise working across various areas of AI to play a major role in responding to societal challenges with effective solutions, and to supporting national AI strategies.&nbsp;</span></em></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“Establishing the University as a world-leading Data &amp; AI research and innovation hub requires a collective, transparent and participatory approach, and my main priority is to create a vibrant and supportive environment for active interdisciplinary research. &nbsp;I would encourage both academic and professional services staff at the University to actively engage in our activities.”</span></em></p>
</blockquote>
          </dd>
          
          <dt>
              <a href="#panel795">Jennie Macdiarmid - Director of the Interdisciplinary Centre for Health, Nutrition and Wellbeing</a>
          </dt>
          <dd id="panel795">
          <p><picture class="imgproxy" style="float:left; margin-left:5px; margin-right:5px"><source media="(min-width: 1200px)" srcset="/img/1200x/research/content-images/Jennie_Macdiarmid_crop_22.jpg"><source media="(min-width: 720px)" srcset="/img/1200x/research/content-images/Jennie_Macdiarmid_crop_22.jpg"><source media="(min-width: 481px)" srcset="/img/780x/research/content-images/Jennie_Macdiarmid_crop_22.jpg"><source media="(min-width: 251px)" srcset="/img/481x/research/content-images/Jennie_Macdiarmid_crop_22.jpg"><source srcset="/img/200x/research/content-images/Jennie_Macdiarmid_crop_22.jpg"><img src="/img/1200x/research/content-images/Jennie_Macdiarmid_crop_22.jpg" width="350" height="350" alt="Photo of Jennie Macdiarmid" loading="lazy"></picture><span style="line-height:115%">Jen</span><span style="line-height:115%">nie g</span><span style="line-height:115%">ained a BSc (Hons) Nutrition and Food Science degree from the University of Surrey and went on to complete a PhD in psychology and dietary habits at the University of Leeds. After her PhD she worked for the International Obesity Task Force before joining The Rowett Institute at the University of Aberdeen. </span></p>

<p><span style="line-height:115%">While at the Rowett she conducted research on public health nutrition and policy before going on to develop a new interdisciplinary area of research, bringing together nutrition and climate change to understand the principles of healthy diets with low greenhouse gas emissions. </span></p>

<p><span style="line-height:115%">She published the first paper in this area, which stimulated the debate among governments, industry and NGOs. In 2017 she was awarded a chair in Sustainable Nutrition and Health. Throughout her career she has worked across disciplines and in recognition of her work in 2021 she was awarded the Prize for Excellence in Interdisciplinary</span><span style="line-height:115%"> Research.</span></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm">&nbsp;</p>

<blockquote>
<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“I am very excited about my new post as the Director of the Interdisciplinary Centre for Health, Nutrition and Wellbeing. </span></em></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“Many of the greatest challenges facing the world today need multiple disciplines to work together to find solutions and the centre can support this type of research. My aim is to help create new, as well as support existing, interdisciplinary projects and introduce it into teaching across the University. </span></em></p>

<p style="margin-bottom:10pt; margin-left:0cm; margin-right:0cm; margin-top:0cm"><em><span style="line-height:115%">“Working together with the directors of the other interdisciplinary centres we will stimulate new exciting collaborations and help train the next generation of researcher in interdisciplinary approaches to address important questions.”</span></em></p>
</blockquote>
          </dd>
                            </dl>
              </section>
          </div>
      </div>
</div><div class="section">
    <div class="container">
                <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Find a Researcher">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/research/feature-images/researcher_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/research/feature-images/researcher_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/research/feature-images/researcher_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/research/feature-images/researcher_rdax_450x338.jpg"><source srcset="/img/250x/research/feature-images/researcher_rdax_450x338.jpg"><img src="/img/450x/research/feature-images/researcher_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Find a Researcher</h2>
                        <p>Search for one of our subject experts.</p>                                                    <div class="feature_more">
                                <a href="https://abdn.pure.elsevier.com/en/persons/">Find a researcher</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Research History">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/research/feature-images/Research%20History_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/research/feature-images/Research%20History_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/research/feature-images/Research%20History_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/research/feature-images/Research%20History_rdax_450x337.jpg"><source srcset="/img/250x/research/feature-images/Research%20History_rdax_450x337.jpg"><img src="/img/450x/research/feature-images/Research%20History_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Research History</h2>
                        <p>Learn more about our Nobel Prizes, notable academics and some of our research highlights through the centuries.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/stories/research-history/index.html">Research history</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: REF">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/research/feature-images/REF%202014_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/research/feature-images/REF%202014_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/research/feature-images/REF%202014_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/research/feature-images/REF%202014_rdax_450x338.jpg"><source srcset="/img/250x/research/feature-images/REF%202014_rdax_450x338.jpg"><img src="/img/450x/research/feature-images/REF%202014_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>REF</h2>
                        <p><span style="line-height:107%">The Research Excellence Framework (REF) assesses the quality of research of all UK higher education institutions.</span></p>                                                    <div class="feature_more">
                                <a href="/research/ref-2021.php">Research Excellence Framework</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Research Portal">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/research/feature-images/research-portal_rdax_450x244.jpg"><source media="(min-width: 640px)" srcset="/img/450x/research/feature-images/research-portal_rdax_450x244.jpg"><source media="(min-width: 481px)" srcset="/img/200x/research/feature-images/research-portal_rdax_450x244.jpg"><source media="(min-width: 251px)" srcset="/img/450x/research/feature-images/research-portal_rdax_450x244.jpg"><source srcset="/img/250x/research/feature-images/research-portal_rdax_450x244.jpg"><img src="/img/450x/research/feature-images/research-portal_rdax_450x244.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Research Portal</h2>
                        <p>Explore our researchers' networks, output, datasets and activities in our dedicated research portal.</p>                                                    <div class="feature_more">
                                <a href="http://abdn.pure.elsevier.com/en/">Explore the&nbsp;Pure research portal</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                 <div class="feature_3ascii_code">
            <aside class="feature_box">
                
<h2 class="motif">Events</h2>

		<p>There are currently no upcoming Events.</p>
		<p>If you'd like to keep up-to-date with all our events, subscribe to our RSS feed!</p>
		            </aside>
            <aside class="feature_box">
                
<h2 class="motif">News</h2>

        <ul class="syndicated">
        
            <li>
                <a href="/research/explore/news/16464/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/MRI_patient2.jpg" width="50" alt="">
                    <h3>New MRI dementia test to be trialled for first time</h3>
                </a>
            </li>
            
            <li>
                <a href="/research/explore/news/16460/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Geothermal_lake.JPG" width="50" alt="">
                    <h3>A cold fish won't give you the cold shoulder</h3>
                </a>
            </li>
            
            <li>
                <a href="/research/explore/news/16457/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Motor_Neuron_Disease.jpg" width="50" alt="">
                    <h3>Gut could sound early warning alarm for motor neuron disease</h3>
                </a>
            </li>
            
            <li>
                <a href="/research/explore/news/16451/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Missing_persons_poster_resized.jpg" width="50" alt="">
                    <h3>Research underway to improve missing person identification</h3>
                </a>
            </li>
            
            <li>
                <a href="/research/explore/news/16447/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/medical_science_experiment_1x1.jpg" width="50" alt="">
                    <h3>University partners new research initiative</h3>
                </a>
            </li>
            
        </ul>
        <div class="feature_more">
            <a href="/research/explore/news/">
                More News
            </a>
        </div>
                    </aside>
            <aside class="feature_box">
                <a class="twitter-timeline" data-height="500" href="https://twitter.com/UoAInnovate">Tweets by UoAInnovate</a>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>            </aside>
        </div>
    </div>
</div>

<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/research/index.php">Research</a></li>
            
            <li><a href="/research/explore/index.php" class="current" aria-current="page">Explore our Research</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/research/explore/energy-transition-573.php">Energy Transition</a></li>
                
                <li><a href="/research/explore/social-inclusion-577.php"> Social Inclusion and Cultural Diversity</a></li>
                
                <li><a href="/research/explore/environment-biodiversity-574.php">Environment and Biodiversity</a></li>
                
                <li><a href="/research/explore/data-ai-572.php">Data and Artificial Intelligence</a></li>
                
                <li><a href="/research/explore/health-nutrition-576.php"> Health, Nutrition and Wellbeing</a></li>
                
                <li><a href="/research/explore/news/index.php">News</a></li>
                
                <li><a href="/research/explore/history.php">Research History</a></li>
                
                <li><a href="/research/explore/projects/index.php">Interdisciplinary Research Projects</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
</main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/research/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="/global/js/opentext_responsive/tabcordion.js?cb=20221026"></script>
                
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
