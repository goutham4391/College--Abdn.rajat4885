<!DOCTYPE html>
<html lang="en-GB" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Log in to access page | University of Aberdeen</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,900,400italic,700italic|Droid+Serif:400,700">
        <link rel="stylesheet" href="/global/fonts/fontawesome-pro-5.15.4-web/css/all.min.css">
        <link rel="stylesheet" href="/global/css/login.css?cb=20221006">
    </head>
    <body>
        <header>
            <div class="uni_logo">
                <a href="https://www.abdn.ac.uk/">
                    <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg" alt="University of Aberdeen">
                </a>
            </div>
            <h1>Log in to access page</h1>
        </header>
        <main>
            
            <div id="advisory" class="hidden" tabindex="-1" aria-live="assertive">
                <p></p>
            </div>
                        <form method="post" action="/staffnet/secure/management-information-systems-1428.php">
                <fieldset>
                    <legend>Log In</legend>
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" maxlength="16" value="">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" value="">
                    <input type="hidden" name="form_token" value="cb9f0baf901d7219bf4b78747ae85ebc">
                    <button type="submit">Log In</button>
                </fieldset>
            </form>
                        <p>Forgot your password? <a href="https://www.abdn.ac.uk/password-reset/" target="_blank">Reset it here</a></p>
            <p>Problems logging in? Email the <a href="mailto:servicedesk@abdn.ac.uk">Service Desk</a></p>
        </main>
                    <script>
                if ('querySelector' in document && 'addEventListener' in window) {
                    var caps_lock = '';
                    var username_field = document.getElementById('username');
                    var the_advisory = document.getElementById('advisory');

                    username_field.focus();

                    document.addEventListener('keyup', function(e) {
                        if (e.getModifierState) {
                            if (e.getModifierState('CapsLock')) {
                                the_advisory.className = 'information';
                                the_advisory.innerHTML = '<p>Please be aware that CAPS LOCK is on.</p>';
                                caps_lock = true;
                            }
                            else {
                                if (caps_lock) {
                                    the_advisory.className = 'hidden';
                                    the_advisory.innerHTML = '';
                                    caps_lock = false;
                                }
                            }
                        }
                    });

                    document.querySelector('form').addEventListener('submit', function(e) {
                        if (!username_field.value || !document.getElementById('password').value) {
                            e.preventDefault();
                        }
                        else {
                            // pause, then remove
                            setTimeout(function() {
                                                                window.location.replace('http://www.abdn.ac.uk/');
                                                            }, 3000);
                        }
                    });
                }
            </script>
                </body>
</html>
