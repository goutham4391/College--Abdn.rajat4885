<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>What We Do | StaffNet | The University of Aberdeen</title>
    <!-- Page ID : 9645 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/themes/internal.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/tabcordion.css?cb=20221026" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/staffnet/" class="section_head_text">
                    StaffNet                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="StaffNet navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/staffnet/working-here/index.php">Working Here</a>
            </li>
            
            <li>
                <a href="/staffnet/governance/index.php">Policy and Governance</a>
            </li>
            
            <li>
                <a href="/staffnet/teaching/index.php" class="current">Teaching and Learning</a>
            </li>
            
            <li>
                <a href="/staffnet/research/index.php">Research and Knowledge Exchange</a>
            </li>
            
            <li>
                <a href="/staffnet/news-events.php">News and Events</a>
            </li>
            
            <li>
                <a href="/staffnet/directory.php">Staff Directory</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">What We Do</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/staffnet/">StaffNet</a></li>
            
            <li><a href="/staffnet/teaching/index.php">Teaching and Learning</a></li>
            
            <li><a href="/staffnet/teaching/elearning-337.php">eLearning</a></li>
            
            <li tabindex="0" aria-current="page">What We Do</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">What We Do</div>
                        <p>The&nbsp;<a href="http://www.abdn.ac.uk/staffnet/teaching/educational-development-1583.php" rel="noreferrer noopener" target="_blank">Centre for Academic Development</a>&nbsp;provides a range of eLearning services, actively supporting course delivery, design and evaluation.&nbsp; Along with managing&nbsp;institution wide&nbsp;eLearning applications, we also deliver staff development,&nbsp;arrange events&nbsp;and offer one-to-one support.&nbsp;</p>
                        </div>
                    </div>
                    <div class="section">
  <div class="container">
          <h2 class="optional_heading">eLearning Services</h2>          <div class="tabs_wrapper">
              <section id="tab_group_14233" class="tab_group">
                  <dl class="accordion tabcordion" data-tabcordion='{"urlFragments" : true, "forceAccordion" : true, "openFirstPanel" : false}'>
  
          <dt>
              <a href="#panel14235">eLearning Support</a>
          </dt>
          <dd id="panel14235">
          <p>The eLearning team provide guidance and support on:&nbsp;</p>

<ul>
	<li paraeid="{6cbdfd9b-9614-4062-b7b9-c123e2ead566}{206}" paraid="564648806"><a href="https://www.abdn.ac.uk/toolkit/systems/myaberdeen-staff/" rel="noopener noreferrer" target="_blank">MyAberdeen &amp; Ally</a>&nbsp;</li>
	<li paraeid="{6cbdfd9b-9614-4062-b7b9-c123e2ead566}{214}" paraid="1169663065"><a href="https://www.abdn.ac.uk/toolkit/systems/lecture-capture/" rel="noopener noreferrer" target="_blank">Panopto lecture capture</a>&nbsp;</li>
	<li paraeid="{6cbdfd9b-9614-4062-b7b9-c123e2ead566}{222}" paraid="1274212368"><a href="https://guides.turnitin.com/01_Manuals_and_Guides/Instructor_Guides/Feedback_Studio" rel="noopener noreferrer" target="_blank">Turnitin&nbsp;</a>&amp;&nbsp;<a href="https://help.blackboard.com/Learn/Instructor/Assignments/SafeAssign" rel="noopener noreferrer" target="_blank">Safe Assign</a>&nbsp;</li>
	<li paraeid="{6cbdfd9b-9614-4062-b7b9-c123e2ead566}{235}" paraid="1380846055"><a href="https://www.abdn.ac.uk/toolkit/systems/collaborateultra/" rel="noopener noreferrer" target="_blank">Collaborate webinars</a>&nbsp;</li>
	<li paraeid="{6cbdfd9b-9614-4062-b7b9-c123e2ead566}{247}" paraid="1810196886"><a href="https://abdn.blackboard.com/bbcswebdav/xid-10483262_1" rel="noopener noreferrer" target="_blank">OMBEA Response</a>&nbsp;</li>
	<li paraeid="{6cbdfd9b-9614-4062-b7b9-c123e2ead566}{255}" paraid="2075955044"><a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-authorscreators/" rel="noopener noreferrer" target="_blank">Accessibility of e-learning material</a>&nbsp;</li>
	<li paraeid="{b1ade071-866f-4270-8776-06edd382a9a3}{8}" paraid="1210559515">Questionmark&nbsp;OnDemand</li>
</ul>

<p>We provide videos, written guides and web links on the<a href="https://www.abdn.ac.uk/toolkit/" target="_blank">&nbsp;Toolkit website</a>&nbsp;for the applications we can support.</p>
          </dd>
          
          <dt>
              <a href="#panel14234">Course Accessibility Service</a>
          </dt>
          <dd id="panel14234">
          <p>This service is intended to support teaching teams using MyAberdeen to improve the accessibility of learning materials and help raise awareness of accessibility issues.&nbsp; The Course Accessibility Service includes an audit of course material and the time of an eLearning Support Assistant, who will fix accessibility issues found (as agreed with the course coordinator).&nbsp; Other provision is already in place to support staff with video captions, so the focus for this service is improving the accessibility of documents.&nbsp; Fixes may include aspects such as heading styles, use of colour, tables, and hyperlinks.&nbsp; To request the Course Accessibility Service for one or more of your courses, please email <a href="mailto:elearning@abdn.ac.uk?subject=Course%20Accessibility%20Service">elearning@abdn.ac.uk</a></p>
          </dd>
                            </dl>
              </section>
          </div>
      </div>
</div><div class="section">
  <div class="container">
          <h2 class="optional_heading">eLearning Staff Development</h2><div class="optional_content"><p>The eLearning team offer workshops, webinars and online CPD courses for staff using MyAberdeen and other eLearning applications.&nbsp; To book a place on one of our workshops or courses, please go to the<a href="https://www.abdn.ac.uk/coursebooking/" target="_blank">&nbsp;course booking</a>&nbsp;website and filter by ‘eLearning/MyAberdeen’ to see the available workshops. If you would like to make an enquiry about a bespoke session for your School/Department please let us know by contacting the&nbsp;<a href="mailto:cad@abdn.ac.uk?subject=eLearning%20Workshops" target="_self">Centre for Academic Development</a>.</p></div>          <div class="tabs_wrapper">
              <section id="tab_group_9927" class="tab_group">
                  <dl class="accordion tabcordion" data-tabcordion='{"urlFragments" : true, "forceAccordion" : true, "openFirstPanel" : false}'>
  
          <dt>
              <a href="#panel9929">Blackboard Collaborate</a>
          </dt>
          <dd id="panel9929">
          <p>Blackboard Collaborate is a real-time video conferencing tool that lets you add files, share applications, use a virtual whiteboard to interact, and set up breakout groups to enable group work. We offer two workshops: Getting Started and Focus on Breakout Groups. The former introduces the system and goes through the general interface, while the latter focuses on running and organising Breakout Groups within a session.</p>

<p>These online sessions give&nbsp;you the opportunity to experience Blackboard Collaborate both as a student and as an instructor. The sessions will provide an overview of the tool, give you the chance to use the interactive features and to experience being a moderator.</p>

<p>Further information about upcoming Collaborate sessions is available on the <a href="http://www.abdn.ac.uk/coursebooking">course booking</a> website and there is additional support material on Toolkit under <a href="https://www.abdn.ac.uk/toolkit/systems/collaborateultra/">MyAberdeen: Collaborate Ultra</a>.</p>
          </dd>
          
          <dt>
              <a href="#panel12222">Panopto</a>
          </dt>
          <dd id="panel12222">
          <p>Panopto is the software supported by the University that provides lecture recording, screencasting, video streaming and video content management software.</p>

<p>eLearning provide online sessions covering information on getting started using Panopto and also a more advanced session focussing on enhancing your use of Panopto.</p>

<p>Further information about upcoming Panopto sessions are available on the <a href="http://www.abdn.ac.uk/coursebooking">course booking</a> website&nbsp;and there is additional support material on Toolkit under <a href="https://www.abdn.ac.uk/toolkit/systems/lecture-capture/">Panopto</a>.</p>
          </dd>
          
          <dt>
              <a href="#panel12223">Blackboard Ally</a>
          </dt>
          <dd id="panel12223">
          <p>Blackboard Ally is a tool within MyAberdeen that focuses on making digital course content more accessible.&nbsp; Online sessions are provided to give an overview of the need for digital accessibility, the feedback Blackboard Ally provides staff and the alternative formats available it generates for students.&nbsp; There will be an opportunity for questions during the session.</p>

<p>Further information about upcoming Ally sessions are available on the <a href="http://www.abdn.ac.uk/coursebooking">course booking</a> website and there further&nbsp;support material available on Toolkit under&nbsp;<a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-authorscreators/">Accessibility for Authors/Creators</a>.</p>
          </dd>
          
          <dt>
              <a href="#panel12224">MyAberdeen Workshops</a>
          </dt>
          <dd id="panel12224">
          <p>MyAberdeen is the University's virtual learning environment, where you can upload learning materials and resources associated with your course.&nbsp;</p>

<p>Prior to the start of semester there are a variety of sessions offered focussing upon:</p>

<ul>
	<li>Content and Communication</li>
	<li>Assessment and Feedback</li>
</ul>

<p>Further information about upcoming MyAberdeen sessions are available on the&nbsp;<a href="http://www.abdn.ac.uk/coursebooking" target="_blank">course booking</a>&nbsp;website&nbsp;and there is additional support material on Toolkit under&nbsp;<a href="https://www.abdn.ac.uk/toolkit/systems/lecture-capture/" target="_blank">M</a><a href="https://www.abdn.ac.uk/toolkit/systems/myaberdeen-staff/">yAberdeen: Staff</a>, <a href="https://www.abdn.ac.uk/toolkit/systems/turnitin-staff/">Blackboard &amp; Turnitin Assignments for Staff</a> and <a href="https://www.abdn.ac.uk/toolkit/systems/myaberdeen-admin/">MyAberdeen: Admin</a>.</p>
          </dd>
          
          <dt>
              <a href="#panel9930">Designing and Tutoring Online Course (DTOC)</a>
          </dt>
          <dd id="panel9930">
          <p>This five-week online course has been developed to support staff in the design and tutoring of online courses. More information can be found on the <a href="https://www.abdn.ac.uk/staffnet/teaching/2column-page-9408-9408.php">Centre for Academic Development</a> pages. Normally DTOC is offered twice a year, usually during October and April each year.</p>
          </dd>
          
          <dt>
              <a href="#panel12221">Designing and Tutoring Online Course LITE (DTOC LITE)</a>
          </dt>
          <dd id="panel12221">
          <p>In response to the University's move to Blended Learning, eLearning offered a reduced version of the Designing and Tutoring Online Course, entitled DTOC LITE.&nbsp; This is a condensed version of DTOC and is delivered over five-days. Currently DTOC LITE is offered in January and August, see <a href="http://www.abdn.ac.uk/coursebooking">course booking</a> for further information.</p>
          </dd>
          
          <dt>
              <a href="#panel9928">Programme Review and Storyboarding  </a>
          </dt>
          <dd id="panel9928">
          <p>This 1 hour session provides an overview of the programme review and storyboarding process, which can be applied to fully online, blended as well as on campus programmes and courses.</p>

<p>In many cases, the programme review and storyboarding processes has greatly inspired both the programme team and course team in the development of their own programmes.</p>

<p>Sessions can be booked via <a href="https://www.abdn.ac.uk/coursebooking/">course bookings</a>, filtering by eLearning/MyAberdeen.</p>
          </dd>
                            </dl>
              </section>
          </div>
      </div>
</div><div class="section">
  <div class="container">
          <h2 class="optional_heading">MyAberdeen User Group</h2><div class="optional_content"><p>The MyAberdeen User Group is an informal space&nbsp;on <strong>MS Teams</strong>&nbsp;where staff can share&nbsp;good practice on the use of MyAberdeen and associated learning technologies.</p>

<p><strong>Joining&nbsp;instructions</strong>: Open MS Teams and click&nbsp;“Join or create a team” in&nbsp;your teams list. Look for the&nbsp;“Join a team with a code”&nbsp;card&nbsp;and enter this code to join the&nbsp;MyAberdeen&nbsp;User Group:&nbsp;<strong>sdtryx2</strong>.&nbsp;</p>

<p>If you have any questions, please contact the <a href="mailto:cad@abdn.ac.uk?subject=MyAberdeen%20User%20Group%20query">Centre for Academic Development</a>.</p></div>          <div class="tabs_wrapper">
              <section id="tab_group_14697" class="tab_group">
                  <dl class="accordion tabcordion" data-tabcordion='{"urlFragments" : true, "forceAccordion" : true, "openFirstPanel" : false}'>
  
          <dt>
              <a href="#panel14701">2022 events</a>
          </dt>
          <dd id="panel14701">
          <p>We are looking for people to contribute to one of this year's meetings!&nbsp;If you'd like to<strong> share your experiences</strong> with others at one of the MyAberdeen User Group&nbsp;meetings, please let us know by completing <a href="https://forms.office.com/r/x0gSVMbtwf">a&nbsp;short MS form</a> and we will get in touch with you soon.</p>

<p>More information on upcoming events in 2022 can be found in the&nbsp;<strong>MS Teams</strong>&nbsp;area.</p>
          </dd>
          
          <dt>
              <a href="#panel14700">2021 events</a>
          </dt>
          <dd id="panel14700">
          <h2>29 March 2021: Inaugural meeting</h2>

<p>At this meeting we discussed the remit of the MyAberdeen User Group. The outcomes were that the User Group is:</p>

<ul>
	<li>An informal space to discuss challenges and opportunities in the use MyAberdeen and of associated learning and teaching technologies.</li>
	<li>A safe space for staff to share good practices, and to get a chance to try things out with the help of colleagues, before using them with students.</li>
	<li>Somewhere to find out about new releases and improvements coming to MyAberdeen and have a chance to discuss with colleagues how they can be used.</li>
</ul>

<h2>7 June 2021: Experiences of grading online</h2>

<p>Two lecturers kindly shared with us their experiences of grading online using the Original Course View on MyAberdeen. A recording of the session has been shared on the MS Teams area.</p>

<h2>9 September 2021: Top tips for the start of term</h2>

<p>This was a well attended session were staff had a chance to share with each other some top tips for the start of term. We have shared the slides from the session and collated all the main points from the discussion in the MS Teams area.</p>
          </dd>
                            </dl>
              </section>
          </div>
      </div>
</div>            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/staffnet/index.php">StaffNet</a></li>
            
            <li><a href="/staffnet/teaching/index.php">Teaching and Learning</a></li>
            
            <li><a href="/staffnet/teaching/elearning-337.php">eLearning</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/staffnet/teaching/what-we-do-9645.php" class="current" aria-current="page">What We Do</a></li>
                
                <li><a href="/staffnet/teaching/2column-page-9602-9602.php">News & Updates </a></li>
                
                <li><a href="/staffnet/teaching/2column-page-9809-9809.php">Meet the Team</a></li>
                
                <li><a href="/staffnet/teaching/video-tutorials-10449.php">Video tutorials</a></li>
                
                <li><a href="/staffnet/teaching/tip-of-the-month-9630.php">Tip of the month</a></li>
                
                <li><a href="/staffnet/teaching/templates-9649.php">Guidelines & Templates</a></li>
                
                <li><a href="/staffnet/teaching/working-with-blackboard-9925.php">Working with Blackboard</a></li>
                
                <li><a href="/staffnet/teaching/course-rollover-7464.php">Course Rollover</a></li>
                
                <li><a href="/staffnet/teaching/accessibility-of-digital-learning-materials-11922.php">Accessibility of Digital Learning Materials</a></li>
                
                <li><a href="/staffnet/teaching/suggestions-9653.php">Suggestions</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/staffnet/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="/global/js/opentext_responsive/tabcordion.js?cb=20221026"></script>
                
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
