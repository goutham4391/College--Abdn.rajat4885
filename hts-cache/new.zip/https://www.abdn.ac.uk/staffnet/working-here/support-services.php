<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Support Services  | StaffNet | The University of Aberdeen</title>
    <!-- Page ID : 11792 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/themes/internal.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/tabcordion.css?cb=20221026" media="screen">
                    
                    <link rel="stylesheet" href="/global/faqs/site/css/faq.css?cb=20221026" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>

                    <script src="/global/faqs/site/js/faq.functions.js?cb=20221026"></script>
                    </head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/staffnet/" class="section_head_text">
                    StaffNet                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="StaffNet navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/staffnet/working-here/index.php" class="current">Working Here</a>
            </li>
            
            <li>
                <a href="/staffnet/governance/index.php">Policy and Governance</a>
            </li>
            
            <li>
                <a href="/staffnet/teaching/index.php">Teaching and Learning</a>
            </li>
            
            <li>
                <a href="/staffnet/research/index.php">Research and Knowledge Exchange</a>
            </li>
            
            <li>
                <a href="/staffnet/news-events.php">News and Events</a>
            </li>
            
            <li>
                <a href="/staffnet/directory.php">Staff Directory</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Support Services </h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/staffnet/">StaffNet</a></li>
            
            <li><a href="/staffnet/working-here/index.php">Working Here</a></li>
            
            <li><a href="/staffnet/working-here/about-hr-994.php">Human Resources</a></li>
            
            <li tabindex="0" aria-current="page">Support Services </li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section heading_only">
                        <div class="container">
                    
                        <div class="h1">Support Services </div>
                        
                        </div>
                    </div>
                    <div class="section">
    <div class="container">
        <h2 class="optional_heading">Support for staff</h2><div class="optional_content"><div>
<p>Additionally, staff are able to contact HR whilst working from home. Please email your HR Partner or <a href="mailto:HR@abdn.ac.uk">HR@abdn.ac.uk</a>. If you'd like to speak to someone on the phone call 01224 273500. &nbsp;</p>
</div></div>        <div class="tabs_wrapper">
            <section id="tab_group_5510" class="tab_group">
                <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                            <dt>
                                <a href="#panel5515">Disabled Staff</a>
                            </dt>
                            <dd id="panel5515">
                            <p>The links below provide information of relevance to disabled staff. For more specific guidance, please contact your Human Resources Officer.</p>

<ul>
	<li>There are a number of&nbsp;opportunities for involvement, if you have an interest in disability matters at the University of Aberdeen.</li>
	<li>Fitness and exercise opportunities for disabled users</li>
	<li><a href="http://www.abdn.ac.uk/library/documents/guides/gen/qggen002.pdf" target="_blank">Library services for disabled users</a></li>
	<li>Staff Disability Network Group</li>
</ul>
                            </dd>
                            
                            <dt>
                                <a href="#panel6424">Employee Assistance Programme</a>
                            </dt>
                            <dd id="panel6424">
                            <p><font><picture class="imgproxy" style="float:right; margin-left:10px; margin-right:10px"><source media="(min-width: 481px)" srcset="/img/780x/staffnet/documents/Care%20First.png"><source media="(min-width: 251px)" srcset="/img/481x/staffnet/documents/Care%20First.png"><source srcset="/img/200x/staffnet/documents/Care%20First.png"><img src="/img/780x/staffnet/documents/Care%20First.png" width="200" height="201" alt="Care first logo" loading="lazy"></picture></font>The University offers staff an Employee Assistance Programme (EAP) which provides a free, confidential face to face and telephone counselling service as well as information services.</p>

<p>The EAP is provided by Care First and staff can contact them about work related or personal issues as well as information, such as&nbsp; legal or financial advice.</p>

<p>Care First is <strong>available 24 hours a day, 7 days a week</strong>. They can be contacted on the <strong>freephone number 0808 168 2143</strong>.</p>

<p>Online information and counselling are available on the Lifestyle website:</p>

<p><a href="http://www.carefirst-lifestyle.co.uk/" style="text-decoration: underline;">http://www.carefirst-lifestyle.co.uk</a><br />
<strong>Username:</strong> aberdeen<br />
<strong>Password:</strong> employee</p>

<p><strong>We want to ensure that our staff get the best service possible, therefore we would welcome feedback on the service provided to you by Carefirst. Comments can be sent to <a href="mailto:reward@abdn.ac.uk" style="text-decoration-line: underline; text-decoration-thickness: initial; text-decoration-color: initial;">reward@abdn.ac.uk</a> </strong></p>

<p>Care First can provide support on a wide range of issues, such as:</p>

<table border="0" cellpadding="10" cellspacing="0" style="width:100%">
	<tbody>
		<tr>
			<td style="vertical-align:top; width:30%">
			<ul>
				<li>Anxiety</li>
				<li>Bereavement</li>
				<li>Budgeting</li>
				<li>Bullying</li>
				<li>Bullying at work</li>
				<li>Coping with change</li>
				<li>Debt</li>
				<li>Depression</li>
			</ul>
			</td>
			<td style="vertical-align:top; width:35%">
			<ul>
				<li>Divorce</li>
				<li>Domestic abuse</li>
				<li>Drug and alcohol abuse</li>
				<li>Family problems</li>
				<li>Food and nutrition</li>
				<li>Gambling</li>
				<li>Harassment at work</li>
				<li>Health information</li>
			</ul>
			</td>
			<td style="vertical-align:top; width:35%">
			<ul>
				<li>Legal advice</li>
				<li>Managing money</li>
				<li>PTSD</li>
				<li>Relationships</li>
				<li>Stress at work</li>
				<li>Stress management</li>
				<li>Suicide</li>
				<li>Workplace critical incidents</li>
			</ul>
			</td>
		</tr>
	</tbody>
</table>

<p>The <a href="/staffnet/documents/Sodexo%20Employee%20EAP%20Presentation1.pptx#Care First presentation">PowerPoint presentation</a>&nbsp;and <a href="https://10pc8n.videomarketingplatform.co/secret/64735288/4d7d6324a858f85642dd4e88f9314ca2">video</a> provide&nbsp;an&nbsp;overview of the services available through Care First.</p>

<p>University of Aberdeen staff have access to a well-being app provided by CareFirst. Details about the application and how to register are available <a href="/staffnet/documents/Care%20first%20NEW%20zest%20app%20Poster.pdf">here</a>.</p>

<p><strong>2022&nbsp;Weekly Publicity Calendar week commencing</strong>:&nbsp;<a href="/staffnet/documents/2022%20Weekly%20Publicity%20Calendar%20-%2013th%20June%2022.pdf" target="_blank">13 June 2022</a></p>

<p><strong>Monday</strong>&nbsp; <a href="/staffnet/documents/Monday%20-%20Loneliness%20Awareness%20Week.pdf" target="_blank">Loneliness Awareness Week&nbsp;</a></p>

<p><strong>Wednesday</strong> <a href="/staffnet/documents/Wednesday%20-%20How%20Care%20first%20can%20support%20you.pdf" target="_blank">How Care First can support you</a></p>

<p><strong>Thursday </strong>- <a href="/staffnet/documents/Thursday%20-%20Menopause%20Awareness.pdf" target="_blank">Menopause Awareness</a>&nbsp;</p>

<p><strong>Friday</strong> - <a href="/staffnet/documents/Friday%20-%20Care%20First%20Lifestyle%20-%20Your%20digital%20well-being%20solution.pdf" target="_blank">Care First Lifestyle - Your digital well-being solution</a>&nbsp;&nbsp;</p>

<p><strong>2022 Weekly Publicity Calendar week commencing</strong> <a href="/staffnet/documents/2022%20Weekly%20Publicity%20Calendar%20-%2020th%20June%2022.pdf" target="_blank">20 Juen 2022&nbsp;</a></p>

<p><strong>Monday</strong> - <a href="/staffnet/documents/Monday%20-%20World%20Wellbeing%20Week.pdf" target="_blank">World Wellbeing Week&nbsp;</a></p>

<p><strong>Wednesday -</strong> <a href="/staffnet/documents/Wednesday%20-%20How%20Care%20first%20can%20support%20you.pdf" target="_blank">How Care first can support you</a>&nbsp;</p>

<p><strong>Friday -</strong> <a href="/staffnet/documents/Friday%20-%20Care%20first%20cCBT.pdf" target="_blank">Care first cCBT</a></p>

<p><strong>Upcoming Topics&nbsp;</strong></p>

<p><a href="/staffnet/documents/2022%20Wellbeing%20calendar%20(003).pdf" id="wellbeing Calendar 2022" name="wellbeing Calendar 2022" target="_blank"><strong>Wellbeing&nbsp;Calendar for 2022&nbsp;</strong></a></p>

<p><a href="/staffnet/documents/2022%20Weekly%20Publicity%20Calendar%20-%2027th%20June.pdf" target="_blank"><strong>Week commencing 27 June 2022&nbsp;</strong></a></p>

<p><strong>Situation in Ukraine - 3 March 2022</strong></p>

<p>With the ever-evolving situation in Ukraine, we felt it is important to update you on what Care first is doing to support their customers. Please click&nbsp;on the link below to see our statement.</p>

<p><a href="/staffnet/documents/Care%20first%20Statement%201.3.2022.pdf" id="Care first Ukraine Statement " name="Care first Ukraine Statement " target="_blank">Care first Statement&nbsp;</a></p>

<p><strong>Documents from previous webinars:</strong></p>

<ul>
	<li><a href="/staffnet/documents/Tuesday%20%20COVID-19%20-%20Change%20and%20Resilience.pdf">Change &amp; Resilliance</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20COVID-19%20-%20Working%20from%20Home.pdf">Working from Home</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20COVID-19%20-%20Loneliness%20and%20Isolation.pdf">Loneliness &amp; Isolation</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20COVID-19%20-%20Mental%20Health%20Awareness%20(World%20Mental%20Health%20Day).pdf">Mental Health Awareness (World Mental Health Day)</a></li>
	<li><a href="/staffnet/documents/Tuesday%20-%20Supporting%20loved%20ones%20overseas.pdf">Supporting loved ones overseas</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20How%20feelings%20of%20loneliness%20and%20isolation%20can%20make%20it%20difficult%20to%20re-interact%20after%20lockdown.pdf">How feelings of loneliness and isolation can make it difficult to re-interact after lockdown</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20How%20to%20spot%20if%20someone%20is%20struggling%20with%20their%20Mental%20Health.pdf">How to spot if someone is struggling with their mental health</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20Alcohol%20Awareness%20%e2%80%93%20Drinking%20Safely%20as%20lockdown%20eases.pdf">Alcohol Awareness - Drinking safely as lockdown eases</a></li>
	<li><a href="/staffnet/documents/Tuesday%20-%20Coping%20with%20uncertainty.pdf">Coping with uncertainty</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20Anxiety%20of%20the%20clinically%20vulnerable.pdf">Anxiety of the clinically vulnerable</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20The%20benefits%20of%20cycling.pdf">The benefits of cycling</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20Information%20for%20MHFA%e2%80%99s,%20Mental%20Health%20Champions%20and%20Managers%20supporting%20teams%20as%20restrictions%20ease%e2%80%99.pdf">Information for MHFAs, Mental Health Champions &amp; Managers supporting teams as restrictions ease</a></li>
	<li><a href="/staffnet/documents/Tuesday%20-%20Bullying%20and%20Harassment%20at%20Work.pdf">Bullying &amp; harrassment at work</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20COVID-19%20-%20Hidden%20Disabilities%2011th%20August.pdf">Hidden disabilities</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20The%20benefits%20of%20being%20sociable.pdf">The benefits of being sociable</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20Tips%20for%20keeping%20safe%20in%20the%20sun%20this%20summer.pdf">Tips for keeping safe in the sun this summer</a></li>
	<li><a href="/staffnet/documents/Tuesday%20-%20Ways%20to%20reduce%20your%20carbon%20footprint.pdf">Ways to reduce your carbon footprint</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20Compassion%20Fatigue.pdf">Compassion fatigue</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20Travelling%20with%20unvaccinated%20children.pdf">Travelling with unvaccinated children</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20Has%20lockdown%20made%20us%20more%20spontaneous.pdf">Has lockdown made us more spontaneous</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20Mental%20Health%20Awareness.pdf">Mental Health Awareness</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20COVID-19%20-%20Guidance%20article.pdf">Covid-19 Guidance Article</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20Preparing%20for%20the%20winter.pdf">Preparing for the winter</a></li>
	<li><a href="/staffnet/documents/Tuesday%20-%20Establishing%20Familiar%20Routines.pdf">Establishing Familiar Routines</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20Long%20COVID.pdf">Long COVID</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20Vaccination%20Booster.pdf">Vaccination Booster</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20World%20Suicde%20Prevention.pdf">World Suicide Prevention</a></li>
	<li><a href="/staffnet/documents/Tuesday%20-%20Maintaining%20working%20relationships%20as%20our%20working%20patterns%20change.pdf">Maintaining working relationships as our working patterns change</a></li>
	<li><a href="/staffnet/documents/Wednesday%20-%20National%20Fitness%20Day%2022%20September.pdf">National Fitness Day</a></li>
	<li><a href="/staffnet/documents/Thursday%20-%20Tips%20for%20improving%20posture.pdf">Tips for improving posture</a></li>
	<li><a href="/staffnet/documents/Friday%20-%20International%20Happiness%20week%20at%20work.pdf">International Happiness Week at Work</a></li>
	<li><a href="/staffnet/documents/19566_EAP_For%20the%20love%20of%20bread.pdf" target="_blank">For the love of bread</a>&nbsp;</li>
	<li><a href="/staffnet/documents/19566_EAP_I%20dont%20mean%20to%20shout.pdf" target="_blank">I don't mean to shout</a></li>
	<li><a href="/staffnet/documents/19566_EAP_You%20dont%20look%20any%20different.pdf" target="_blank">You don't look any different</a>&nbsp;&nbsp;</li>
	<li><a href="/staffnet/documents/Mens%20Health%20Awareness.pdf" target="_blank">Mens Health Awareness&nbsp;</a></li>
	<li><a href="/staffnet/documents/My%20Autistic%20Life.pdf" target="_blank">My Autistic Life&nbsp;</a></li>
</ul>

<p><a href="https://sodexo-group.videomarketingplatform.co/secret/75668694/6179e7340b58545329bdd91d5319b006" target="_blank">EAP Video&nbsp;</a></p>

<p><strong>Further Materials</strong></p>

<p>April 2022&nbsp;</p>

<p><a href="/staffnet/documents/19549_EAP-April_Be-Active.pdf" id="care first Be Active " name="Care first Be Active " target="_blank">Be Active</a>&nbsp;</p>

<p>May 2021</p>

<p><a href="/staffnet/documents/19224_EAP_POSTERS_MAY_DEMENTIA.pdf">Dementia Awareness</a></p>

<p><a href="/staffnet/documents/19224_EAP_POSTERS_MAY_MENTALHEALTHAWARERNESS.pdf">Mental Health Awareness</a></p>

<p><a href="/staffnet/documents/19224_EAP_POSTERS_MAY_%20POST_PARTEM.pdf">Post-Partum (Perinatal Depressions) and Mental Illness</a></p>
                            </dd>
                            
                            <dt>
                                <a href="#panel11470">Scotland's Mental Health First Aid (SMHFA)</a>
                            </dt>
                            <dd id="panel11470">
                            <p>Mental Health First Aid is a national training programme and prepares people to be Mental Health First Aiders (MHFAs).</p>

<ul>
	<li>To find out more please <a href="https://www.abdn.ac.uk/staffnet/working-here/wellbeing-portal/workplace-wellbeing-11651.php#panel11659">visit the Employee Wellbeing</a> section of Staffnet</li>
</ul>
                            </dd>
                            
                            <dt>
                                <a href="#panel6451">Counselling Service - Information for Staff</a>
                            </dt>
                            <dd id="panel6451">
                            <h2>Staff Seeking Help</h2>

<p>The Counselling Service offers in-person, online or telephone counselling sessions for members of staff and students who&nbsp;are currently&nbsp;in the UK. The Counselling Service aim to offer you an appointment within 2 working days of you getting in touch. Instead of arranging a block of future appointments, counselling sessions are booked individually at the point where you feel they would be helpful. For further information on the Counselling Service and how to contact them, please go to their <a href="http://www.abdn.ac.uk/counselling" target="_blank">webpage</a></p>

<ul>
	<li><a href="https://www.abdn.ac.uk/infohub/support/counselling-service.php#panel1886" target="_blank">External Resources</a></li>
</ul>

<h2>Letters of Support for Students</h2>

<p>The Counselling Service can provide letters of support for students who have talked to a&nbsp;counsellor. Please see the 'Letters of Support Requests from Students' section on their&nbsp;<a href="https://www.abdn.ac.uk/students/support/counselling-3635.php#panel3642" target="_blank">webpage</a></p>
                            </dd>
                            
                            <dt>
                                <a href="#panel5513">Mediation</a>
                            </dt>
                            <dd id="panel5513">
                            <p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" frameborder="0" height="315" src="https://www.youtube.com/embed/8ZzNJozAS9c" title="YouTube video player" width="560"></iframe></p>

<table border="0" cellpadding="10" cellspacing="0" class="faq_table" style="width:100%">
	<tbody>
		<tr>
			<th><strong>Members of the Mediation Team</strong></th>
		</tr>
		<tr>
			<td>
			<p>The following members of the Mediation Team are prepared to take part in Co-Mediation for early dispute resolution:</p>

			<table border="1" cellpadding="10" cellspacing="0" style="width:100%">
				<tbody>
					<tr>
						<th style="vertical-align: top; text-align: left;" width="30%"><strong>Name</strong></th>
						<th style="vertical-align: top; text-align: left;" width="70%"><strong>Title</strong></th>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:d.auchie@abdn.ac.uk?subject=Mediation%20Enquiry">Derek Auchie</a></td>
						<td style="vertical-align:top">Personal Chair, School of Law</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:g.cordiner@abdn.ac.uk?subject=Mediation%20Enquiry">Grant Cordiner</a></td>
						<td style="vertical-align:top">Technical Resources Officer, Central Workshop&nbsp;</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:a.ivanovic@abdn.ac.uk?subject=Mediation%20Enquiry">Ana Ivanovic</a></td>
						<td style="vertical-align:top">Personal Chair, School of Engineering</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:d.stuart@abdn.ac.uk?subject=Mediation%20Enquiry">Duncan Stuart</a></td>
						<td style="vertical-align:top">Head of Student Experience</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:gail.smillie@abdn.ac.uk?subject=Mediation%20Enquiry">Gail Smillie</a></td>
						<td style="vertical-align:top">Relationship Manager Team Lead, Programme Management</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:p.spence@abdn.ac.uk?subject=Mediation%20Enquiry">Patricia Spence</a></td>
						<td style="vertical-align:top">Centre Manager, Centre for Academic Development</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:e.towler@abdn.ac.uk?subject=Mediation%20Enquiry">Emma Towler</a></td>
						<td style="vertical-align:top">Strategic Planning Officer</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:g.ferrigan@abdn.ac.uk?subject=Mediation%20Enquiry">Grainne Ferrigan</a>&nbsp;</td>
						<td style="vertical-align:top">Development Officer, Online Education</td>
					</tr>
					<tr>
						<td style="vertical-align:top"><a href="mailto:clare.trembleau@abdn.ac.uk?subject=Mediation%20Enquiry">Clare Trembleau</a></td>
						<td style="vertical-align:top">&nbsp;Staff Development Partner&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>

<p><strong>What is Mediation?</strong></p>

<p>Mediation is an effective way of resolving disputes. It involves an independent third party, a Mediator, who helps both sides to reach an agreement.</p>

<p>The role of the Mediator is to help parties to reach a solution to their problem and to arrive at an outcome which both parties are happy to accept. Mediators are entirely independent; they avoid taking sides, making judgements or giving guidance. They are responsible for developing effective communication and building consensus between the individuals who are in dispute.</p>

<p>The focus of a Mediation meeting is to reach a settlement which is agreeable to both parties.</p>

<p>Mediation is a voluntary process and will only take place if both parties agree. It is a confidential process and the content of a Mediation meeting is not disclosed to anyone outside the meeting.</p>

<p><strong>What are the Benefits of Mediation?</strong></p>

<p>Mediation provides a quicker and simpler way of resolving disputes rather than using formal procedures.</p>

<p><strong>The University's Mediation Team</strong></p>

<p>The University has established a Mediation Team. Members of the Mediation Team are fully trained, and are able to provide a Mediation service for all members of staff, and between all levels of staff, with the aim of providing resolution at the early stages of a dispute.</p>

<p>The University is a Member of Scottish Mediation and adhere to their <a href="/staffnet/documents/secure/Code-of-Practice-for-Mediation-in-Scotland.pdf">Code of Conduct</a>&nbsp;to ensure that all members of the Mediation Team demonstrate respect, independence, impartiality and confidentiality.&nbsp;</p>

<p><strong>Co-Mediation</strong></p>

<p>The approach to Mediation which has been adopted by Members of the Mediation Team is Co-Mediation. This involves two Mediators who work together as a team.</p>

<p>The advantages of Co-Mediation are:</p>

<ul>
	<li>The participants have the advantage of the combined skills of two Mediators whose skills usually enhance and complement each other;</li>
	<li>There is a better check on any bias or shortcomings which might occur if only one Mediator is used;</li>
	<li>A participant has a better chance of establishing a sense of trust with at least one of the two Mediators.</li>
</ul>

<p><strong>How Does Co-Mediation Work?</strong></p>

<p>There are usually three phases to Co-Mediation:</p>

<ol>
	<li><strong>Pre Mediation </strong>– once the people involved in the dispute agree to participate in the Mediation process, the Co-Mediators will schedule a separate Pre Mediation meeting with each individual. The purpose of this meeting is to find out more about the individuals' perspectives and to answer any questions about the process. A confidentiality agreement is signed by all the parties at this stage.<br />
	&nbsp;</li>
	<li><strong>Mediation </strong>– the people involved in the dispute and the Mediators meet, and the Mediation process is explained in detail. Each person has the opportunity to provide his or her perspective on the dispute. One Mediator will guide the conversation while the other will listen and feedback what has been recorded to check for accuracy. The role of the Mediators is to guide the process to facilitate increased understanding between the people involved in the dispute. Mediation aims to help people achieve a win/win solution to a dispute. This may take some time and the outcome is a Mediation Agreement which is signed by both parties.<br />
	&nbsp;</li>
	<li><strong>Follow Up</strong> – It is good practice for one of the Mediators to follow up with the participants in the Mediation process some time after the Mediation has been completed to see how things are progressing.</li>
</ol>

<p><br />
<strong>Further Information and Access to Mediation</strong></p>

<p>Members of the team are able to provide more information on mediation and to make arrangements for mediation to take place.</p>
                            </dd>
                            
                            <dt>
                                <a href="#panel5512">Multi-faith Chaplaincy</a>
                            </dt>
                            <dd id="panel5512">
                            <p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" frameborder="0" height="315" src="https://www.youtube.com/embed/35-G15SLMU8" title="YouTube video player" width="560"></iframe></p>

<p><a href="http://www.abdn.ac.uk/chaplaincy/" title="The Chaplaincy website">The Multi-faith Chaplaincy</a> offers resources and help for everyone, whatever their situation. Chaplaincy staff work closely with&nbsp;<a href="http://www.abdn.ac.uk/student-support/" target="_blank">Student Support Services</a>&nbsp;team, and are here for all staff and students on campus - everyone is welcome.</p>

<p>The Chaplaincy Centre is at 25 High Street and is open 09:30 - 16:30, Monday to Friday, throughout the year for visitors.</p>

<p>Chaplaincy staff will happily arrange out of hours meetings for those in need.</p>
                            </dd>
                            
                            <dt>
                                <a href="#panel5511">Occupational Health</a>
                            </dt>
                            <dd id="panel5511">
                            <p>All staff are able to consult the service for advice on health matters. You are encouraged to discuss any health problems relating to your work in the first instance with your line manager however the occupational health service may be able to provide medical advice and assistance in situations where:</p>

<ul>
	<li>&nbsp;You are concerned that some aspect of your job is making you ill</li>
	<li>You feel that you cannot perform at work to the best of your ability because of a health problem</li>
</ul>

<p>&nbsp;<a href="https://www.abdn.ac.uk/staffnet/working-here/wellbeing-portal/workplace-wellbeing-11651.php#panel11657">Find out more on the Employee Wellbeing</a> section of the Staffnet.</p>
                            </dd>
                                            </dl>
            </section>
        </div>
    </div>
</div>
            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/staffnet/index.php">StaffNet</a></li>
            
            <li><a href="/staffnet/working-here/index.php">Working Here</a></li>
            
            <li><a href="/staffnet/working-here/about-hr-994.php">Human Resources</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/staffnet/working-here/hr-employment-services-3031.php">Contact HR</a></li>
                
                <li><a href="/staffnet/working-here/industrial-action-2592.php">Industrial Action</a></li>
                
                <li><a href="/staffnet/working-here/probation-2813.php">Probation</a></li>
                
                <li><a href="/staffnet/working-here/honorary-status-2973.php">Honorary Status</a></li>
                
                <li><a href="/staffnet/working-here/hesa-staff-record-4017.php">Staff Collection Notice</a></li>
                
                <li><a href="/staffnet/working-here/staff-survey-2022-15219.php">Staff Survey 2022</a></li>
                
                <li><a href="/staffnet/working-here/support-services.php" class="current" aria-current="page">Support Services </a></li>
                
                <li><a href="/staffnet/working-here/toolkits-12919.php">Toolkits</a></li>
                
                <li><a href="/staffnet/working-here/rewards-calculator.php">Total Reward Calculator</a></li>
                
                <li><a href="/staffnet/working-here/workload-planning-review-group-11898.php">Workload Planning Review Group</a></li>
                
                <li><a href="/staffnet/working-here/myhr-14371.php">MyHR</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/staffnet/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="/global/js/opentext_responsive/tabcordion.js?cb=20221026"></script>
                
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                
    <script>
        showHideFAQSetup();
    </script>
        </body>
</html>
