<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>News | The University of Aberdeen</title>
    <!-- Page ID : 3 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Latest News from the University of Aberdeen">
    
<meta name="application-name" content="News">
    <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" media="screen">
                    
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" media="screen">
                    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/slick_combined.css?cb=20221026" media="screen">
                    
                    <link rel="stylesheet" href="/global/news/site/css/opentext_responsive/news.css" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
                    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
                    
<script>
    var global_base_url = '/global/';
</script>

<link rel="alternate" type="application/rss+xml" href="/news/rss.xml" title="News - Latest News, RSS">
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/news/" class="section_head_text">
                    News                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="News navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/news/latest-news.php">Latest News</a>
            </li>
            
            <li>
                <a href="/news/communications/index.php">Communications Team</a>
            </li>
            
            <li>
                <a href="/news/public-affairs.php">Public Affairs</a>
            </li>
            
            <li>
                <a href="/news/opinion/index.php">Opinion</a>
            </li>
            
            <li>
                <a href="/news/brexit/index.php">Life after Brexit</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">News</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li tabindex="0" aria-current="page">News</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="full_width" tabindex="-1">
    
        <div class="section heading_only">
          <div class="container">
        
            <div class="h1">News</div>
            
            </div>
        </div>
        <div class="section">
    <div class="container">
<div class="slider">
    <section class="slick_slideshow slick_not_loaded">

    <article>
    
        <a href="https://www.abdn.ac.uk/stories/in-depth/index.html" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 1200px)" srcset="/img/850x/news/slideshow-images/montage_of_indepth_stories_rdax_850x478.jpg"><source media="(min-width: 980px)" srcset="/img/415x/news/slideshow-images/montage_of_indepth_stories_rdax_850x478.jpg"><source media="(min-width: 800px)" srcset="/img/680x/news/slideshow-images/montage_of_indepth_stories_rdax_850x478.jpg"><source srcset="/img/500x/news/slideshow-images/montage_of_indepth_stories_rdax_850x478.jpg"><img src="/img/850x/news/slideshow-images/montage_of_indepth_stories_rdax_850x478.jpg" alt="In-depth - our pioneers and their extraordinary achievements" width="849" height="478" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>In-depth - our pioneers and their extraordinary achievements</h2>
    <p>Our staff, students and graduates have achieved remarkable success. We explore their stories and how they have shaped the lives of others.</p>
    </div>
    
        </a>
        
    </article>
    
    <article>
    
        <a href="/news/videos-122.php" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 1200px)" srcset="/img/850x/news/slideshow-images/Camera_video_research_rdax_850x478.jpg"><source media="(min-width: 980px)" srcset="/img/415x/news/slideshow-images/Camera_video_research_rdax_850x478.jpg"><source media="(min-width: 800px)" srcset="/img/680x/news/slideshow-images/Camera_video_research_rdax_850x478.jpg"><source srcset="/img/500x/news/slideshow-images/Camera_video_research_rdax_850x478.jpg"><img src="/img/850x/news/slideshow-images/Camera_video_research_rdax_850x478.jpg" alt="Videos" width="850" height="478" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>Videos</h2>
    <p>Check out our research story videos and news updates.</p>
    </div>
    
        </a>
        
    </article>
    
    <article>
    
        <a href="https://www.abdn.ac.uk/events/resources/podcast-hub-1634.php" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 1200px)" srcset="/img/850x/news/slideshow-images/podcast_rdax_850x478.jpg"><source media="(min-width: 980px)" srcset="/img/415x/news/slideshow-images/podcast_rdax_850x478.jpg"><source media="(min-width: 800px)" srcset="/img/680x/news/slideshow-images/podcast_rdax_850x478.jpg"><source srcset="/img/500x/news/slideshow-images/podcast_rdax_850x478.jpg"><img src="/img/850x/news/slideshow-images/podcast_rdax_850x478.jpg" alt="Podcasts" width="850" height="478" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>Podcasts</h2>
    <p>Listen to our wide array of thought provoking podcasts.</p>
    </div>
    
        </a>
        
    </article>
    
    <article>
    
        <a href="https://www.abdn.ac.uk/research/impact/" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 1200px)" srcset="/img/850x/news/slideshow-images/student-female-laptop-elphinstone_rdax_850x478.jpg"><source media="(min-width: 980px)" srcset="/img/415x/news/slideshow-images/student-female-laptop-elphinstone_rdax_850x478.jpg"><source media="(min-width: 800px)" srcset="/img/680x/news/slideshow-images/student-female-laptop-elphinstone_rdax_850x478.jpg"><source srcset="/img/500x/news/slideshow-images/student-female-laptop-elphinstone_rdax_850x478.jpg"><img src="/img/850x/news/slideshow-images/student-female-laptop-elphinstone_rdax_850x478.jpg" alt="Research" width="850" height="478" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>Research</h2>
    <p>Find out how our research is making an impact locally and globally.</p>
    </div>
    
        </a>
        
    </article>
    
            </section>
        </div>
    </div>
</div>

    <section class="news_home">
        <div class="abdn_row_padded">
            <div class="abdn_col">
                <div class="feature_box top_story">
                    <div class="feature_box_wrapper">
                        <div class="feature_image">
                            <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/600x337/news/images/features/MRI_patient2.jpg"><source media="(min-width: 640px)" srcset="/img/750x422/news/images/features/MRI_patient2.jpg"><source media="(min-width: 481px)" srcset="/img/600x337/news/images/features/MRI_patient2.jpg"><source media="(min-width: 251px)" srcset="/img/450x254/news/images/features/MRI_patient2.jpg"><source srcset="/img/250x141/news/images/features/MRI_patient2.jpg"><img src="/img/600x337/news/images/features/MRI_patient2.jpg" alt="" loading="lazy"></picture></div>
                        </div>
                        <div class="feature_content">
                            <h2>New MRI dementia test to be trialled for first time</h2>
                            <p>The effectiveness of a new method of identifying Alzheimer's disease is to be trialled for the first time by researchers at the University of Aberdeen.</p>
                            <div class="feature_more">
                                <a href="/news/16464/">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="abdn_row_padded light">
            <div class="abdn_col">
                <div class="feature_3box">
    
        <div class="feature_box">
            <div class="feature_box_wrapper">
                <div class="feature_image">
                    <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/images/features/Geothermal_lake.JPG"><source media="(min-width: 640px)" srcset="/img/450x/news/images/features/Geothermal_lake.JPG"><source media="(min-width: 481px)" srcset="/img/200x/news/images/features/Geothermal_lake.JPG"><source media="(min-width: 251px)" srcset="/img/450x/news/images/features/Geothermal_lake.JPG"><source srcset="/img/250x/news/images/features/Geothermal_lake.JPG"><img src="/img/450x/news/images/features/Geothermal_lake.JPG" alt="" loading="lazy"></picture></div>
                </div>
                <div class="feature_content">
                    <h2>A cold fish won't give you the cold shoulder</h2>
                    <p>New study shows temperature can affect social behaviour.</p>
                    <div class="feature_more">
                        <a href="/news/16460/">Read More</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="feature_box">
            <div class="feature_box_wrapper">
                <div class="feature_image">
                    <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/images/features/Motor_Neuron_Disease.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/images/features/Motor_Neuron_Disease.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/images/features/Motor_Neuron_Disease.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/images/features/Motor_Neuron_Disease.jpg"><source srcset="/img/250x/news/images/features/Motor_Neuron_Disease.jpg"><img src="/img/450x/news/images/features/Motor_Neuron_Disease.jpg" alt="" loading="lazy"></picture></div>
                </div>
                <div class="feature_content">
                    <h2>Gut could sound early warning alarm for motor neuron disease</h2>
                    <p>The same proteins thought to contribute to motor neuron disease can be found in the gut many years before any brain symptoms occur, a new study by the University of Aberdeen has found.</p>
                    <div class="feature_more">
                        <a href="/news/16457/">Read More</a>
                    </div>
                </div>
            </div>
        </div>
        
    <aside class="feature_box">
    
        <h2 class="motif">In other news</h2>
        <ul class="syndicated">
        
            <li>
                <a href="/news/in-brief/16456/" class="clearfix">
            
                <img src="/img/50,sc/news/images/thumbs/EVE_Headshot_002.jpg" width="50" alt="">
                
                    <h3>Business leader Ewan Venters talks rural economy at University event</h3>
                </a>
            </li>
            
            <li>
                <a href="/news/in-brief/16448/" class="clearfix">
            
                <img src="/img/50,sc/news/images/thumbs/George_Boyne_web1.jpg" width="50" alt="">
                
                    <h3>UCEA announces Professor George Boyne as new Chair</h3>
                </a>
            </li>
            
            <li>
                <a href="/news/in-brief/16402/" class="clearfix">
            
                <img src="/img/50,sc/news/images/thumbs/Wilczek_and_Frost.jpg" width="50" alt="">
                
                    <h3>International symposium welcomes Polish ambassador</h3>
                </a>
            </li>
            
            <li>
                <a href="/news/in-brief/16349/" class="clearfix">
            
                <img src="/img/50,sc/news/images/thumbs/luca-bravo-XJXWbfSo2f0-unsplash.jpg" width="50" alt="">
                
                    <h3>Innovative computer collaborative launches in Aberdeen</h3>
                </a>
            </li>
            
            <li>
                <a href="/news/in-brief/16306/" class="clearfix">
            
                <img src="/img/50,sc/news/images/thumbs/Kings_College_campus.jpg" width="50" alt="">
                
                    <h3>Researchers awarded &pound;2.9 million to improve access to injury care in the Global South</h3>
                </a>
            </li>
            
        </ul>
        <div class="feature_more">
            <a href="/news/in-brief/" class="">View More</a>
        </div>
        
                </aside>
            </div>
        </div>
    </div>
    <div class="abdn_row_padded">
        <div class="abdn_col clearfix">
            <div class="news_home_latest">
                <ul class="syndicated_browse">
    
        <li>
            <a href="/news/16458/">
        
            <img src="/img/50,sc/news/images/thumbs/Project_SEARCH_Interns_Trophy_Photo.jpg" width="50" alt="">
            
                <h2>Employment programme for people with learning disabilities and autism wins awards</h2>
                <p>The University of Aberdeen's programme to support young people with a learning disability and autism or both into employment has been recognised with a national award.</p>
            </a>
        </li>
        
        <li>
            <a href="/news/16453/">
        
            <img src="/img/50,sc/news/images/thumbs/107AlexKemp.jpg" width="50" alt="">
            
                <h2>University petro-economist honoured with prestigious international energy award</h2>
                <p>The work of a long-serving University of Aberdeen academic has been recognised with a prestigious international lifetime achievement in energy award.</p>
            </a>
        </li>
        
        <li>
            <a href="/news/16451/">
        
            <img src="/img/50,sc/news/images/thumbs/Missing_persons_poster_resized.jpg" width="50" alt="">
            
                <h2>Research underway to improve missing person identification</h2>
                <p>Researchers from the University of Aberdeen have been awarded funding to look at how the photograph chosen by families of missing persons may impact the likelihood of them being recognised.</p>
            </a>
        </li>
        
        <li>
            <a href="/news/16452/">
        
            <img src="/img/50,sc/news/images/thumbs/Strange_Sickness_banner.jpg" width="50" alt="">
            
                <h2>University of Aberdeen video game in the running for 2022 BAFTA Scotland Awards</h2>
                <p>A video game based on the work of University of Aberdeen historians has been nominated for the 2022 BAFTA Scotland Awards.</p>
            </a>
        </li>
        
        <li>
            <a href="/news/16447/">
        
            <img src="/img/50,sc/news/images/thumbs/medical_science_experiment_1x1.jpg" width="50" alt="">
            
                <h2>University partners new research initiative</h2>
                <p>The University of Aberdeen will work with local partners to establish a Health Determinants Research Collaboration after funding of £5 million was secured.</p>
            </a>
        </li>
        
        <li>
            <a href="/news/16425/">
        
            <img src="/img/50,sc/news/images/thumbs/Hemp_crop.jpg" width="50" alt="">
            
                <h2>Hemp has the potential to make Scotland's agricultural sector carbon neutral</h2>
                <p>Hemp has the potential to make Scotland's agricultural sector carbon neutral as well as providing huge economic benefits, a new report has found.</p>
            </a>
        </li>
        
        <li>
            <a href="/news/16440/">
        
            <img src="/img/50,sc/news/images/thumbs/Wind_farm.jpg" width="50" alt="">
            
                <h2>Energy transition skills training body receives &pound;1m funding boost</h2>
                <p>An initiative involving the University of Aberdeen which aims to provide the energy sector with the skills and talent to meet the challenges of the energy transition has been awarded £1,000,000 by the Scottish Government.</p>
            </a>
        </li>
        
        </ul>
        <div class="feature_more">
            <a href="/news/latest-news.php">View More</a>
        </div>
    </div>
    <section class="the_conversation">
        <h2 class="offscreen">The Conversation</h2>
        <img src="https://www.abdn.ac.uk/global/news/site/images/layout/the-conversation.gif" width="255" height="20" alt="The Conversation">
        <p>The University of Aberdeen is a founding partner of The Conversation UK. See below our academics' articles and opinion pieces on various topics of public interest.</p>
    
            <div class="rss_feed_wrapper">
            
            <ul class="syndicated">
            
                    <li>
                        <a href="https://theconversation.com/ghanas-economic-crisis-expert-insights-into-how-things-got-so-bad-and-what-the-fixes-are-193153" target="_blank">
                            Ghana's economic crisis: expert insights into how things got so bad – and what the fixes are<br>
                            <time datetime="2022-10-25">25 October 2022</time>
                        </a>
                    </li>
                    
                    <li>
                        <a href="https://theconversation.com/climate-change-uk-test-for-new-oil-and-gas-fields-impact-on-emissions-targets-is-not-fit-for-purpose-191803" target="_blank">
                            Climate change: UK test for new oil and gas fields' impact on emissions targets is not fit for purpose<br>
                            <time datetime="2022-10-13">13 October 2022</time>
                        </a>
                    </li>
                    
                    <li>
                        <a href="https://theconversation.com/why-many-ukrainians-speak-russian-as-their-first-language-190856" target="_blank">
                            Why many Ukrainians speak Russian as their first language<br>
                            <time datetime="2022-10-12">12 October 2022</time>
                        </a>
                    </li>
                    
                    <li>
                        <a href="https://theconversation.com/late-night-eating-may-cause-greater-weight-gain-new-research-points-to-why-192114" target="_blank">
                            Late night eating may cause greater weight gain – new research points to why<br>
                            <time datetime="2022-10-12">12 October 2022</time>
                        </a>
                    </li>
                    
                    <li>
                        <a href="https://theconversation.com/ghana-and-the-imf-debt-restructuring-must-go-hand-in-hand-with-managing-finances-better-191877" target="_blank">
                            Ghana and the IMF: debt restructuring must go hand-in-hand with managing finances better<br>
                            <time datetime="2022-10-10">10 October 2022</time>
                        </a>
                    </li>
                    
                    <li>
                        <a href="https://theconversation.com/riset-baru-soal-penurunan-berat-badan-waktu-anda-makan-makanan-terbanyak-miliki-sedikit-efek-190437" target="_blank">
                            Riset baru soal penurunan berat badan: waktu Anda makan makanan terbanyak miliki sedikit efek<br>
                            <time datetime="2022-09-13">13 September 2022</time>
                        </a>
                    </li>
                    
                    <li>
                        <a href="https://theconversation.com/doric-the-scots-dialect-spoken-by-the-queen-what-it-sounds-like-and-where-it-comes-from-190385" target="_blank">
                            Doric: the Scots dialect spoken by the Queen – what it sounds like and where it comes from<br>
                            <time datetime="2022-09-12">12 September 2022</time>
                        </a>
                    </li>
                    
            </ul>
            
            </div>
            
            </section>
        </div>
    </div>
    <div class="abdn_row_padded light">
        <div class="abdn_col clearfix">
            <h2 class="motif tab_heading light">Opinion</h2>
            <div class="feature_3box">
    
            <div class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/images/thumbs/Wind_farm.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/images/thumbs/Wind_farm.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/images/thumbs/Wind_farm.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/images/thumbs/Wind_farm.jpg"><source srcset="/img/250x/news/images/thumbs/Wind_farm.jpg"><img src="/img/450x/news/images/thumbs/Wind_farm.jpg" alt="" loading="lazy"></picture></div>
                    </div>
                    <div class="feature_content">
                        <h2>University's role in tissue bank key to breakthrough of breast cancer research</h2>
                        <p>
I have been fortunate enough to enjoy a 30-year-long career in cancer research and I would absolutely say that my greatest achievement has been my involvement in setting up and running the Breast Cancer Now Tissue Bank (www.breastcancertissuebank.org).&nbsp;&nbsp;


First established in 2010, we opened the Tissue Bank&nbsp;up to researchers in 2012....</p>
                        <div class="feature_more">
                            <a href="/news/opinion/universitys-role-in-tissue-bank-key-to-breakthrough-of-breast-cancer-research/">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/images/thumbs/Wind_farm.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/images/thumbs/Wind_farm.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/images/thumbs/Wind_farm.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/images/thumbs/Wind_farm.jpg"><source srcset="/img/250x/news/images/thumbs/Wind_farm.jpg"><img src="/img/450x/news/images/thumbs/Wind_farm.jpg" alt="" loading="lazy"></picture></div>
                    </div>
                    <div class="feature_content">
                        <h2>Why are chickens used for breeding kept hungry?</h2>
                        <p>&nbsp;
I&rsquo;ve been researching the ethics of farming animals for fifteen years now. That convinced me some time ago that industrial animal agriculture is highly problematic for farmed animals, as well as for human welfare and the climate and biodiversity crises. But details about the systemic cruelty current farming practice inflicts...</p>
                        <div class="feature_more">
                            <a href="/news/opinion/why-are-chickens-used-for-breeding-kept-hungry/">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/opinion/images/features/QM_JBO_cropped.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/opinion/images/features/QM_JBO_cropped.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/opinion/images/features/QM_JBO_cropped.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/opinion/images/features/QM_JBO_cropped.jpg"><source srcset="/img/250x/news/opinion/images/features/QM_JBO_cropped.jpg"><img src="/img/450x/news/opinion/images/features/QM_JBO_cropped.jpg" alt="" loading="lazy"></picture></div>
                    </div>
                    <div class="feature_content">
                        <h2>A generous patron of science whose gift has led to 100 years of ground-breaking nutritional research</h2>
                        <p>Dr David Watts, a Social scientist and historian based in the&nbsp;Rowett Institute, explores the story of the man behind the name of the Institute and how his generous gift a century ago has supported ground-breaking nutritional research for 100 years. &nbsp;&nbsp;
&nbsp;
Although most accounts date the founding of the Rowett Institute...</p>
                        <div class="feature_more">
                            <a href="/news/opinion/a-generous-patron-of-science-whose-gift-has-led-to-100-years-of-groundbreaking-nutritional-research/">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            
            </div>
        </div>
    </div>
        <div class="abdn_row_padded">
            <div class="abdn_col clearfix">
                <div class="news_features">
                    <div class="feature_box">
                        <div class="feature_box_wrapper">
                            <div class="feature_image">
                                <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/feature-images/eu-flag.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/feature-images/eu-flag.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/feature-images/eu-flag.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/feature-images/eu-flag.jpg"><source srcset="/img/250x/news/feature-images/eu-flag.jpg"><img src="/img/450x/news/feature-images/eu-flag.jpg" alt="" loading="lazy"></picture></div>
                            </div>
                            <div class="feature_content">
                                <h2>Brexit</h2>
                                <p>Information following the EU Referendum.</p>
                                <div class="feature_more">
                                    <a href="/news/brexit/">Find Out More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="feature_box">
                        <div class="feature_box_wrapper">
                            <div class="feature_image">
                                <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/https:///www.abdn.ac.uk/news/images/layout/Kings_Crown_Tower.jpg"><source media="(min-width: 640px)" srcset="/img/450x/https:///www.abdn.ac.uk/news/images/layout/Kings_Crown_Tower.jpg"><source media="(min-width: 481px)" srcset="/img/200x/https:///www.abdn.ac.uk/news/images/layout/Kings_Crown_Tower.jpg"><source media="(min-width: 251px)" srcset="/img/450x/https:///www.abdn.ac.uk/news/images/layout/Kings_Crown_Tower.jpg"><source srcset="/img/250x/https:///www.abdn.ac.uk/news/images/layout/Kings_Crown_Tower.jpg"><img src="/img/450x/https:///www.abdn.ac.uk/news/images/layout/Kings_Crown_Tower.jpg" alt="" loading="lazy"></picture></div>
                            </div>
                            <div class="feature_content">
                                <h2>University Facts</h2>
                                <p>The University at a glance.</p>
                                <div class="feature_more">
                                    <a href="/news/fast-facts.php">Find Out More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="feature_box">
                        <div class="feature_box_wrapper">
                            <div class="feature_image">
                                <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/images/layout/rowers.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/images/layout/rowers.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/images/layout/rowers.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/images/layout/rowers.jpg"><source srcset="/img/250x/news/images/layout/rowers.jpg"><img src="/img/450x/news/images/layout/rowers.jpg" alt="" loading="lazy"></picture></div>
                            </div>
                            <div class="feature_content">
                                <h2>Communications Team</h2>
                                <p>Contacts and information for media.</p>
                                <div class="feature_more">
                                    <a href="/news/communications/">Find Out More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="feature_box">
                        <div class="feature_box_wrapper">
                            <div class="feature_image">
                                <div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/news/images/layout/armadillo.jpg"><source media="(min-width: 640px)" srcset="/img/450x/news/images/layout/armadillo.jpg"><source media="(min-width: 481px)" srcset="/img/200x/news/images/layout/armadillo.jpg"><source media="(min-width: 251px)" srcset="/img/450x/news/images/layout/armadillo.jpg"><source srcset="/img/250x/news/images/layout/armadillo.jpg"><img src="/img/450x/news/images/layout/armadillo.jpg" alt="" loading="lazy"></picture></div>
                            </div>
                            <div class="feature_content">
                                <h2>Public Affairs</h2>
                                <p>Contacts and services for policy and political communities.</p>
                                <div class="feature_more">
                                    <a href="/news/public-affairs.php">Find Out More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/news/index.php" class="current" aria-current="page">News</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/news/latest-news.php">Latest News</a></li>
                
                <li><a href="/news/communications/index.php">Communications Team</a></li>
                
                <li><a href="/news/public-affairs.php">Public Affairs</a></li>
                
                <li><a href="/news/opinion/index.php">Opinion</a></li>
                
                <li><a href="/news/brexit/index.php">Life after Brexit</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
</main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/news/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="/global/js/opentext_responsive/slick.js?cb=20221026"></script>
                
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                
                <script src="/global/news/site/js/opentext_responsive/calendar.functions.js"></script>
                    </body>
</html>
