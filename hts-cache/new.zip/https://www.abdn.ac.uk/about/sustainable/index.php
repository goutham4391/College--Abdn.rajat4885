<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Sustainable | About | The University of Aberdeen</title>
    <!-- Page ID : 1662 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/about/" class="section_head_text">
                    About                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="About navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/about/schools-institutes/index.php">Schools and Institutes</a>
            </li>
            
            <li>
                <a href="/about/campus/index.php">Campus</a>
            </li>
            
            <li>
                <a href="/about/strategy-and-governance/index.php" class="current">Strategy and Governance</a>
            </li>
            
            <li>
                <a href="/about/management/index.php">Management</a>
            </li>
            
            <li>
                <a href="/about/facts-figures/index.php">Facts & Figures</a>
            </li>
            
            <li>
                <a href="/about/history/index.php">History</a>
            </li>
            
            <li>
                <a href="/about/contact/index.php">Contact</a>
            </li>
            
            <li>
                <a href="/about/partnerships/index.php">Partnerships</a>
            </li>
            
            <li>
                <a href="/about/coronavirus/index.php">Coronavirus (Covid-19)</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Sustainable</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/about/">About</a></li>
            
            <li><a href="/about/strategy-and-governance/index.php">Strategy and Governance</a></li>
            
            <li tabindex="0" aria-current="page">Sustainable</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="full_width" tabindex="-1">
    
        <div class="section">
          <div class="container">
        
            <div class="h1">Sustainable</div>
            <p><span style="line-height:1.5em"><span style="text-decoration-thickness:initial"><span><span>Our Aberdeen 2040 strategy commits the University to achieving&nbsp;net-zero emissions before 2040.&nbsp;</span></span></span></span>We will show leadership in working for the sustainable future of our planet, setting an example to our sector and to society. We will evaluate all our actions for their impact on the environment, and will meet stretching standards and targets.&nbsp;In an era of significant&nbsp;societal challenges, an effective approach to sustainability will&nbsp;ensure that limited resources are used efficiently,&nbsp;and that activity&nbsp;is conducted&nbsp;in a way that minimises&nbsp;environmental impacts while demonstrating an awareness of&nbsp;ethical and social responsibilities.</p>

<p>We recognise&nbsp;that the sustainability legacy and impact of the University will be measured not only by carbon emissions or landfill tonnage, but by the sustainability of our decision-making, by the quality and global relevance of our research, and by our role in developing active and engaged graduates with the attributes necessary to tackle the challenges facing society. We will also use our resources wisely, plan ahead and secure new sources of income to ensure our University’s financial sustainability.</p>
            </div>
        </div>
        
    <div class="section stats_section theme_dark_grey stats_have_image" style="background-image: url(/img/2000x/about/feature-images/sustainability-background.png);">
        <div class="container">
    <h2 class="optional_heading">Commitments</h2>
    <div class="stats_wrapper">
    
            <div class="stat">
            
            <div class="stat_teaser">Sustainability</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/sustainability_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Encourage everyone within our community to work and live sustainably, recognising the importance of our time, energy and resilience</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Environment</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/environment_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Educate all our students and staff to be leaders in protecting the environment</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Research</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/research_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Excel in research that addresses the climate emergency, enables energy transition and the preservation of biodiversity</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Net zero</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/net-zero_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Achieve net zero carbon emissions before 2040</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Investment</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/investment_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Generate resources for investment in education and research year on year, so that we can continue to develop the people, ideas and actions that help us to fulfil our purpose</p></div>
            
            </div>
            
            </div>
        </div>
    </div>
    <div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="COP26">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/COP26%20Facebook%20800x600_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/COP26%20Facebook%20800x600_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/COP26%20Facebook%20800x600_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/COP26%20Facebook%20800x600_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/COP26%20Facebook%20800x600_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/COP26%20Facebook%20800x600_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>COP26</h2>
                        <p>Find out more about the University's activities at&nbsp;the&nbsp;United Nations&nbsp;Climate Change Conference of the Parties,&nbsp;<a href="https://ukcop26.org/">COP26</a>, which took place&nbsp;in Glasgow from&nbsp;1-12 November 2021.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/research/cop26.php">COP26</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Sustainable Development Goals">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/sustainable%20world_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/sustainable%20world_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/sustainable%20world_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/sustainable%20world_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/sustainable%20world_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/sustainable%20world_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Sustainable Development Goals</h2>
                        <p>The United Nations' Sustainable Development Goals (SDGs) is&nbsp;a framework that informs&nbsp;our academic and operational sustainability activities.</p>                                                    <div class="feature_more">
                                <a href="/about/sustainable/sustainable-development-goals-1668.php">Sustainable Development Goals</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Centre for Energy Transition">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Turbine_4_3_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Turbine_4_3_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Turbine_4_3_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Turbine_4_3_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/Turbine_4_3_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/Turbine_4_3_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Centre for Energy Transition</h2>
                        <p>Our Centre for Energy Transition (CET) is a dynamic&nbsp;research centre that brings the power of interdisciplinary research to bear on the climate crisis.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/energy/">Centre for Energy Transition</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>

    <div class="section stats_section theme_dark_grey stats_have_image" style="background-image: url(/img/2000x/about/feature-images/sustainability-background.png);">
        <div class="container">
    <h2 class="optional_heading">Our Global Sustainability Impact Rankings</h2>
    <div class="stats_wrapper">
    
            <div class="stat">
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>34<sup>th</sup></p>
                </div>
                
            </div>
            
            <div class="stat_heading">In the world for Environmental Impact</div>
            
            <div class="stat_content"><p>QS Sustainability Rankings 2022</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>64<sup>th</sup></p>
                </div>
                
            </div>
            
            <div class="stat_heading">In the world for Sustainability*</div>
            
            <div class="stat_content"><p>QS Sustainability Rankings 2022&nbsp;</p>

<p>*based on the UN’s 17 Sustainable Development Goals</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>182<sup>nd</sup></p>
                </div>
                
            </div>
            
            <div class="stat_heading">In the world for Social Impact</div>
            
            <div class="stat_content"><p>QS Sustainability Rankings 2022</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Top</div>
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>100</p>
                </div>
                
            </div>
            
            <div class="stat_heading">In the world for 8 SDGs</div>
            
            <div class="stat_content"><p>THE Impact Rankings 2022</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Top</div>
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>200</p>
                </div>
                
            </div>
            
            <div class="stat_heading">In the world for positive impact on society</div>
            
            <div class="stat_content"><p>THE Impact Rankings 2022</p></div>
            
            </div>
            
            </div>
        </div>
    </div>
    <div class="section">
    <div class="container">
        <h2 class="optional_heading">Impact through research</h2><div class="optional_content"><p style="text-align:center">Our interdisciplinary research is challenge-led, impactful and built on&nbsp;sustainable partnerships that ensure we can tackle major societal challenges and support the UN's Sustainable Development Goals.</p></div>        <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Energy Transition">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Esprit_4_3_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Esprit_4_3_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Esprit_4_3_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Esprit_4_3_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/Esprit_4_3_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/Esprit_4_3_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Energy Transition</h3>
                        <p>Our energy work provides a focus for all areas of energy-related research, with an emphasis on supporting industry and policy makers in the transition to clean,&nbsp;sustainable energy and renewables.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/research/explore/energy-transition-573.php">Energy Transition Research</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Environment and Biodiversity">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/aerial_trees_4_3_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/aerial_trees_4_3_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/aerial_trees_4_3_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/aerial_trees_4_3_rdax_450x338.jpg"><source srcset="/img/250x/about/feature-images/aerial_trees_4_3_rdax_450x338.jpg"><img src="/img/450x/about/feature-images/aerial_trees_4_3_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Environment and Biodiversity</h3>
                        <p>Our research crosses the broad themes of understanding the fundamental biological and physical consequences of environmental changes, from the gene to global levels and from the Arctic to Antarctic.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/research/explore/environment-biodiversity-574.php">Environment and Biodiversity Research</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>

    <div class="section stats_section theme_dark_grey stats_have_image" style="background-image: url(/img/2000x/about/feature-images/sustainability-background.png);">
        <div class="container">
    <h2 class="optional_heading">Our Environmental Research Impact</h2>
    <div class="stats_wrapper">
    
            <div class="stat">
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>1st</p>
                </div>
                
            </div>
            
            <div class="stat_heading">In Scotland for environmental research impact</div>
            
            <div class="stat_content"><p>QS World Rankings 2022</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <div class="stat_text">
                    <p>1st</p>
                </div>
                
            </div>
            
            <div class="stat_heading">In Scotland for globally collaborative environmental research</div>
            
            <div class="stat_content"><p>QS World Rankings 2022</p></div>
            
            </div>
            
            </div>
        </div>
    </div>
    
<div class="section">
    <div class="container">
    <p><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" frameborder="0" height="315" src="https://www.youtube.com/embed/25TKVvy5LJU" title="YouTube video player" width="560"></iframe></p>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Creating a Sustainable Legacy</h2><div class="optional_content"><p style="text-align:center">The&nbsp;University's sustainability legacy&nbsp;is the impact of our teaching and research and the contribution of our graduates as active, global citizens.</p></div>        <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Energy Online Courses">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Online_4_3_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Online_4_3_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Online_4_3_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Online_4_3_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/Online_4_3_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/Online_4_3_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Energy Online Courses</h3>
                        <p>From degrees to short courses, our energy-related On-Demand courses can help you to learn new skills and progress your career whilst helping to support&nbsp;a sustainable future.</p>                                                    <div class="feature_more">
                                <a href="https://on.abdn.ac.uk/energy/">Energy Online Courses</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: SDG-Related Programmes">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Students_4_3_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Students_4_3_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Students_4_3_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Students_4_3_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/Students_4_3_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/Students_4_3_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>SDG-Related Programmes</h3>
                        <p>The University of Aberdeen offers a wide range of advanced postgraduate programmes that support&nbsp;the UN Sustainable&nbsp;Development Goals.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/research/study-772.php">SDG-related programmes</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Resources for Students">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Environment_4_3_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Environment_4_3_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Environment_4_3_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Environment_4_3_rdax_450x338.jpg"><source srcset="/img/250x/about/feature-images/Environment_4_3_rdax_450x338.jpg"><img src="/img/450x/about/feature-images/Environment_4_3_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Resources for Students</h3>
                        <p>Find out more about how to get involved with AUSA's environmental societies and conservation projects and how to support local campaigns.</p>                                                    <div class="feature_more">
                                <a href="/about/sustainable/students-309.php">Student resources</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">On Campus</h2>        <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: A Sustainable Campus">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/SDRL_4_3_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/SDRL_4_3_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/SDRL_4_3_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/SDRL_4_3_rdax_450x338.jpg"><source srcset="/img/250x/about/feature-images/SDRL_4_3_rdax_450x338.jpg"><img src="/img/450x/about/feature-images/SDRL_4_3_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>A Sustainable Campus</h3>
                        <p>On campus we are working to reduce our energy consumption, improve energy efficiency, reduce waste volumes, support biodiversity,&nbsp;encourage sustainable travel and reduce our carbon footprint.</p>                                                    <div class="feature_more">
                                <a href="/about/sustainable/around-campus-159.php">Campus initiatives</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Sustainable Development Committee">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Kings-College-exterior06_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Kings-College-exterior06_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Kings-College-exterior06_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Kings-College-exterior06_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/Kings-College-exterior06_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/Kings-College-exterior06_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Sustainable Development Committee</h3>
                        <p>The committee co-ordinates the development, implementation and review of the activities which underpin our commitment to sustainability as outlined in the&nbsp;<a href="https://www.abdn.ac.uk/2040/">Aberdeen 2040 strategic plan</a>. &nbsp;</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/staffnet/governance/sustainable-development-committee.php">Sustainable Development Committee</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_1box_2ascii_code">
            <aside class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_about_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Contact Us</h2>
                        <p>If you are in industry and&nbsp;would like to work with us to support a sustainable future, we are keen to hear from you.</p>                        
                            <div class="feature_more">
                                <a href="/about/sustainable/contact-us-1670.php">Get in touch</a>
                            </div>
                                                </div>
                </div>
            </aside>
            <aside class="feature_box">
                
<h2 class="motif">Events</h2>

		<p>There are currently no upcoming Events.</p>
		<p>If you'd like to keep up-to-date with all our events, subscribe to our RSS feed!</p>
		            </aside>
            <aside class="feature_box">
                
<h2 class="motif">News</h2>

        <ul class="syndicated">
        
            <li>
                <a href="/about/sustainable/news/16261/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Maryculter_2.JPG" width="50" alt="">
                    <h3>Aberdeenshire community woodlands could offset carbon emissions of 80 residents</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/sustainable/news/16220/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/ants.jpg" width="50" alt="">
                    <h3>Invasive pests have cost New Zealand billions</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/sustainable/news/16217/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Solar_energy.jpg" width="50" alt="">
                    <h3>Using strength of Greek sun makes sense</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/sustainable/news/16024/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Capuchin.JPG" width="50" alt="">
                    <h3>Hooded capuchin monkey at higher risk of extinction than realised</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/sustainable/news/16158/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/damselflies_mating.jpg" width="50" alt="">
                    <h3>Global warming may not be as bad for animal reproduction as thought, study suggests</h3>
                </a>
            </li>
            
        </ul>
        <div class="feature_more">
            <a href="/about/sustainable/news/">
                More News
            </a>
        </div>
                    </aside>
        </div>
    </div>
</div><div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Divestment from fossil fuel">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Crown_4_3_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Crown_4_3_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Crown_4_3_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Crown_4_3_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/Crown_4_3_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/Crown_4_3_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Divestment from fossil fuel</h2>
                        <p>The University is committed to generating resources for investment in education and research year on year through a responsible and sustainable investment policy, whereby investments achieve the best return possible.&nbsp;</p>                                                    <div class="feature_more">
                                <a href="/about/sustainable/fossil-fuel-divestment.php">Find out more about sustainable investment</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Engaging our Community">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Fairtrade_rdax_450x337.JPG"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Fairtrade_rdax_450x337.JPG"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Fairtrade_rdax_450x337.JPG"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Fairtrade_rdax_450x337.JPG"><source srcset="/img/250x/about/feature-images/Fairtrade_rdax_450x337.JPG"><img src="/img/450x/about/feature-images/Fairtrade_rdax_450x337.JPG" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Engaging our Community</h2>
                        <p>Find out more about our social responsibility initiatives in the local community.</p>                                                    <div class="feature_more">
                                <a href="/about/sustainable/community-engagement-162.php">Find out more about community engagement</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Net Zero Commitment">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/King%27s%20College_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/King%27s%20College_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/King%27s%20College_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/King%27s%20College_rdax_450x338.jpg"><source srcset="/img/250x/about/feature-images/King%27s%20College_rdax_450x338.jpg"><img src="/img/450x/about/feature-images/King%27s%20College_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Net Zero Commitment</h2>
                        <p>Our Aberdeen 2040 strategy commits the University to achieving&nbsp;net-zero emissions before 2040. Our approach will encompass&nbsp;emissions from all&nbsp;sources and all sites associated with the University.</p>

<p>To reiterate this commitment we have also signed the&nbsp;<a href="https://www.sdgaccord.org/climateletter">Global Climate Letter</a>&nbsp;and the&nbsp;<a href="https://www.oneplanetpledge.org/">One Planet Pledge</a>.</p>                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>

<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/about/index.php">About</a></li>
            
            <li><a href="/about/strategy-and-governance/index.php">Strategy and Governance</a></li>
            
            <li><a href="/about/sustainable/index.php" class="current" aria-current="page">Sustainable</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/about/sustainable/sustainable-development-goals-1668.php">SDGs</a></li>
                
                <li><a href="/about/sustainable/students-309.php">Students</a></li>
                
                <li><a href="/about/sustainable/around-campus-159.php">Around Campus</a></li>
                
                <li><a href="/about/sustainable/contact-us-1670.php">Contact Us</a></li>
                
                <li><a href="/about/sustainable/news/index.php">News</a></li>
                
                <li><a href="/about/sustainable/events/index.php">Events</a></li>
                
                <li><a href="/about/sustainable/fossil-fuel-divestment.php">Fossil Fuel Divestment</a></li>
                
                <li><a href="/about/sustainable/community-engagement-162.php">Community and Engagement</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
</main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/about/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
