<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Inclusive | About | The University of Aberdeen</title>
    <!-- Page ID : 1381 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" media="screen">
                    
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" media="screen">
                    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/slick_combined.css?cb=20221026" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
                    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
                    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/about/" class="section_head_text">
                    About                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="About navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/about/schools-institutes/index.php">Schools and Institutes</a>
            </li>
            
            <li>
                <a href="/about/campus/index.php">Campus</a>
            </li>
            
            <li>
                <a href="/about/strategy-and-governance/index.php" class="current">Strategy and Governance</a>
            </li>
            
            <li>
                <a href="/about/management/index.php">Management</a>
            </li>
            
            <li>
                <a href="/about/facts-figures/index.php">Facts & Figures</a>
            </li>
            
            <li>
                <a href="/about/history/index.php">History</a>
            </li>
            
            <li>
                <a href="/about/contact/index.php">Contact</a>
            </li>
            
            <li>
                <a href="/about/partnerships/index.php">Partnerships</a>
            </li>
            
            <li>
                <a href="/about/coronavirus/index.php">Coronavirus (Covid-19)</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Inclusive</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/about/">About</a></li>
            
            <li><a href="/about/strategy-and-governance/index.php">Strategy and Governance</a></li>
            
            <li tabindex="0" aria-current="page">Inclusive</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="full_width" tabindex="-1">
    
        <div class="section">
          <div class="container">
        
            <div class="h1">Inclusive</div>
            <p>In 1495 we were founded on the principle of being open to all and dedicated to the pursuit of truth in the services of others. We still have that purpose and continuously work towards a more inclusive community.</p>

<p>The University is fully committed to equality for all its staff and students.&nbsp; Our commitment to inclusion guides our education, our research, and the projects we deliver. We aspire to lead our sector in promoting health and wellbeing and celebrating diversity. We welcome staff and students of all backgrounds and connect with our communities and partners, locally, nationally and internationally.&nbsp;</p>

<p>This page provides an overview of the University of Aberdeen's commitments, initiatives and resources on equality, diversity and inclusion.</p>
            </div>
        </div>
        
    <div class="section stats_section theme_dark_grey stats_have_image" style="background-image: url(/img/2000x/about/feature-images/inclusive-background.jpg);">
        <div class="container">
    <h2 class="optional_heading">Commitments</h2>
    <div class="stats_wrapper">
    
            <div class="stat">
            
            <div class="stat_teaser">Wellbeing</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/wellbeing_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Care for the wellbeing, health and safety of our diverse community, supporting and developing our people to achieve their full potential</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Access</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/access_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Encourage widening access to study, by having fair and flexible entry routes, offering diverse qualifications, and providing a range of modes of delivery; our students will be able to succeed whatever their personal and social background</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Collaboration</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/collaboration_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Develop a research portfolio that promotes national and international collaboration with stakeholders, including companies, organisations and governments</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Accreditation</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/accreditation_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Secure the highest standards of equality, diversity and inclusion, achieving accreditation across multiple strands and characteristics</p></div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_teaser">Pay</div>
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/pay_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            <div class="stat_content"><p>Eliminate pay gaps across all protected characteristics</p></div>
            
            </div>
            
            </div>
        </div>
    </div>
    
<div class="section">
    <div class="container">
    <p style="text-align:center"><iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" frameborder="0" height="252" src="https://www.youtube.com/embed/ngtgDSNm5Ug" title="YouTube video player" width="448"></iframe></p>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_1box_2ascii_code">
            <aside class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_students_rdax_450x253_2040.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_students_rdax_450x253_2040.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_students_rdax_450x253_2040.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_students_rdax_450x253_2040.jpg"><source srcset="/img/250x/about/feature-images/16x9_students_rdax_450x253_2040.jpg"><img src="/img/450x/about/feature-images/16x9_students_rdax_450x253_2040.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Blogs</h2>
                        <p>A collection of student and staff blogs focused on equality and diversity.</p>                        
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/students/student-channel/blog/category/equality-and-diversity" target="_blank">Read the students blog here</a>

<a href="https://www.abdn.ac.uk/staffnet/teaching/celebrating-diversity/index.php" target="_blank">Read the staff blog here</a>
                            </div>
                                                </div>
                </div>
            </aside>
            <aside class="feature_box">
                
<h2 class="motif">Events</h2>

		<p>There are currently no upcoming Events.</p>
		<p>If you'd like to keep up-to-date with all our events, subscribe to our RSS feed!</p>
		            </aside>
            <aside class="feature_box">
                
<h2 class="motif">News</h2>

        <ul class="syndicated">
        
            <li>
                <a href="/about/inclusive/news/16441/" class="clearfix">
                    <img src="/img/50,sc/global/news/site/images/layout/placeholder.png" width="50" alt="">
                    <h3>Launch of University Antiracism Strategy</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/inclusive/news/16206/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Kings_Red_Sky_16x9.jpg" width="50" alt="">
                    <h3>'Shining Lights' scholarships will help students seeking sanctuary</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/inclusive/news/16176/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Umbrellas_Cruickshank.jpg" width="50" alt="">
                    <h3>Umbrellas celebrating neurodiversity bring additional colour to Cruickshank Botanic Garden</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/inclusive/news/14811/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/University_gaelic_sign.jpg" width="50" alt="">
                    <h3>University joins network to support Gaelic community officers</h3>
                </a>
            </li>
            
            <li>
                <a href="/about/inclusive/news/14790/" class="clearfix">
                    <img src="/img/50,sc/news/images/thumbs/Benin_bronze_resized.jpg" width="50" alt="">
                    <h3>University to return Benin bronze</h3>
                </a>
            </li>
            
        </ul>
        <div class="feature_more">
            <a href="/about/inclusive/news/">
                More News
            </a>
        </div>
                    </aside>
        </div>
    </div>
</div><div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Equality Network Groups">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/shutterstock_1890861754_rdax_450x270.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/shutterstock_1890861754_rdax_450x270.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/shutterstock_1890861754_rdax_450x270.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/shutterstock_1890861754_rdax_450x270.jpg"><source srcset="/img/250x/about/feature-images/shutterstock_1890861754_rdax_450x270.jpg"><img src="/img/450x/about/feature-images/shutterstock_1890861754_rdax_450x270.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Equality Network Groups</h2>
                        <ul>
	<li>Disability Network</li>
	<li>LGBT Staff Network</li>
	<li>Menopause Support</li>
	<li>Parents and Carers Network</li>
	<li>Race Network</li>
	<li>Women's Development Network</li>
</ul>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/staffnet/working-here/Staff-equality-networks-and-committees.php" target="_blank">More information here</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Widening Access">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/website_rdax_450x300_2040.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/website_rdax_450x300_2040.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/website_rdax_450x300_2040.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/website_rdax_450x300_2040.jpg"><source srcset="/img/250x/about/feature-images/website_rdax_450x300_2040.jpg"><img src="/img/450x/about/feature-images/website_rdax_450x300_2040.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Widening Access</h2>
                        <p>The University of Aberdeen has a long-standing commitment to Widening Access to Higher Education. As an Institution we aim to create an outstanding and inclusive educational environment, to ensure every student has the opportunity to reach their potential.&nbsp;</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/study/undergraduate/widening-access.php" target="_blank">More information here</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Resources for Students and Staff</h2>        <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: For Staff">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/staff-edi-image_rdax_450x300.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/staff-edi-image_rdax_450x300.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/staff-edi-image_rdax_450x300.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/staff-edi-image_rdax_450x300.jpg"><source srcset="/img/250x/about/feature-images/staff-edi-image_rdax_450x300.jpg"><img src="/img/450x/about/feature-images/staff-edi-image_rdax_450x300.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>For Staff</h3>
                        <p>The staff equality, diversity and inclusion page is a repository of information that covers legislative frameworks, action plans, training and support for staff and provides access to relevant University commitments, communications and consultations.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/staffnet/working-here/equality-diversity-and-inclusion.php" target="_blank">Find resources and contacts on equality, diversity and inclusion for staff here</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: For Students">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/students-edi_rdax_450x300.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/students-edi_rdax_450x300.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/students-edi_rdax_450x300.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/students-edi_rdax_450x300.jpg"><source srcset="/img/250x/about/feature-images/students-edi_rdax_450x300.jpg"><img src="/img/450x/about/feature-images/students-edi_rdax_450x300.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>For Students</h3>
                        <p>The student equality, diversity and inclusion page contains information about available student support services, counselling, reporting and feedback, as well as links to informative stories on various equality, diversity and inclusivity topics.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/students/support/equality-diversity-inclusion.php" target="_blank">Find resources and contacts on equality, diversity and inclusion for students here</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>

    <div class="section stats_section theme_dark_grey">
        <div class="container">
    <h2 class="optional_heading">Initiatives</h2>
    <div class="stats_wrapper">
    
            <div class="stat">
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/athena-swan_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/rec-charter_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/stonewall_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/disability-confident_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            </div>
            
            <div class="stat">
            
            <div class="stat_highlight">
            
                <img src="/about/feature-images/emily-test_rdax_100.png" alt="" class="stat_image">
                
            </div>
            
            </div>
            
            </div>
        </div>
    </div>
    <div class="section">
    <div class="container">
<div class="slider">
    <section class="slick_slideshow slick_not_loaded">

    <article>
    <iframe title="Video: University Antiracism Strategy" width="560" height="315" src="https://www.youtube.com/embed/_p3T9-RV_tA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <a href="https://eur03.safelinks.protection.outlook.com/?url=https%3A%2F%2Femail.abdn-online.ac.uk%2F5EH4-NJ64-3AGT4W-HW1SN-1%2Fc.aspx&amp;data=05%7C01%7Cmarin.pasaric%40abdn.ac.uk%7C40d58a3f1ce64c8548fa08daaaa00012%7C8c2b19ad5f9c49d490773ec3cfc52b3f%7C0%7C0%7C638009901410696214%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&amp;sdata=0o8SrJmNOVOpZopBiGTV1Gf8uiKGglppQhi0%2BBpdQSY%3D&amp;reserved=0" class="linked_video">
        
    <div class="feature_content">
    <h2>University Antiracism Strategy</h2>
    <p>Our goal of creating an antiracist culture and ethos on campus moves a step forward with the formal launch of our Antiracism Strategy 2022-2025. </p>
    </div>
    
        </a>
        
    </article>
    
            </section>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Black History Month">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/BHM22_rdax_450x338.png"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/BHM22_rdax_450x338.png"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/BHM22_rdax_450x338.png"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/BHM22_rdax_450x338.png"><source srcset="/img/250x/about/feature-images/BHM22_rdax_450x338.png"><img src="/img/450x/about/feature-images/BHM22_rdax_450x338.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Black History Month</h2>
                        <p><span style="color:#444444; display:inline !important; font-family:&quot;Source Sans Pro&quot;,sans-serif; text-decoration-color:initial; text-decoration-thickness:initial">A programme of events, blogs, podcasts and talks which will provide opportunities for our community to engage with the ethos of Black History Month - to be Proud To Be.</span></p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/events/bhm/index.php" target="_blank">Celebrate with us</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: International Women's Day">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/iwd_rdax_450x337.jpeg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/iwd_rdax_450x337.jpeg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/iwd_rdax_450x337.jpeg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/iwd_rdax_450x337.jpeg"><source srcset="/img/250x/about/feature-images/iwd_rdax_450x337.jpeg"><img src="/img/450x/about/feature-images/iwd_rdax_450x337.jpeg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>International Women's Day</h2>
                        <p>International Women's Day falls on the 8th of March each year, has been celebrated across the world since the early 1900's. Relive our inspring events from the latest annual International Women's Day celebration.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/events/international-womens-day-1953.php">International Women's Day page</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Wellbeing Toolkit">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/wellbeing%20toolkit_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/wellbeing%20toolkit_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/wellbeing%20toolkit_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/wellbeing%20toolkit_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/wellbeing%20toolkit_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/wellbeing%20toolkit_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Wellbeing Toolkit</h2>
                        <p>Maintaining our mental wellbeing can be difficult, and it’s difficult in different ways for different people. On the Wellbeing Toolkit pages, you'll find a lot of ideas to help you with your Wellbeing, such as connecting with others, learning new skills or being more active.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/students/support/winter-wellbeing-toolkit-4992.php" name="Student Wellbeing Toolkit page" target="_blank" title="Student Wellbeing Toolkit page">Access the Student Wellbeing Toolkit here</a>

<a href="https://www.abdn.ac.uk/staffnet/working-here/wellbeing-portal/" name="Employee Wellbeing page" target="_blank" title="Employee Wellbeing page">Access the Employee&nbsp;Wellbeing page&nbsp;here</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: BeWell Podcasts">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/podcast%20series%20(2)_rdax_450x253.jpeg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/podcast%20series%20(2)_rdax_450x253.jpeg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/podcast%20series%20(2)_rdax_450x253.jpeg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/podcast%20series%20(2)_rdax_450x253.jpeg"><source srcset="/img/250x/about/feature-images/podcast%20series%20(2)_rdax_450x253.jpeg"><img src="/img/450x/about/feature-images/podcast%20series%20(2)_rdax_450x253.jpeg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>BeWell Podcasts</h2>
                        <p>The BeWell Podcast series focuses on topical wellbeing issues from student pressure points to national wellbeing campaigns. The series is hosted by Wellbeing Adviser Bekah Walker who is joined each week by guest speakers from our staff and student community.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/students/support/bewell-podcasts-5089.php" target="_blank">Listen to the podcasts here</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Teaching and Learning">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Aberdeen2040-4x3_rdax_450x338_2040.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Aberdeen2040-4x3_rdax_450x338_2040.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Aberdeen2040-4x3_rdax_450x338_2040.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Aberdeen2040-4x3_rdax_450x338_2040.jpg"><source srcset="/img/250x/about/feature-images/Aberdeen2040-4x3_rdax_450x338_2040.jpg"><img src="/img/450x/about/feature-images/Aberdeen2040-4x3_rdax_450x338_2040.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Teaching and Learning</h2>
                        <p>We ensure that our written or recorded information is inclusive and accessible to all students.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/staffnet/teaching/accessibility-7775.php" target="_blank">Find out more about teaching and learning here</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Online Reporting Tool">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/report%20and%20support_rdax_450x337.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/report%20and%20support_rdax_450x337.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/report%20and%20support_rdax_450x337.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/report%20and%20support_rdax_450x337.jpg"><source srcset="/img/250x/about/feature-images/report%20and%20support_rdax_450x337.jpg"><img src="/img/450x/about/feature-images/report%20and%20support_rdax_450x337.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Online Reporting Tool</h2>
                        <p>The University does not tolerate any form of discrimination and&nbsp;will do all that we can to support students and staff who have been affected by any acts of harassment, bullying, violence and sexual misconduct at any time and anywhere. Use our confidential online tool to report any incidents of this type.</p>                                                    <div class="feature_more">
                                <a href="/about/inclusive/support/index.php">Find out more on our Online Reporting Tool pages</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Public Sector Equality Duty Progress">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/E-D-image204043_rdax_450x337.png"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/E-D-image204043_rdax_450x337.png"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/E-D-image204043_rdax_450x337.png"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/E-D-image204043_rdax_450x337.png"><source srcset="/img/250x/about/feature-images/E-D-image204043_rdax_450x337.png"><img src="/img/450x/about/feature-images/E-D-image204043_rdax_450x337.png" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Public Sector Equality Duty Progress</h2>
                        <p>The University of Aberdeen commits to taking bold, ambitious and effective action to support its work on equality, diversity and inclusion and to create a safe, respectful culture in which its community can work and study.&nbsp; This includes proactively challenging inappropriate behaviour and systemic inequalities.&nbsp;</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/staffnet/working-here/public-sector-equality-duty-13340.php" target="_blank">Find out more here</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
                <div class="feature_listbox">
            <aside class="feature_box" aria-label="Governance">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/Aberdeen-2040_4_3_rdax_450x338.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/Aberdeen-2040_4_3_rdax_450x338.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/Aberdeen-2040_4_3_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/Aberdeen-2040_4_3_rdax_450x338.jpg"><source srcset="/img/250x/about/feature-images/Aberdeen-2040_4_3_rdax_450x338.jpg"><img src="/img/450x/about/feature-images/Aberdeen-2040_4_3_rdax_450x338.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h2>Governance</h2>
                        <p>The Equality, Diversity and Inclusion Committee is responsible for the strategic direction of all Equality, Diversity and Inclusion activities supporting the Aberdeen 2040 strategy.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/staffnet/governance/equality-diversity-and-inclusion-committee-9357.php" target="_blank">Find out more about the Committees work here</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>

<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/about/index.php">About</a></li>
            
            <li><a href="/about/strategy-and-governance/index.php">Strategy and Governance</a></li>
            
            <li><a href="/about/inclusive/index.php" class="current" aria-current="page">Inclusive</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/about/inclusive/news/index.php">News</a></li>
                
                <li><a href="/about/inclusive/events/index.php">Events</a></li>
                
                <li><a href="/about/inclusive/support/index.php">Online Reporting Tool</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
</main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/about/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="/global/js/opentext_responsive/slick.js?cb=20221026"></script>
                
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
