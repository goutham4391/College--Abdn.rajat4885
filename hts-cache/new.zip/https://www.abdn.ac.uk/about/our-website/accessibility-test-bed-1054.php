<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Accessibility Test Bed | About | The University of Aberdeen</title>
    <!-- Page ID : 1054 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
        <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/tabcordion.css?cb=20221026" media="screen">
                    
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" media="screen">
                    
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" media="screen">
                    
                    <link rel="stylesheet" href="/global/css/opentext_responsive/slick_combined.css?cb=20221026" media="screen">
                        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
                    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
                    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/about/" class="section_head_text">
                    About                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="About navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/about/schools-institutes/index.php">Schools and Institutes</a>
            </li>
            
            <li>
                <a href="/about/campus/index.php">Campus</a>
            </li>
            
            <li>
                <a href="/about/strategy-and-governance/index.php">Strategy and Governance</a>
            </li>
            
            <li>
                <a href="/about/management/index.php">Management</a>
            </li>
            
            <li>
                <a href="/about/facts-figures/index.php">Facts & Figures</a>
            </li>
            
            <li>
                <a href="/about/history/index.php">History</a>
            </li>
            
            <li>
                <a href="/about/contact/index.php">Contact</a>
            </li>
            
            <li>
                <a href="/about/partnerships/index.php">Partnerships</a>
            </li>
            
            <li>
                <a href="/about/coronavirus/index.php">Coronavirus (Covid-19)</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Accessibility Test Bed</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/about/">About</a></li>
            
            <li><a href="/about/our-website/index.php">Our Website</a></li>
            
            <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
            
            <li tabindex="0" aria-current="page">Accessibility Test Bed</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">Accessibility Test Bed</div>
                        <p>This page is a test bed for identifying improvements to the University's online accessibility and does not form part of the main site. If you find yourself here, please return to the previous page or, for help using our website, visit our <a href="/about/our-website/a11y.php">Accessibility Help Page</a>.</p>

<p>&nbsp;</p>

<p>Example skip to <a href="#" id="this_must_be_unique">Feature List Box Test</a></p>
<script>
$('#this_must_be_unique').click(function(e){
    var jump = $( "h2:contains('Feature List Box Test')" )
    var new_position = $(jump).offset();
    $('html, body').stop().animate({ scrollTop: new_position.top }, 500);
    e.preventDefault();
});
</script>
                        </div>
                    </div>
                    <div class="section">
    <div class="container">
        <h2 class="optional_heading">Tab Wrapper Test B</h2>        <div class="tabs_wrapper">
            <section id="tab_group_1091" class="tab_group">
                <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                            <dt>
                                <a href="#panel1097">Tab 1</a>
                            </dt>
                            <dd id="panel1097">
                            <p>Praesent tristique quam sit amet urna bibendum scelerisque. Proin magna lectus, finibus ut lacus nec, condimentum vestibulum urna. In scelerisque nec dolor vel tempus. Duis accumsan enim a libero posuere ultrices.</p>

<p><picture class="imgproxy" style="float:right"><source media="(min-width: 481px)" srcset="/img/780x/about/content-images/chapel-background.jpg"><source media="(min-width: 251px)" srcset="/img/481x/about/content-images/chapel-background.jpg"><source srcset="/img/200x/about/content-images/chapel-background.jpg"><img src="/img/780x/about/content-images/chapel-background.jpg" alt="" width="220" height="332" loading="lazy"></picture>Pellentesque elementum finibus tellus ut rhoncus. Morbi sed elementum odio, at dignissim turpis. Aliquam et tortor consectetur, bibendum leo nec, consequat enim. Nulla finibus dictum sollicitudin. Donec sed bibendum velit, ac posuere magna.</p>

<p>Maecenas interdum malesuada ipsum et malesuada. Curabitur magna diam, lacinia quis lobortis eget, commodo eu nisi. Mauris malesuada quis diam vel egestas. Praesent fringilla felis lacus, sed fringilla elit porta vitae.</p>
                                <div class="feature_more">
                                    <a href="https://www.abdn.ac.uk/">More Information</a>
                                </div>
                                
                            </dd>
                            
                            <dt>
                                <a href="#panel1096">Tab 2</a>
                            </dt>
                            <dd id="panel1096">
                            <p>Sed efficitur ligula dignissim porttitor pellentesque. Vivamus tempor lorem quis nisi vulputate, eget ultrices nulla aliquam. Nam blandit ut metus vitae vehicula. Curabitur gravida sollicitudin consectetur. Vestibulum sollicitudin commodo neque, ac scelerisque ipsum. Praesent ut velit ex. Donec euismod dignissim risus at egestas. Sed molestie tortor vitae hendrerit consequat. Sed condimentum ante tellus, at venenatis justo malesuada sit amet.</p>

<p>Maecenas ac justo nibh. Cras ultrices, sem sed malesuada dignissim, mi nunc euismod lacus, quis venenatis neque nunc auctor justo. Nunc lacinia ligula at imperdiet aliquet.</p>
                                <div class="feature_more">
                                    <a href="https://www.abdn.ac.uk/">More Information</a>
                                </div>
                                
                            </dd>
                            
                            <dt>
                                <a href="#panel1095">Tab 3</a>
                            </dt>
                            <dd id="panel1095">
                            <p>Suspendisse potenti. Cras congue sit amet leo vitae vestibulum. Etiam imperdiet lacus a bibendum volutpat. Aenean vehicula, dolor quis fringilla imperdiet, nulla est tempus nunc, eget lacinia arcu dolor nec sem. Maecenas porta vestibulum tempor. Proin non lacus ac augue lacinia porta. Maecenas ut interdum augue.</p>

<p>In urna sapien, convallis ut eleifend eget, blandit gravida nunc. Fusce interdum purus in tortor ullamcorper, a euismod magna consequat.</p>
                                <div class="feature_more">
                                    <a href="https://www.abdn.ac.uk/">More Information</a>
                                </div>
                                
                            </dd>
                            
                            <dt>
                                <a href="#panel1094">Tab 4</a>
                            </dt>
                            <dd id="panel1094">
                            <p>Nullam blandit, neque eu sollicitudin hendrerit, magna quam volutpat sem, vitae condimentum nunc elit quis nisi.</p>

<p>Sed euismod turpis urna, quis elementum nisl ornare nec. Mauris efficitur tortor vitae hendrerit sollicitudin. Sed iaculis lorem quis justo posuere, scelerisque porttitor turpis auctor. Quisque dapibus aliquet quam, et hendrerit dolor interdum vel. Quisque eu viverra tortor, at commodo dolor. Morbi aliquet purus ut ante tempor condimentum.</p>
                                <div class="feature_more">
                                    <a href="https://www.abdn.ac.uk/">More Information</a>
                                </div>
                                
                            </dd>
                            
                            <dt>
                                <a href="#panel1093">Tab 5</a>
                            </dt>
                            <dd id="panel1093">
                            <p>Praesent ac pretium ex. Curabitur mi dui, pellentesque at tellus vel, viverra vehicula augue. In hac habitasse platea dictumst. Nullam eros justo, fringilla vel mi eu, lacinia tempor lectus. Donec nec enim id justo pharetra accumsan. Duis egestas consectetur vulputate. Vestibulum venenatis venenatis tortor eget suscipit. Quisque sit amet vehicula sem.</p>

<p>Praesent sagittis diam nec sodales euismod. Duis tincidunt leo ac nibh vestibulum malesuada.</p>
                            </dd>
                            
                            <dt>
                                <a href="#panel1092">Tab 6 has a really long title to make it an accordion</a>
                            </dt>
                            <dd id="panel1092">
                            <p>Phasellus pharetra enim at metus tristique fermentum. Nam nisi tortor, consectetur eu interdum vel, mattis sit amet orci. Nunc in efficitur sapien, nec molestie sapien. Aliquam pellentesque in ligula a maximus.</p>

<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Curabitur tincidunt enim enim, eu rhoncus nunc rhoncus ut.</p>
                            </dd>
                                            </dl>
            </section>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Tab Wrapper Test A</h2><div class="optional_content"><p>A few tabs</p></div>        <div class="tabs_wrapper">
            <section id="tab_group_1088" class="tab_group">
                <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                            <dt>
                                <a href="#panel1090">Tab 1</a>
                            </dt>
                            <dd id="panel1090">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean a diam et elit dapibus luctus vel vel sem. Curabitur non tellus mauris. Praesent tristique quam sit amet urna bibendum scelerisque.</p>

<p>Proin magna lectus, finibus ut lacus nec, condimentum vestibulum urna. In scelerisque nec dolor vel tempus. Duis accumsan enim a libero posuere ultrices. Pellentesque elementum finibus tellus ut rhoncus.</p>
                                <div class="feature_more">
                                    <a href="https://www.abdn.ac.uk/">More Information</a>
                                </div>
                                
                            </dd>
                            
                            <dt>
                                <a href="#panel1089">Tab 2</a>
                            </dt>
                            <dd id="panel1089">
                            <p>Morbi sed elementum odio, at dignissim turpis. Aliquam et tortor consectetur, bibendum leo nec, consequat enim. Nulla finibus dictum sollicitudin. Donec sed bibendum velit, ac posuere magna. Maecenas interdum malesuada ipsum et malesuada. Curabitur magna diam, lacinia quis lobortis eget, commodo eu nisi.</p>

<p>Mauris malesuada quis diam vel egestas. Praesent fringilla felis lacus, sed fringilla elit porta vitae.</p>
                                <div class="feature_more">
                                    <a href="https://www.abdn.ac.uk/">More Information</a>
                                </div>
                                
                            </dd>
                                            </dl>
            </section>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
<div class="slider">
    <section class="slick_slideshow slick_not_loaded">

    <article>
    <iframe title="Video: Video Slide" width="560" height="315" src="https://www.youtube.com/embed/YjwWEBZzcZM" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <a href="https://www.abdn.ac.uk/" class="linked_video">
        
    <div class="feature_content">
    <h2>Video Slide</h2>
    <p>Celebrating 525 Years</p>
    </div>
    
        </a>
        
    </article>
    
    <article>
    
        <a href="https://www.abdn.ac.uk/" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/slideshow-images/Able_4-edit_rdax_850x637.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/slideshow-images/Able_4-edit_rdax_850x637.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/slideshow-images/Able_4-edit_rdax_850x637.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/slideshow-images/Able_4-edit_rdax_850x637.jpg"><source srcset="/img/250x/about/slideshow-images/Able_4-edit_rdax_850x637.jpg"><img src="/img/450x/about/slideshow-images/Able_4-edit_rdax_850x637.jpg" alt="Slide 2" width="850" height="637" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>Slide 2</h2>
    <p>Slide 2 content</p>
    </div>
    
        </a>
        
    </article>
    
    <article>
    
        <a href="https://www.abdn.ac.uk/" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/slideshow-images/Bus_Stop_rdax_850x563.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/slideshow-images/Bus_Stop_rdax_850x563.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/slideshow-images/Bus_Stop_rdax_850x563.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/slideshow-images/Bus_Stop_rdax_850x563.jpg"><source srcset="/img/250x/about/slideshow-images/Bus_Stop_rdax_850x563.jpg"><img src="/img/450x/about/slideshow-images/Bus_Stop_rdax_850x563.jpg" alt="Slide 3" width="850" height="563" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>Slide 3</h2>
    <p>Slide 3 content</p>
    </div>
    
        </a>
        
    </article>
    
    <article>
    
        <a href="https://www.abdn.ac.uk/" class="linked_slide">
        <div class="feature_image"><div><picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/slideshow-images/campus.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/slideshow-images/campus.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/slideshow-images/campus.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/slideshow-images/campus.jpg"><source srcset="/img/250x/about/slideshow-images/campus.jpg"><img src="/img/450x/about/slideshow-images/campus.jpg" alt="Slide 4" width="500" height="281" loading="lazy"></picture></div></div>
    <div class="feature_content">
    <h2>Slide 4</h2>
    <p>Slide 4 content</p>
    </div>
    
        </a>
        
    </article>
    
            </section>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature List Box Test</h2><div class="optional_content"><p>Aenean viverra consequat libero, sit amet sodales velit gravida quis. Nam non eleifend nibh. Curabitur sagittis erat felis, at consectetur ante tincidunt et.</p>

<p>Sed maximus ante eu dui ullamcorper rhoncus. Vestibulum id nulla sapien. Cras vel risus et nulla cursus tincidunt. Aliquam erat volutpat. Nullam viverra purus nunc, non convallis turpis venenatis a.</p></div>        <div class="feature_listbox">
            <aside class="feature_box" aria-label="List Box Heading">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/cops_16x9.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/cops_16x9.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/cops_16x9.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/cops_16x9.jpg"><source srcset="/img/250x/about/feature-images/cops_16x9.jpg"><img src="/img/450x/about/feature-images/cops_16x9.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>List Box Heading</h3>
                        <p>Donec eu justo blandit, convallis lorem non, finibus sapien. Ut aliquet, quam sed pharetra luctus, enim purus dapibus mi, ut ultrices orci neque quis augue. In fringilla quam ac consectetur mollis. Vivamus vulputate dolor metus, et rutrum diam elementum vitae. Quisque ultricies consectetur magna, quis rhoncus enim. Aliquam eu nisi eu arcu egestas pellentesque at quis metus.</p>

<p>Donec convallis mauris id leo tempus mollis. Aenean commodo odio turpis, in blandit mi imperdiet ut. Nam non orci faucibus, tincidunt dui sed, suscipit augue. Cras magna nunc, accumsan at tempus in, facilisis vitae lacus. Donec vulputate ultrices cursus. Aenean imperdiet fermentum pharetra. Cras sed risus consequat, maximus ex fringilla, venenatis sapien.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature 3 Box Test</h2><div class="optional_content"><p>Nunc quis leo dui. Nunc ultricies viverra tellus id laoreet. Nam placerat nisl id lectus consectetur aliquam commodo et dolor. Nullam suscipit consequat tempus. Nulla accumsan leo vel augue laoreet, non venenatis lorem fringilla. Donec quis ipsum vel lectus mattis pellentesque lobortis at ex.</p>

<p>Aenean auctor et sem non convallis. In hac habitasse platea dictumst. Integer sed leo a ipsum consectetur euismod vel quis ex. Phasellus pretium metus nunc, luctus finibus risus laoreet a. Quisque quis consequat lacus. Nulla mollis, erat eget ornare dignissim, diam justo scelerisque lacus, eu tempus libero dui et eros.</p></div>        <div class="feature_3box">
            <aside class="feature_box" aria-label="Feature box: Box 1">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_business_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_business_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_business_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_business_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_business_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_business_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Box 1</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Box 2">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_popular_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Box 2</h3>
                        <p>Nulla varius tristique pulvinar. Quisque vitae massa lectus.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Box 3">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_research_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_research_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_research_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_research_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_research_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_research_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Box 3</h3>
                        <p>Vivamus suscipit metus sed est egestas vehicula. Aenean et elit est. Etiam in congue lectus. Proin fermentum nisl et egestas faucibus.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature 2 Box plus Tabs Test A</h2><div class="optional_content"><p>This test only a few tabs</p></div>        <div class="feature_tabs_2box">
            <aside class="feature_box" aria-label="Feature box: Feature Box 1">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_about_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Feature Box 1</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla varius tristique pulvinar. Quisque vitae massa lectus. Aliquam ac ex ut dolor rhoncus auctor nec ut velit.</p>

<p>Mauris mattis aliquam erat, nec tincidunt urna dignissim a. Donec diam est, placerat sed feugiat in, dictum et massa. Vivamus suscipit metus sed est egestas vehicula. Aenean et elit est. Etiam in congue lectus. Proin fermentum nisl et egestas faucibus.</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Feature Box 2">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Feature Box 2</h3>
                        <p>Sed ut dapibus diam, vitae dictum tellus. Proin pulvinar, tortor a commodo fermentum, urna risus lacinia urna, et mollis quam nunc in magna.</p>

<p>Maecenas efficitur libero efficitur, volutpat velit sed, pulvinar nisl. In pellentesque ipsum velit, euismod finibus risus blandit non. Nunc ultricies volutpat ullamcorper. Praesent ut velit eget dolor sollicitudin aliquam. Sed ut finibus nibh.</p>                                            </div>
                </div>
            </aside>
            <div class="feature_tabs">
                <div class="tabs_wrapper">
                    
                    <section id="tab_group_1078" class="tab_group">
                        <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                        <dt>
                            <a href="#panel1080">Tab 1</a>
                        </dt>
                        <dd id="panel1080">
                        <p>Aenean viverra consequat libero, sit amet sodales velit gravida quis. Nam non eleifend nibh. Curabitur sagittis erat felis, at consectetur ante tincidunt et. Sed maximus ante eu dui ullamcorper rhoncus. Vestibulum id nulla sapien. Cras vel risus et nulla cursus tincidunt.</p>

<p>Aliquam erat volutpat. Nullam viverra purus nunc, non convallis turpis venenatis a. Donec eu justo blandit, convallis lorem non, finibus sapien. Ut aliquet, quam sed pharetra luctus, enim purus dapibus mi, ut ultrices orci neque quis augue. In fringilla quam ac consectetur mollis. Vivamus vulputate dolor metus, et rutrum diam elementum vitae. Quisque ultricies consectetur magna, quis rhoncus enim. Aliquam eu nisi eu arcu egestas pellentesque at quis metus.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        <dt>
                            <a href="#panel1079">Tab 2</a>
                        </dt>
                        <dd id="panel1079">
                        <p>Donec convallis mauris id leo tempus mollis. Aenean commodo odio turpis, in blandit mi imperdiet ut. Nam non orci faucibus, tincidunt dui sed, suscipit augue.</p>

<p>Cras magna nunc, accumsan at tempus in, facilisis vitae lacus. Donec vulputate ultrices cursus. Aenean imperdiet fermentum pharetra. Cras sed risus consequat, maximus ex fringilla, venenatis sapien.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        </dl>
                    </section>
                                    </div>
            </div>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature 2 Box plus Tabs Test B</h2><div class="optional_content"><p>This test has many&nbsp;tabs.</p></div>        <div class="feature_tabs_2box">
            <aside class="feature_box" aria-label="Feature box: First Feature Box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_students_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_students_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_students_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_students_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_students_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_students_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>First Feature Box</h3>
                        <p>Nam malesuada non erat non ultricies. Phasellus laoreet eget ligula vel aliquet. Pellentesque arcu felis, placerat eu facilisis ut, vulputate eget nibh.</p>

<p>Vivamus vulputate ligula vel elit rhoncus varius eu vitae eros. Cras ut congue nisl, in sollicitudin enim. Morbi ullamcorper lectus elit, sed rutrum nisi congue ut. Praesent non orci ante.</p>                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Second Feature Box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_popular_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Second Feature Box</h3>
                        <p>Cras vitae enim maximus, aliquam libero nec, ultricies ligula. Curabitur maximus porttitor erat, quis venenatis mi elementum eget. Pellentesque non ante id quam tempus feugiat.</p>

<p>Nam pharetra elementum metus, at pharetra odio malesuada eu.</p>                                            </div>
                </div>
            </aside>
            <div class="feature_tabs">
                <div class="tabs_wrapper">
                    
                    <section id="tab_group_1071" class="tab_group">
                        <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                        <dt>
                            <a href="#panel1072">Tab 1</a>
                        </dt>
                        <dd id="panel1072">
                        <p>Etiam tellus mauris, porttitor ut orci vitae, vulputate tempor mauris. Phasellus dictum, nibh non varius malesuada, urna dolor maximus risus, vel cursus libero diam imperdiet elit. Suspendisse accumsan mauris et tellus eleifend, in consectetur tortor aliquam. In rutrum scelerisque pellentesque.</p>

<p>Aenean venenatis augue arcu, ac tempus ex consectetur nec. Aliquam pulvinar turpis justo, ac gravida nulla finibus vel. Pellentesque faucibus tortor quis nunc suscipit facilisis. Praesent et eros elit.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        <dt>
                            <a href="#panel1073">Tab 2</a>
                        </dt>
                        <dd id="panel1073">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam pretium feugiat sem ut sagittis. Quisque pretium est est, ut sollicitudin elit scelerisque non.</p>

<p>Vivamus posuere nulla non mauris gravida, eu sodales est imperdiet. Sed vestibulum imperdiet leo tempor tincidunt. Integer arcu sapien, bibendum vitae enim a, rutrum ornare lacus. Vivamus non urna vitae odio maximus accumsan vitae varius mi. Duis sit amet ullamcorper eros, at ornare sem. Donec odio magna, facilisis id lectus sollicitudin, eleifend sodales leo. Mauris vel molestie tortor.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        <dt>
                            <a href="#panel1074">Tab 3</a>
                        </dt>
                        <dd id="panel1074">
                        <p>Mauris nec tortor lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut dui quam, consectetur ac rhoncus ac, ultricies eu orci. Quisque feugiat ut orci sed convallis. Suspendisse mollis posuere tincidunt. Sed euismod posuere orci, quis porta nunc condimentum ut.</p>

<p>Aliquam erat volutpat. Cras auctor dapibus sodales. Nullam erat ipsum, hendrerit eget nibh placerat, pharetra tempus augue. Praesent eleifend leo nunc, vel viverra elit euismod at. Suspendisse efficitur, sapien vitae vestibulum congue, felis velit feugiat eros, quis iaculis turpis ipsum facilisis leo. Mauris tempor aliquet eros quis placerat. Donec eget nisi auctor ligula commodo pretium. Integer venenatis accumsan gravida. Curabitur auctor eget metus eget faucibus. Aliquam vulputate convallis nisi vitae tempor.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1075">Tab 4</a>
                        </dt>
                        <dd id="panel1075">
                        <p>Etiam nec mollis eros, et feugiat ex. Fusce imperdiet metus felis, et suscipit elit consectetur cursus. Vivamus erat velit, dictum at ante eget, dapibus ornare metus.</p>

<p>Fusce ultrices mi id interdum pellentesque. Phasellus in venenatis lorem. Ut nec purus semper, convallis est nec, porta nunc. Maecenas non erat at libero laoreet consequat.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1076">Tab 5</a>
                        </dt>
                        <dd id="panel1076">
                        <p>Praesent ultricies nulla et arcu faucibus bibendum. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sit amet ex enim. Maecenas suscipit pulvinar vulputate. Donec venenatis leo eget metus aliquet pretium. Cras id viverra elit. Nullam vitae justo magna. Vivamus in efficitur lorem. Donec volutpat lectus in justo consequat, sit amet pulvinar quam ultrices.</p>

<p>Cras eget diam rutrum, lacinia nibh id, condimentum augue. Cras quis pretium risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a lorem enim. Aliquam pretium a leo sit amet porttitor. Maecenas lacus ligula, pharetra quis pharetra sed, tempus at justo.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1077">Tab 6 has a really long title to make it an accordion</a>
                        </dt>
                        <dd id="panel1077">
                        <p>Etiam laoreet non magna in volutpat. Curabitur ut enim cursus, tempor ligula at, molestie risus. Curabitur vel nisi cursus, consequat magna sed, pellentesque massa.</p>

<p>Quisque at suscipit elit, sit amet finibus arcu. Donec scelerisque nulla ut risus facilisis, vitae tincidunt ante pretium. Mauris diam ex, luctus et semper id, ullamcorper ornare tellus. Vivamus metus nisi, placerat sit amet dolor sed, malesuada malesuada neque. In facilisis eleifend ultricies.</p>

<p>Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec ac ante nec enim egestas tristique sit amet sit amet nisi. Mauris in dignissim quam. Morbi sit amet ornare justo, eget placerat nisi. Maecenas at vulputate ipsum. Ut at felis sed velit convallis suscipit ut eget ante. In iaculis auctor eleifend. Nunc arcu enim, ullamcorper ut consectetur vel, laoreet ac lectus</p>
                        </dd>
                        
                        </dl>
                    </section>
                                    </div>
            </div>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature 2 Box Test</h2><div class="optional_content"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

<p>Etiam mauris nisi, congue ac libero a, tristique placerat arcu. Vivamus maximus, lacus a lacinia porta, nulla velit varius tellus, in viverra magna turpis at eros. Sed quis libero sollicitudin, fringilla justo ut, accumsan odio. Aenean a tortor vel ligula elementum consequat. Fusce vitae pretium massa, in vehicula mi.</p>

<p>Phasellus auctor dui ut fermentum malesuada. Duis lobortis mattis neque sed rhoncus. Maecenas dignissim pellentesque purus, sed efficitur velit convallis ac. Suspendisse eu ex eget ex imperdiet ultrices ut sed augue. Sed massa dui, dapibus finibus feugiat nec, ultricies eu dolor. Maecenas ut tortor id nisi convallis fringilla non vel massa. Sed aliquet tellus id congue consectetur. Nunc vulputate molestie dapibus. Mauris fringilla accumsan sem, a dictum lectus vestibulum ut.</p></div>        <div class="feature_2box">
            <aside class="feature_box" aria-label="Feature box: Left Feature Box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_popular_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_popular_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Left Feature Box</h3>
                        <p>Donec semper cursus velit quis fermentum. Donec nec tortor at odio maximus mollis et id magna. Maecenas vulputate semper ultricies. Donec nec tempor nisl.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>                            </div>
                                            </div>
                </div>
            </aside>
            <aside class="feature_box" aria-label="Feature box: Right Feature Box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_staff_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_staff_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_staff_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_staff_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_staff_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_staff_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Right Feature Box</h3>
                        <p>Sed et nunc bibendum, molestie nibh ac, hendrerit nibh. Morbi vel ex nec lorem mattis tempus. Curabitur accumsan, mauris hendrerit vehicula fermentum, sem tortor blandit elit, et commodo magna lorem vitae massa. Nulla ut urna ipsum.</p>                                                    <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>                            </div>
                                            </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature 1 Box Plus Tabs Test B</h2><div class="optional_content"><p>This test has many tabs.</p></div>        <div class="feature_tabs_1box">
            <div class="feature_tabs">
                <div class="tabs_wrapper">
                    
                    <section id="tab_group_1063" class="tab_group">
                        <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                        <dt>
                            <a href="#panel1064">Tab 1</a>
                        </dt>
                        <dd id="panel1064">
                        <p>Nam vehicula porttitor pulvinar. Ut lectus massa, facilisis et magna in, auctor vulputate justo. Ut vel libero pellentesque, bibendum tortor egestas, cursus ex.</p>

<p>Vestibulum sagittis felis ex, vitae porttitor dui tempor et. Cras tincidunt tortor eget viverra lacinia. Proin at erat euismod, maximus arcu ac, pulvinar neque. Maecenas eget orci nibh.</p>

<p>Sed lacinia orci sit amet turpis mattis bibendum. Vivamus in venenatis sem, quis pharetra ligula. Nullam ac dapibus ex, eget euismod quam. Etiam tortor purus, vestibulum id enim sit amet, facilisis vehicula nibh. In sit amet augue venenatis lacus molestie varius ut vel nisi.</p>

<p>Pellentesque scelerisque vitae ligula a eleifend. Mauris vulputate odio bibendum justo laoreet, id tristique elit vulputate. Vestibulum sollicitudin imperdiet felis, eu pulvinar magna molestie at.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        <dt>
                            <a href="#panel1065">Tab 2</a>
                        </dt>
                        <dd id="panel1065">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nisi tortor, dictum a varius eget, accumsan eu libero. Proin sit amet mi interdum, viverra erat sit amet, tincidunt mauris. Morbi luctus cursus nulla ut vehicula. Nullam facilisis eros vitae leo iaculis, eu dictum neque ultricies. Integer nulla massa, congue et semper fermentum, laoreet id lacus. Aliquam in mattis felis, at mollis urna. Nunc eleifend, mi id lobortis blandit, turpis tellus posuere nisl, sed maximus massa nisl eu justo.</p>

<p>Duis sapien massa, consectetur eget tortor eget, fermentum placerat nunc. Fusce sed mi ut nisl ultrices pretium id id massa. Mauris eu diam non nulla rutrum vestibulum. Duis egestas dictum nisl, vitae consequat sapien tempus nec. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum bibendum molestie accumsan. Donec dictum pharetra dictum. Duis enim felis, ultrices ut lectus ac, accumsan maximus ex. Ut eget enim quis sem ullamcorper aliquet.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1066">Tab 3</a>
                        </dt>
                        <dd id="panel1066">
                        <p>Vivamus tempor mattis arcu eu pulvinar. Ut rhoncus eros ac ipsum ullamcorper imperdiet. Maecenas in ultrices ante. In hac habitasse platea dictumst. Aliquam consequat nisi ut posuere fringilla. Pellentesque fringilla sodales ipsum. Nulla et consequat odio.</p>

<p>Praesent suscipit id ex non ultricies. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi finibus scelerisque tellus, vitae malesuada dolor mattis vitae. Fusce tristique ut arcu sed ultrices. Donec nibh magna, accumsan ac placerat eget, viverra nec sem.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1067">Tab 4</a>
                        </dt>
                        <dd id="panel1067">
                        <p>Donec vel tellus porta, molestie nisl vitae, cursus magna. Donec commodo quam at elit lacinia vulputate. Duis vitae nunc turpis. Fusce sodales dapibus eros a varius.</p>

<p>Aliquam volutpat eros congue elit tristique, in sagittis lorem feugiat. Aliquam eu lacus sed velit semper suscipit. Aliquam laoreet est eu dictum aliquam. Phasellus tempor felis et purus scelerisque, a sagittis justo imperdiet.</p>

<p>Integer sit amet porttitor ante. Duis tincidunt tellus sapien, sed tempor lectus lacinia eu. Ut posuere a diam et rhoncus. Aenean nec maximus tellus, et sollicitudin ligula. Sed aliquam luctus enim, in lobortis justo porta eget. Duis interdum leo vel ex bibendum gravida.</p>

<p>Aliquam hendrerit consequat velit in ultrices. Etiam iaculis pulvinar urna, nec eleifend felis elementum quis. Curabitur volutpat faucibus neque. Donec sed urna ex. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1068">Tab 5</a>
                        </dt>
                        <dd id="panel1068">
                        <p>Morbi cursus leo non odio finibus, vitae condimentum orci mollis. Maecenas ornare imperdiet sem, vestibulum maximus mi lobortis quis. Mauris bibendum augue eu odio condimentum iaculis. Sed odio neque, tincidunt eu gravida eget, ultrices non elit.</p>

<p>Pellentesque quam justo, volutpat eu condimentum quis, pellentesque nec nisl. Sed imperdiet consequat volutpat. Duis vitae blandit ex.</p>
                        </dd>
                        
                        <dt>
                            <a href="#panel1069">Tab 6 has a really long title to make it an accordion</a>
                        </dt>
                        <dd id="panel1069">
                        <p>Vivamus tempor mattis arcu eu pulvinar. Ut rhoncus eros ac ipsum ullamcorper imperdiet. Maecenas in ultrices ante. In hac habitasse platea dictumst. Aliquam consequat nisi ut posuere fringilla. Pellentesque fringilla sodales ipsum. Nulla et consequat odio. Praesent suscipit id ex non ultricies.</p>

<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi finibus scelerisque tellus, vitae malesuada dolor mattis vitae. Fusce tristique ut arcu sed ultrices. Donec nibh magna, accumsan ac placerat eget, viverra nec sem.</p>

<p>Donec vel tellus porta, molestie nisl vitae, cursus magna.</p>
                        </dd>
                        
                        </dl>
                    </section>
                                    </div>
            </div>
            <aside class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_alumni_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_alumni_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Feature Test 1B</h3>
                        <p>&nbsp;Sed sit amet pulvinar neque, quis commodo arcu. Nam egestas tempus lacus sed mattis. Duis quis justo eget risus congue tempor eget ut libero.</p>

<p>Sed congue, orci quis cursus bibendum, neque nulla pretium ipsum, sit amet feugiat ante tellus et nulla. Nunc pretium metus ac justo luctus ultricies.</p>                        
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>
<div class="section">
    <div class="container">
        <h2 class="optional_heading">Feature 1 Box Plus Tabs Test A</h2><div class="optional_content"><p>This test only has a few tabs.</p></div>        <div class="feature_tabs_1box">
            <div class="feature_tabs">
                <div class="tabs_wrapper">
                    
                    <section id="tab_group_1060" class="tab_group">
                        <dl class="tabcordion" data-tabcordion='{"urlFragments" : true}'>
                    
                        <dt>
                            <a href="#panel1062">Tab 2</a>
                        </dt>
                        <dd id="panel1062">
                        <p>Suspendisse sed condimentum purus, et mollis est. Vivamus non tellus eleifend, mattis felis eu, consequat mi. Duis rhoncus libero a mi pellentesque, nec congue lacus elementum. Sed nec nunc rhoncus, mollis risus in, hendrerit sapien. Mauris nec orci vel lacus tincidunt aliquam et eu nulla.</p>

<p>Nam vehicula, tellus vitae dictum vestibulum, diam augue gravida augue, sed venenatis est arcu non nisl. Pellentesque consectetur lectus sit amet libero tincidunt egestas vel sit amet est. Nunc porttitor dictum auctor. Etiam porttitor quis magna sed efficitur.</p>

<p>Aliquam id purus scelerisque, laoreet mauris eget, sodales velit. Etiam ligula nunc, hendrerit a arcu eu, fringilla eleifend diam. Nam ut nisi nec eros sodales tempor ut a ex.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        <dt>
                            <a href="#panel1061">Tab 1</a>
                        </dt>
                        <dd id="panel1061">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut augue nulla, malesuada eu varius efficitur, cursus sit amet dolor. Etiam non velit consectetur, placerat mauris ut, cursus urna. Morbi dolor dolor, vestibulum sed volutpat eget, facilisis id nisi. Aliquam sed mauris pellentesque, congue nisi ac, tristique velit. Suspendisse ullamcorper ligula turpis, a tincidunt purus porttitor vitae. Sed eget semper nibh. Mauris tristique posuere diam, a egestas magna placerat in.</p>

<p>Aenean quis lectus nibh. Fusce commodo ex id finibus rhoncus. Ut maximus, ligula eget blandit finibus, mauris diam viverra metus, quis lacinia nisi magna id ante. Proin volutpat molestie nisl vel vulputate. Suspendisse suscipit enim lorem, a feugiat sem interdum et. Donec laoreet sapien a eros suscipit rhoncus. Nam eget sagittis quam.</p>
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                            
                        </dd>
                        
                        </dl>
                    </section>
                                    </div>
            </div>
            <aside class="feature_box">
                <div class="feature_box_wrapper">
                    <div class="feature_image">
                        <div>
                            <picture class="imgproxy"><source media="(min-width: 860px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 640px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 481px)" srcset="/img/200x/about/feature-images/16x9_about_rdax_450x253.jpg"><source media="(min-width: 251px)" srcset="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg"><source srcset="/img/250x/about/feature-images/16x9_about_rdax_450x253.jpg"><img src="/img/450x/about/feature-images/16x9_about_rdax_450x253.jpg" alt="" loading="lazy"></picture>                        </div>
                    </div>
                    <div class="feature_content">
                        <h3>Feature Test 1A</h3>
                        <p>Aliquam id purus scelerisque, laoreet mauris eget, sodales velit. Etiam ligula nunc, hendrerit a arcu eu, fringilla eleifend diam. Nam ut nisi nec eros sodales tempor ut a ex. Etiam quis nisl vulputate, feugiat orci a, luctus velit. Proin ipsum velit, gravida in aliquet nec, sollicitudin eget ex.</p>                        
                            <div class="feature_more">
                                <a href="https://www.abdn.ac.uk/">More Information</a>
                            </div>
                                                </div>
                </div>
            </aside>
        </div>
    </div>
</div>

<div class="section">
    <div class="container">
    <h2>General Text Area Test</h2>

<ul>
	<li>List item 1</li>
	<li>List item 2</li>
	<li>List Item 3</li>
</ul>

<blockquote>
<p>This is a block quote.</p>
</blockquote>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut augue nulla, malesuada eu varius efficitur, cursus sit amet dolor. Etiam non velit consectetur, placerat mauris ut, cursus urna. Morbi dolor dolor, vestibulum sed volutpat eget, facilisis id nisi. Aliquam sed mauris pellentesque, congue nisi ac, tristique velit. Suspendisse ullamcorper ligula turpis, a tincidunt purus porttitor vitae. Sed eget semper nibh. Mauris tristique posuere diam, a egestas magna placerat in.</p>

<p><picture class="imgproxy" style="float:right"><source media="(min-width: 481px)" srcset="/img/780x/about/content-images/Biomass_boiler_edit_rdax_450x338.jpg"><source media="(min-width: 251px)" srcset="/img/481x/about/content-images/Biomass_boiler_edit_rdax_450x338.jpg"><source srcset="/img/200x/about/content-images/Biomass_boiler_edit_rdax_450x338.jpg"><img src="/img/780x/about/content-images/Biomass_boiler_edit_rdax_450x338.jpg" alt="" width="450" height="338" loading="lazy"></picture>Aenean quis lectus nibh. Fusce commodo ex id finibus rhoncus. Ut maximus, ligula eget blandit finibus, mauris diam viverra metus, quis lacinia nisi magna id ante. Proin volutpat molestie nisl vel vulputate. Suspendisse suscipit enim lorem, a feugiat sem interdum et. Donec laoreet sapien a eros suscipit rhoncus. Nam eget sagittis quam. Suspendisse sed condimentum purus, et mollis est. Vivamus non tellus eleifend, mattis felis eu, consequat mi. Duis rhoncus libero a mi pellentesque, nec congue lacus elementum. Sed nec nunc rhoncus, mollis risus in, hendrerit sapien. Mauris nec orci vel lacus tincidunt aliquam et eu nulla. Nam vehicula, tellus vitae dictum vestibulum, diam augue gravida augue, sed venenatis est arcu non nisl. Pellentesque consectetur lectus sit amet libero tincidunt egestas vel sit amet est. Nunc porttitor dictum auctor. Etiam porttitor quis magna sed efficitur.</p>
    </div>
</div>
<div class="section">
  <div class="container">
          <h2 class="optional_heading">Test Accordion Module Heading</h2><div class="optional_content"><p>Sed nunc urna, fringilla ac pharetra eget, eleifend in leo. Cras imperdiet scelerisque sollicitudin. Quisque a vulputate quam. Quisque in nibh nisi. Nullam id tristique nisl, iaculis accumsan eros. Ut eu rutrum est. Nunc felis ipsum, laoreet sit amet massa in, accumsan ornare eros. Etiam id ullamcorper libero.</p></div>          <div class="tabs_wrapper">
              <section id="tab_group_1055" class="tab_group">
                  <dl class="accordion tabcordion" data-tabcordion='{"urlFragments" : true, "forceAccordion" : true, "openFirstPanel" : false}'>
  
          <dt>
              <a href="#panel1056">Accordion Test Panel 1</a>
          </dt>
          <dd id="panel1056">
          <p><picture class="imgproxy" style="float:right"><source media="(min-width: 481px)" srcset="/img/780x/about/content-images/Elphinstone,%20Kings%20chapel.jpg"><source media="(min-width: 251px)" srcset="/img/481x/about/content-images/Elphinstone,%20Kings%20chapel.jpg"><source srcset="/img/200x/about/content-images/Elphinstone,%20Kings%20chapel.jpg"><img src="/img/780x/about/content-images/Elphinstone,%20Kings%20chapel.jpg" alt="" loading="lazy"></picture>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vitae ligula erat. Sed vitae nisi velit. Nunc convallis vel lacus quis ultrices. Vivamus quam purus, tempor in ornare eget, ullamcorper ut mi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque pharetra, erat vitae tempus fermentum, nunc nulla pharetra lacus, non euismod purus elit id lectus. Aliquam sagittis felis a dolor ultrices tempor. Suspendisse potenti. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed id viverra lectus, ac venenatis eros. Curabitur pulvinar dignissim hendrerit. Curabitur id iaculis felis, id tristique metus. Phasellus sollicitudin, turpis vehicula euismod malesuada, sem lorem lacinia enim, nec euismod nibh orci a sapien. Morbi malesuada aliquet libero sit amet imperdiet.</p>
              <div class="feature_more">
                  <a href="https://www.abdn.ac.uk/">More Information</a>
              </div>
              
          </dd>
          
          <dt>
              <a href="#panel1057">Accordion Test Panel 2</a>
          </dt>
          <dd id="panel1057">
          <p>Vivamus vehicula iaculis ullamcorper. Morbi nulla orci, sollicitudin id erat et, tincidunt sollicitudin diam. In maximus tellus varius nisl sodales, ut pretium turpis laoreet. Fusce sed nisl at justo volutpat viverra eget non metus. Quisque at ex risus. Nullam id molestie erat. Ut nec sem vestibulum, ullamcorper risus eu, pharetra magna. Praesent accumsan elit sit amet sem laoreet euismod. Ut semper est condimentum risus tincidunt egestas. Donec blandit faucibus sapien, scelerisque vulputate enim convallis et. Proin ultrices facilisis nisi, vitae tristique ipsum ultrices nec. Curabitur eget semper neque. Ut dictum bibendum scelerisque. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
              <div class="feature_more">
                  <a href="https://www.abdn.ac.uk/">More Information</a>
              </div>
              
          </dd>
          
          <dt>
              <a href="#panel1058">Accordion Test Panel 3</a>
          </dt>
          <dd id="panel1058">
          <p>Aliquam sollicitudin odio ornare sapien hendrerit, non hendrerit ante facilisis. Morbi egestas leo id ullamcorper vulputate. In aliquam fringilla ex. In hac habitasse platea dictumst. Mauris dictum augue eu nisl tempus, quis pellentesque purus varius. Donec at nulla tellus. Donec id venenatis dolor.</p>

<p>Duis euismod, mauris sed lacinia cursus, arcu ante bibendum eros, sed pretium arcu felis ut libero. Duis accumsan risus pharetra mauris luctus, eget scelerisque nulla tristique. Sed pharetra eu risus non egestas. Integer pellentesque neque vel dui congue fringilla. Morbi vestibulum dolor purus. Maecenas ut eros molestie, tempus velit et, fermentum tellus. Nam viverra condimentum iaculis.</p>
              <div class="feature_more">
                  <a href="https://www.abdn.ac.uk/">More Information</a>
              </div>
              
          </dd>
                            </dl>
              </section>
          </div>
      </div>
</div>            </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/about/index.php">About</a></li>
            
            <li><a href="/about/our-website/index.php">Our Website</a></li>
            
            <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/about/our-website/accessibility-test-bed-1054.php" class="current" aria-current="page">Accessibility Test Bed</a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/about/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="/global/js/opentext_responsive/tabcordion.js?cb=20221026"></script>
                
                <script src="/global/js/opentext_responsive/slick.js?cb=20221026"></script>
                
                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
