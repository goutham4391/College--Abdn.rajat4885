<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>A to Z | About | The University of Aberdeen</title>
    <!-- Page ID : 538 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A-Z listing of the main sections of our website">
    
        <meta name="keywords" content="a to z">
            <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/about/" class="section_head_text">
                    About                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="About navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/about/schools-institutes/index.php">Schools and Institutes</a>
            </li>
            
            <li>
                <a href="/about/campus/index.php">Campus</a>
            </li>
            
            <li>
                <a href="/about/strategy-and-governance/index.php">Strategy and Governance</a>
            </li>
            
            <li>
                <a href="/about/management/index.php">Management</a>
            </li>
            
            <li>
                <a href="/about/facts-figures/index.php">Facts & Figures</a>
            </li>
            
            <li>
                <a href="/about/history/index.php">History</a>
            </li>
            
            <li>
                <a href="/about/contact/index.php">Contact</a>
            </li>
            
            <li>
                <a href="/about/partnerships/index.php">Partnerships</a>
            </li>
            
            <li>
                <a href="/about/coronavirus/index.php">Coronavirus (Covid-19)</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">A to Z</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/about/">About</a></li>
            
            <li><a href="/about/our-website/index.php">Our Website</a></li>
            
            <li tabindex="0" aria-current="page">A to Z</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">A to Z</div>
                        <p><a name="TOP"></a><a class="offscreen" href="#skip_a_to_z">Skip the following A to Z links</a></p>

<ol aria-label="A to Z links, to headings on this page" class="a_to_z clearfix">
	<li><a href="#azA">A</a></li>
	<li><a href="#azB">B</a></li>
	<li><a href="#azC">C</a></li>
	<li><a href="#azD">D</a></li>
	<li><a href="#azE">E</a></li>
	<li><a href="#azF">F</a></li>
	<li><a href="#azG">G</a></li>
	<li><a href="#azH">H</a></li>
	<li><a href="#azI">I</a></li>
	<li><a href="#azJ">J</a></li>
	<li><a href="#azK">K</a></li>
	<li><a href="#azL">L</a></li>
	<li><a href="#azM">M</a></li>
	<li><a href="#azN">N</a></li>
	<li><a href="#azO">O</a></li>
	<li><a href="#azP">P</a></li>
	<li><a href="#azQ">Q</a></li>
	<li><a href="#azR">R</a></li>
	<li><a href="#azS">S</a></li>
	<li><a href="#azT">T</a></li>
	<li><a href="#azU">U</a></li>
	<li><a href="#azV">V</a></li>
	<li><a href="#azW">W</a></li>
	<li><strong title="No items for this letter">X</strong></li>
	<li><strong title="No items for this letter">Y</strong></li>
	<li><a href="#azZ">Z</a></li>
</ol>

<p class="offscreen" id="skip_a_to_z" tabindex="-1">A to Z links skipped</p>

<p><strong>Can't find a link?</strong> Click the search button at the top right of this page.</p>

<p><strong>Looking for a phone number?</strong> Try the <a href="https://www.abdn.ac.uk/staffnet/directory.php">online directory</a> or phone the switchboard on <a href="tel:441224272000">+44 (0)1224 272000</a></p>

<p>If you are a University student or member of staff and want something added to this listing, contact the <a href="mailto:web-team@abdn.ac.uk?Subject=A to Z">Web Team</a></p>

<p>The A-Z is intended to be a comprehensive listing of all University web content by title and by keyword and therefore includes all departments, sections, centres and units.</p>

<p>If you wish to report a dead link, please contact the <a href="mailto:web-team@abdn.ac.uk?Subject=A to Z">Web Team</a> or phone <a href="tel:+441224273262">+44 (0)1224 273262</a></p>

<h2><a name="azA"></a>A</h2>

<ul>
	<li>Aberdeen AUT - see <a href="https://www.abdn.ac.uk/ucu/">AUCU Aberdeen University and College Union</a></li>
	<li><a href="https://www.abdn.ac.uk/biodiversity/">Aberdeen Biodiversity Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/imaging/">Aberdeen Biomedical Imaging Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/acamh/">Aberdeen Centre for Arthritis and Musculoskeletal Health (ACHAMH)</a></li>
	<li><a href="https://www.abdn.ac.uk/research/acreef/">Aberdeen Centre for Research in Energy Economics and Finance (ACREEF)</a></li>
	<li><a href="https://www.abdn.ac.uk/aga/">Aberdeen Geological Alumni (AGA)</a></li>
	<li><a href="https://www.abdn.ac.uk/historic/harbour/">Aberdeen Harbour Board Collection</a></li>
	<li><a href="https://www.abdn.ac.uk/aicsm/">Aberdeen Institute for Coastal Science and Management</a></li>
	<li><a href="http://en.wikipedia.org/wiki/Aberdeen_Research_Consortium">Aberdeen Research Consortium</a></li>
	<li><a href="http://www.aberdeensportsvillage.com/">Aberdeen Sports Village</a></li>
	<li><a href="http://aura.abdn.ac.uk/">Aberdeen University Research Archive</a></li>
	<li><a href="https://www.abdn.ac.uk/cad/">Academic Development, Centre for</a></li>
	<li>Academic Learning and Study Unit (ALSU) - see <a href="https://www.abdn.ac.uk/cad/">Centre for Academic Development</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/academic-quality-handbook-838.php">Academic Quality Handbook</a></li>
	<li><a href="https://www.abdn.ac.uk/capc/">Academic Primary Care, Centre of</a></li>
	<li><a href="https://www.abdn.ac.uk/directory/">Academic Staff Directory</a>- including external access</li>
	<li><a href="https://www.abdn.ac.uk/urology/">Academic Urology Unit </a></li>
	<li>Access - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-authorscreators/">Accessibility for Auhor/Creators</a></li>
	<li><a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-users/">Accessibility for Users</a></li>
	<li>Accommodation
	<ul>
		<li><a href="https://www.abdn.ac.uk/estates/administration/staff_accomm.shtml">for Staff</a>&nbsp;</li>
		<li><a href="https://www.abdn.ac.uk/accommodation/">for Students</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/business">Accountancy and Finance</a></li>
	<li><a href="https://www.abdn.ac.uk/graduateattributes/">ACHIEVE</a></li>
	<li><a href="https://www.abdn.ac.uk/admin/">Administration</a></li>
	<li>Admission Policy
	<ul>
		<li><a href="https://www.abdn.ac.uk/study/undergraduate/admissions-policy.php">Undergraduate</a></li>
		<li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/admissions-policy.php">Postgraduate Taught</a></li>
		<li><a href="https://www.abdn.ac.uk/study/postgraduate-research/pgr-admissions-policy.php">Postgraduate Research</a></li>
	</ul>
	</li>
	<li>Advertising - see <a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DITadvertising.pdf">Policy on the use of University web pages for commercial advertising</a>&nbsp;-&nbsp;PDF</li>
	<li>Aerobics - see <a href="http://www.aberdeensportsvillage.com/">Aberdeen Sports Village</a></li>
	<li>Aesthetics - see <a href="https://www.abdn.ac.uk/philosophy/">Philosophy</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/facilities/microarray-58.php">Affymetrix Microarray Facility</a></li>
	<li>Agriculture - see <a href="https://www.abdn.ac.uk/sbs/">School of Biological Sciences</a></li>
	<li>Agronomy - see <a href="https://www.abdn.ac.uk/sbs/">School of Biological Sciences</a></li>
	<li><a href="https://www.abdn.ac.uk/riiss/about/ahrc-centre-66.php">AHRC Centre for Irish and Scottish Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/study/undergraduate/aim4uni-2030.php">aim4uni</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/academic-quality-handbook/Policy%20on%20Drugs%20and%20Alcohol%20Misuse.pdf" target="_blank">Alcohol&nbsp;and Drugs&nbsp;Misuse Policy (Students)</a></li>
	<li><a href="https://www.abdn.ac.uk/alumni_relations/">Alumni Relations</a></li>
	<li><a href="https://www.abdn.ac.uk/museums/collections/medical.php#anatomy">Anatomy Museum</a></li>
	<li>Anglo-Saxon Studies - see <a href="https://www.abdn.ac.uk/history/">Centre for Anglo-Saxon Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/anthropology/">Anthropology</a></li>
	<li>Anthropology of Religion - see <a href="https://www.abdn.ac.uk/divinity/">Divinity and Religious Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/appeals-and-complaints-686.php">Appeals and Complaints</a></li>
	<li>Application
	<ul>
		<li><a href="https://www.abdn.ac.uk/study/undergraduate/request-a-prospectus.php">Request form for Undergraduate Prospectus</a></li>
		<li><a href="https://www.abdn.ac.uk/pgap/login.php">Postgraduate application - online form</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/archaeology/">Archaeology</a></li>
	<li><a href="https://www.abdn.ac.uk/hoart/">Art, History of</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/enhancing-feedback-272.php">Assessment and Feedback</a></li>
	<li><a href="https://www.abdn.ac.uk/atech/">Assistive Technology</a></li>
	<li>AU Consultancy - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
	<li><a href="https://www.abdn.ac.uk/avu/">Audio-Visual Unit</a></li>
	<li><a href="http://aura.abdn.ac.uk/">AURA</a></li>
	<li>AURIS Research - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azB"></a>B</h2>

<ul>
	<li>Bacteria - see <a href="http://www.ncimb.co.uk/">National Collections of Industrial, Marine and Food Bacteria</a></li>
	<li>Ballad Studies - see the <a href="https://www.abdn.ac.uk/elphinstone/">Elphinstone Institute</a></li>
	<li><a href="https://www.abdn.ac.uk/bestiary/">Bestiary</a></li>
	<li>Biblical Theology - see <a href="https://www.abdn.ac.uk/divinity/">Divinity and Religious Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/it/student/print/print-shop.php">Binding</a></li>
	<li>Biochemistry - see&nbsp;<a href="../../smmsn" title="School of Medicine, Medical Sciences and Nutrition">School of Medicine, Medical Sciences and Nutrition</a></li>
	<li><a href="https://www.abdn.ac.uk/sbs/">Biological Sciences, School of</a></li>
	<li>Biomechanics and Biomaterials Research - see the&nbsp;<a href="../../smmsn" title="School of Medicine, Medical Sciences and Nutrition">School of Medicine, Medical Sciences and Nutrition</a></li>
	<li>Bio-Medical Physics and Bio-Engineering - see the&nbsp;<a href="../../smmsn" title="School of Medicine, Medical Sciences and Nutrition">School of Medicine, Medical Sciences and Nutrition</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/imaging/">Biomedical Imaging Centre, Aberdeen</a></li>
	<li>Biomedical Sciences - see the&nbsp;<a href="../../smmsn" title="School of Medicine, Medical Sciences and Nutrition">School of Medicine, Medical Sciences and Nutrition</a></li>
	<li>Booking
	<ul>
		<li><a href="https://www.abdn.ac.uk/it/services/training/courses.php">Courses</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/room-booking-708.php">Rooms</a></li>
		<li><a href="https://www.abdn.ac.uk/mycourses/">Tutorials</a></li>
	</ul>
	</li>
	<li>Business</li>
	<li><a href="https://www.abdn.ac.uk/continuity/">Business Continuity</a></li>
	<li><a href="https://www.abdn.ac.uk/business/">Business School</a></li>
	<li>Business Studies/Administration - see <a href="https://www.abdn.ac.uk/business/">Business School</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azC"></a>C</h2>

<ul>
	<li>Calendar
	<ul>
		<li><a href="https://www.abdn.ac.uk/registry/calendar/">University Calendar</a></li>
		<li><a href="https://www.abdn.ac.uk/students/term-dates.php">Term Dates and Week Numbers</a></li>
		<li><a href="https://www.abdn.ac.uk/registry/courses/" target="_blank">Catalogue of Courses</a></li>
	</ul>
	</li>
	<li>Campus Tours - see <a href="https://www.abdn.ac.uk/oldtownhouse/">Old Town House</a></li>
	<li><a href="https://www.abdn.ac.uk/acdc/">Cardiovascular Research</a></li>
	<li><a href="https://www.abdn.ac.uk/careers/">Careers and Employability&nbsp;Service</a></li>
	<li><a href="https://www.abdn.ac.uk/chaplaincy/">Chaplaincy</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/celtic-anglo-saxon-studies-1300.php">Celtic and Anglo-Saxon Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/admin/">Central Administration</a></li>
	<li><a href="https://www.abdn.ac.uk/uniprint/">Central Printing Service</a></li>
	<li>Centre for -
	<ul>
		<li><a href="https://www.abdn.ac.uk/cad/">Academic Development</a></li>
		<li><a href="https://www.abdn.ac.uk/capc/">Academic Primary Care</a></li>
		<li><a href="https://www.abdn.ac.uk/history/">Anglo-Saxon Studies</a></li>
		<li><a href="https://www.abdn.ac.uk/cadr/">Applied Dynamics Research</a></li>
		<li><a href="https://www.abdn.ac.uk/cisrul/">Citizenship, Civil Society and Rule of Law</a></li>
		<li><a href="https://www.abdn.ac.uk/cems/">Early Modern Studies</a></li>
		<li><a href="https://www.abdn.ac.uk/ims/facilities/genomics.php">Genome-Enabled Biology and Medicine</a></li>
		<li><a href="https://www.abdn.ac.uk/hsru/chart/">Healthcare Randomised Trials (CHaRT)</a></li>
		<li><a href="https://www.abdn.ac.uk/chpstm/">History and Philosophy of Science, Technology and Medicine</a></li>
		<li><a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
		<li><a href="https://www.abdn.ac.uk/sll/disciplines/research-interests-1381.php">Linguistic Research</a></li>
		<li><a href="https://www.abdn.ac.uk/modernthought/">Modern Thought</a></li>
		<li><a href="https://www.abdn.ac.uk/ceminacs/">Micro and Nanomechanics (CEMINACS)</a></li>
		<li><a href="https://www.abdn.ac.uk/cpem/">Planning and Environmental Management</a></li>
		<li><a href="https://www.abdn.ac.uk/business/research/crer.php">Research in Real Estate</a></li>
		<li><a href="https://www.abdn.ac.uk/crh/">Rural Health</a>&nbsp;- formerly Highlands and Islands Health Research Institute (HIHRI)</li>
		<li><a href="https://www.abdn.ac.uk/cfss/">Scandinavian Studies</a></li>
		<li>Scottish Studies see <a href="https://www.abdn.ac.uk/riiss/">Research Institute of Irish and Scottish Studies</a></li>
		<li><a href="https://www.abdn.ac.uk/cshad/">Spirituality, Health and Disability. (CSHAD)</a></li>
		<li><a href="https://www.abdn.ac.uk/sustainable-international-development/">Sustainable International Development</a></li>
		<li><a href="https://www.abdn.ac.uk/sll/research/centre-for-the-novel-215.php">The Novel</a></li>
		<li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/kosterlitz.php">Therapeutics (Kosterlitz)</a></li>
		<li><a href="https://www.abdn.ac.uk/engineering/research/ctr/index.php">Transport Research (CTR)</a></li>
		<li><a href="https://www.abdn.ac.uk/acwhr/">Women's Health Research</a></li>
	</ul>
	</li>
	<li>Chapel, King's College</li>
	<li><a href="https://www.abdn.ac.uk/chaplaincy/">Chaplaincy</a></li>
	<li><a href="https://www.abdn.ac.uk/hsru/chart/">CHaRT - Centre for Healthcare Randomised Trials</a></li>
	<li><a href="https://www.abdn.ac.uk/chemistry/">Chemistry</a></li>
	<li>Child Care - see <a href="https://www.abdn.ac.uk/rockinghorse/">Rocking Horse Nursery</a></li>
	<li><a href="https://www.abdn.ac.uk/child_health/">Child Health</a></li>
	<li>Civil Engineering - see <a href="https://www.abdn.ac.uk/engineering/">Engineering</a></li>
	<li><a href="https://www.abdn.ac.uk/clearing/">Clearing</a></li>
	<li><a href="https://www.abdn.ac.uk/crf/">Clinical Research Facility</a></li>
	<li><a href="https://www.abdn.ac.uk/clinicalskills/">Clinical Skills Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/cad/">Centre for Academic Development</a></li>
	<li><a href="https://www.abdn.ac.uk/aicsm/">Coastal Science and Management, Aberdeen Institute for</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DIT_e-publishing.pdf">Code of Practice for the Publishing of Information in Electronic Format</a>- PDF</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/catering-outlets-on-campus-441.php" title="Coffee on Campus">Coffee on Campus</a></li>
	<li>Commercial Services</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/minutes-and-agendas-135.php">Committees</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/common-grading-scale-2840.php">Common&nbsp;grading scale</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/study/appeals-and-complaints-procedures.php">Complaints</a></li>
	<li>Computers - <a href="https://www.abdn.ac.uk/freepcs/">real time display of free PCs</a></li>
	<li>Computing Centre - see <a href="https://www.abdn.ac.uk/dit">IT Services</a></li>
	<li><a href="https://www.abdn.ac.uk/ncs/departments/computing-science/">Computing Science</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DIT_cond-IT-guide.pdf">Conditions for Using&nbsp;Information Technology&nbsp;Facilities</a>&nbsp;- PDF</li>
	<li><a href="https://www.abdn.ac.uk/confevents/" title="Conferences and Events">Conferences and Events </a></li>
	<li><a href="https://www.abdn.ac.uk/hospitality/">Conference and Event Office</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/imaging/">Confocal Microscopy</a></li>
	<li>Contacts Information</li>
	<li>Continuing Education - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/cpd/">Continuing Professional Development</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/travel-benefits/index.php">Corporate Trave</a><a href="https://www.abdn.ac.uk/staffnet/working-here/travel-benefits/index.php">l</a>&nbsp;(requires login)</li>
	<li><a href="https://www.abdn.ac.uk/counselling/">Counselling Service</a></li>
	<li><a href="https://www.abdn.ac.uk/scef/">Course Feedback&nbsp;Forms</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/course-and-programme-approval-6102.php">Course programme proposal forms </a></li>
	<li>Courses
	<ul>
		<li><a href="https://www.abdn.ac.uk/clearing/">Clearing</a></li>
		<li><a href="https://www.abdn.ac.uk/it/services/training/courses.php">Course Booking System</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/teaching/course-and-programme-approval-6102.php">Course programme proposal forms SENAS</a></li>
		<li><a href="https://www.abdn.ac.uk/prospectus/">Undergraduate Prospectus</a></li>
		<li><a href="https://www.abdn.ac.uk/prospectus/">Postgraduate Courses</a></li>
		<li><a href="https://www.abdn.ac.uk/prospectus/">Postgraduate Prospectus</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/court-papers-147.php">Court</a> - see <a href="https://www.abdn.ac.uk/staffnet/governance/index.php">Policy and Governance</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/admin/court/intranet/">Court Intranet</a> (requires login)</li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/cpd/">CPD</a></li>
	<li>Creche - see <a href="https://www.abdn.ac.uk/rockinghorse/">Rocking Horse Nursery</a></li>
	<li><a href="https://www.abdn.ac.uk/cshad/">CSHAD (Centre for Spirituality, Health and Disability)</a></li>
	<li>Cultural History</li>
	<li><a href="https://www.abdn.ac.uk/elphinstone/">Cultural Tradition</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/curriculum-reform-and-enhanced-study-2760.php">Curriculum Reform Project</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azD"></a>D</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/data-protection-6958.php">Data Protection</a></li>
	<li>Degree Regulations - see <a href="https://www.abdn.ac.uk/registry/calendar/">University Calendar</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/delivered-catering-442.php" title="Delivered Catering">Delivered Catering</a></li>
	<li>Dentistry - see <a href="https://www.abdn.ac.uk/medicine-dentistry/">Medicine, Medical Sciences and Nutrition, School of</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/mybds">MyBDS Staff and Student Resources</a> (login required)</li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/it/services/media/design.php">Design</a></li>
	<li><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/finance/us-federal-direct-loans.php">Direct Loans</a>(US Students)</li>
	<li><a href="https://www.abdn.ac.uk/directorscut/">Director's Cut</a> <!--<li>Directorate of Information Technology (DIT) - see <a href="https://www.abdn.ac.uk/dit/">IT Services</a></li>
<li><a href="https://www.abdn.ac.uk/experts/">Directory of Experts</a></li>--></li>
	<li><a href="https://www.abdn.ac.uk/directory/">Directory Services</a></li>
	<li>Disabilities:
	<ul>
		<li><a href="https://www.abdn.ac.uk/atech/">Assistive Technology</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/governance/equality-and-diversity-277.php#panel6024">Disability Information for Staff</a></li>
		<li><a href="https://www.abdn.ac.uk/infohub/support/support-for-disabled-students-1901.php">Disability Information for Students</a></li>
		<li><a href="https://www.abdn.ac.uk/it/student/help/disabilities.php">Computing Services for Disabled Students</a></li>
		<li><a href="https://www.abdn.ac.uk/library/documents/guides/gen/qggen002.pdf">Library Facilities and Services for Disabled Students</a>- PDF</li>
		<li><a href="https://www.abdn.ac.uk/staffnet/teaching/registry-972.php">Registry</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/lifelonglearning/">Distance Learning - see Centre for Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/divinity/">Divinity and Religious Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/sdhp/">Divinity, History and Philosophy, School of</a></li>
	<li>Donations, gifts and legacies - see the <a href="https://www.abdn.ac.uk/devtrust/">Development Trust</a></li>
	<li>Doric - see the <a href="https://www.abdn.ac.uk/elphinstone/">Elphinstone Institute</a> and the <a href="https://www.abdn.ac.uk/elphinstone/kist/">Elphinstone Kist</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/academic-quality-handbook/Policy%20on%20Drugs%20and%20Alcohol%20Misuse.pdf" target="_blank">Drugs and Alcohol Misuse Policy&nbsp;(Students)</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azE"></a>E</h2>

<ul>
	<li><a href="https://abdn.primo.exlibrisgroup.com/discovery/search?vid=44ABE_INST:44ABE_VU1">E-journals</a></li>
	<li><a href="https://www.abdn.ac.uk/cems/">Early Modern Studies, Centre for</a></li>
	<li><a href="https://www.abdn.ac.uk/bodysnatchers/">Echoes of the Resurrection Men</a></li>
	<li>Ecology:
	<ul>
		<li><a href="https://www.abdn.ac.uk/sbs/">The School of Biological Sciences</a></li>
		<li><a href="https://www.abdn.ac.uk/prospectus/pgrad/study/taught.php?code=ecology">MSc in Ecology</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/business/">Economics</a></li>
	<li>Education
	<ul>
		<li><a href="https://www.abdn.ac.uk/education/">School of Education</a></li>
		<li><a href="https://www.abdn.ac.uk/lifelonglearning/">Centre for Lifelong Learning</a></li>
		<li><a href="https://www.abdn.ac.uk/prospectus/">Prospectuses</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/education/">Education, School of</a></li>
	<li>Educational Development - see <a href="https://www.abdn.ac.uk/cad/">Centre for Academic Development</a></li>
	<li><a href="https://www.abdn.ac.uk/study/international/language-centre.php">EFL</a></li>
	<li><a href="https://abdn.primo.exlibrisgroup.com/discovery/search?vid=44ABE_INST:44ABE_VU1">Electronic journals</a></li>
	<li><a href="https://www.abdn.ac.uk/erg/">Electronics Research Group (Engineering)</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/facilities/microscopy-histology.php">Electron Microscope Facility</a></li>
	<li><a href="https://www.abdn.ac.uk/elphinstone/">Elphinstone Institute</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/elphinstone/kist/">Elphinstone Kist</a></li>
	</ul>
	</li>
	<li>Email
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-communications.php">Staff and research postgraduate email</a>
		<ul>
			<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-services/communications.php#office365">Web access Office 365</a> - post migration</li>
		</ul>
		</li>
		<li><a href="https://www.abdn.ac.uk/dit/student/email/">Student email (undergraduate and taught postgraduate)</a>
		<ul>
			<li><a href="https://www.abdn.ac.uk/toolkit/systems/outlook/">Login</a></li>
		</ul>
		</li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-communications.php">Mailing Lists</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/emigration/">Emigration Database, Scottish</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/Employability_Development_Framework_Sept_2016_final_version.pdf" target="_blank">Employability Framework</a></li>
	<li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Employer Engagement</a></li>
	<li>Energy - see <a href="https://www.abdn.ac.uk/energy/">Institute of Energy Technologies</a></li>
	<li><a href="https://www.abdn.ac.uk/engineering/">Engineering</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/erg/">Electronics Research Group</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/engineering/">Engineering, School of </a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/english-1313.php">English</a></li>
	<li><a href="https://www.abdn.ac.uk/study/international/language-centre.php">English as a Foreign Language</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/life/enhanced-transcript-623.php">Enhanced Transcript</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/environment/">Environment</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/environment/">Environment Office</a></li>
	<li>Environmental Management - see <a href="https://www.abdn.ac.uk/geography/">Geography and Environment</a></li>
	<li>Environmental Science - see <a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/828/CD27/plant-and-soil-science/">Plant and Soil Science</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/equality-and-diversity-277.php">Equality and Diversity</a></li>
	<li><a href="https://www.abdn.ac.uk/erasmus/">Erasmus</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/">Estates Section</a></li>
	<li>Ethics - see <a href="https://www.abdn.ac.uk/philosophy/">Philosophy</a></li>
	<li>Ethnography/Ethnology - see the <a href="https://www.abdn.ac.uk/elphinstone/">Elphinstone Institute</a></li>
	<li>Evening Courses - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
	<li><a href="https://www.abdn.ac.uk/library/support/exam-papers-180.php">Exam Papers database</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/timetables-416.php#panel6715">Exam Timetable</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/policies-proceedures-plans-and-guidlines-399.php">Expenses and Benefits Policy</a></li>
	<li>External Affairs
	<ul>
		<li><a href="https://www.abdn.ac.uk/devtrust/">Development Trust</a></li>
		<li><a href="https://www.abdn.ac.uk/alumni_relations/">Alumni Relations</a></li>
		<li><a href="https://www.abdn.ac.uk/sras/">Student Recruitment and Admissions</a></li>
		<li><a href="https://www.abdn.ac.uk/news/communications/index.php">Communications</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/external-examiners-6107.php">External Examiners</a></li>
	<li>External Funding - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
	<li>Extra Mural Studies - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azF"></a>F</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/estates/">Facilities Management</a>&nbsp;- now Estates Section</li>
	<li><a href="https://www.abdn.ac.uk/fairtrade/">Fairtrade</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/supporting-your-students-338.php#panel7012">Fees (Tuition)</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/film-visual-culture-1338.php">Film and Visual Culture</a></li>
	<li>Filtering - see <a href="https://www.abdn.ac.uk/dit/documents/Web_content_filter_guidelines.pdf">Web Content Filtering</a></li>
	<li><a href="https://www.abdn.ac.uk/finance/">Finance Section (Corporate)</a></li>
	<li>Finance - Student Information
	<ul>
		<li><a href="https://www.abdn.ac.uk/undergraduate/finance.php">Undergraduates</a></li>
		<li><a href="https://www.abdn.ac.uk/postgraduate/finance.php">Postgraduate Students</a></li>
		<li><a href="https://www.abdn.ac.uk/international/finance.php">International Students</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/policies-proceedures-plans-and-guidlines-399.php">Financial Regulations</a></li>
	<li>Fish - see <a href="https://www.abdn.ac.uk/sfirc/">Scottish Fish Immunology Research Centre</a></li>
	<li>Folklife, Folklore, Folk music, Folksong - see the <a href="https://www.abdn.ac.uk/elphinstone/">Elphinstone Institute</a></li>
	<li>Food Bacteria - see <a href="http://www.ncimb.co.uk/">National Collections of Industrial, Marine and Food Bacteria</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/catering-outlets-on-campus-441.php" title="Food on Campus ">Food on Campus</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-finance/Fraud_Policy_April_2020.pdf">Fraud Policy</a></li>
	<li>Free PCs - <a href="https://www.abdn.ac.uk/freepcs/">real time display of free PCs</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/freedom-of-information-254.php">Freedom of Information</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/foi/">Publication Scheme</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/french-francophone-studies-1349.php">French and Francophone Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/trac.php#panel11064">Full Economic Costing</a></li>
	<li>Funding
	<ul>
		<li><a href="https://www.abdn.ac.uk/undergraduate/finance.php">Undergraduate and EU Students</a></li>
		<li><a href="https://www.abdn.ac.uk/postgraduate/finance.php">Postgraduate Students</a></li>
		<li><a href="https://www.abdn.ac.uk/international/finance.php">International Students</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/estates/">Furnishing Services</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azG"></a>G</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/gaelic/">Gaelic</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/gaelic-language-plan-334.php">Gaelic Language Act</a></li>
	<li><a href="https://www.abdn.ac.uk/general-council/">General Council</a></li>
	<li>General Practice and Primary Care - see <a href="https://www.abdn.ac.uk/capc/">Centre of Academic Primary Care</a></li>
	<li><a href="https://www.abdn.ac.uk/geography/">Geography and Environment</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/cpem/">Centre for Planning and Environmental Management</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/geology/">Geology and Petroleum Geology</a></li>
	<li><a href="https://www.abdn.ac.uk/historic/gww/">George Washington Wilson archive</a></li>
	<li><a href="https://www.abdn.ac.uk/geology/">Geoscience</a></li>
	<li><a href="https://www.abdn.ac.uk/geosciences/">Geosciences, School of</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/german-studies-1371.php">German</a></li>
	<li>Gifts, donations and legacies - see the <a href="https://www.abdn.ac.uk/devtrust/">Development Trust</a></li>
	<li><a href="https://gohealthservices.scot.nhs.uk/travel-clinic" target="_blank" title="GO Health Service">GO Health Service</a></li>
	<li><a href="https://www.abdn.ac.uk/graduateattributes/">Graduate Attributes</a></li>
	<li><a href="https://www.abdn.ac.uk/pgrs/">Graduate Schools</a></li>
	<li><a href="https://www.abdn.ac.uk/grads/">Graduation</a></li>
	<li><a href="https://www.abdn.ac.uk/obsgynae/">Gynaecology</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azH"></a>H</h2>

<ul>
	<li>Halls of Residence - see <a href="https://www.abdn.ac.uk/accommodation/">Accommodation</a></li>
	<li><a href="https://www.abdn.ac.uk/historic/harbour/">Harbour Board Collection</a></li>
	<li>Health and Safety:
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/health-and-safety-308.php">Health and Safety at the University </a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/support-for-staff-226.php#panel5511">Occupational Health Service</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/heru/">Health Economics Research Unit (HERU)</a></li>
	<li><a href="https://www.abdn.ac.uk/hsru/">Health Services Research Unit (HSRU)</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/sport-and-exercise-1188.php">Healthy Working Lives</a></li>
	<li>Highlands and Islands Health Research Institute (HIHRI) - See <a href="https://www.abdn.ac.uk/crh/">Centre for Rural Health </a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/spanish-latin-american-studies-1393.php">Hispanic Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/facilities/microscopy-histology/index.php">Histology Facility</a></li>
	<li><a href="https://www.abdn.ac.uk/history/">History</a></li>
	<li><a href="https://www.abdn.ac.uk/chpstm/">History and Philosophy of Science, Technology and Medicine</a></li>
	<li><a href="https://www.abdn.ac.uk/hoart/">History of Art</a></li>
	<li><a href="https://www.abdn.ac.uk/hsru/">HSRU</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub">Hub, The</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Human Resources</a>
	<ul>
		<li><a href="https://myview.abdn.ac.uk/dashboard/dashboard-ui/index.html#/landing">MyHR</a>&nbsp;(Internal access only)</li>
	</ul>
	</li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azI"></a>I</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/geosciences/departments/geography-environment/idrisi-resource-centre-897.php">Idrisi Resource Center</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/imaging/">Imaging - see Aberdeen Biomedical Imaging Centre </a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/immigration-936.php">Immigration: Information for Staff</a></li>
	<li>Immunology
	<ul>
		<li><a href="https://www.abdn.ac.uk/ims/research/immunity-and-infection-1587.php">Immunity, Infection and Inflammation</a></li>
		<li><a href="https://www.abdn.ac.uk/sfirc/">Scottish Fish Immunology Research Centre</a></li>
	</ul>
	</li>
	<li>Industrial Bacteria - see <a href="http://www.ncimb.co.uk/">National Collections of Industrial, Marine and Food Bacteria</a></li>
	<li>Industrial Liaison- see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
	<li><a href="https://www.abdn.ac.uk/smmsn/undergraduate/medical-sciences/industrial-placements.php">Industrial Placements,&nbsp;School of Medicine, Medical Sciences and Nutrition</a></li>
	<li><a href="https://www.abdn.ac.uk/psychology/research/industrial-psychology-research-centre-529.php">Industrial Psychology Research Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/">Infohub</a></li>
	<li><a href="https://www.abdn.ac.uk/iahs/">Institute of Applied Health Sciences (IAHS</a>)</li>
	<li><a href="https://www.abdn.ac.uk/aicsm/">Institute for Coastal Science and Management, Aberdeen</a></li>
	<li><a href="https://www.abdn.ac.uk/icsmb/">Institute for Complex Systems and Mathematical Biology</a></li>
	<li><a href="https://www.abdn.ac.uk/iemds/">Institute of Education in Healthcare and Medical Sciences (IEHMS)</a></li>
	<li><a href="https://www.abdn.ac.uk/iet/">Institute of Energy Technologies</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/">Institute of Medical Sciences&nbsp;(IMS)</a></li>
	<li><a href="http://aura.abdn.ac.uk/">Institutional Repository</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/insurance-367.php">Insurance</a>&nbsp;- for staff</li>
	<li><a href="https://www.abdn.ac.uk/pir/">International Relations (and Politics)</a></li>
	<li><a href="https://www.abdn.ac.uk/study/international/">International Students</a></li>
	<li>Irish and Scottish Studies - see <a href="https://www.abdn.ac.uk/riiss/">Research Institute of Irish and Scottish Studies</a></li>
	<li>Italian - see the <a href="https://www.abdn.ac.uk/study/international/language-centre.php">Language Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/dit/index.php">IT Services</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/atech/">Assistive Technology</a></li>
		<li><a href="https://www.abdn.ac.uk/avu">Audio Visual</a></li>
		<li><a href="https://www.abdn.ac.uk/it/services/data-management/index.php">Data Management Services</a></li>
		<li><a href="https://www.abdn.ac.uk/medi-cal/">Medi-CAL</a></li>
		<li><a href="https://www.abdn.ac.uk/it/services/media/med-ill/">Medical Illustration</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DITadvertising.pdf">Service Catalogue</a></li>
		<li>Service Desk
		<ul>
			<li><a href="https://www.abdn.ac.uk/it/student/help/">IT support for students</a></li>
			<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-support.php">IT support for staff</a></li>
		</ul>
		</li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-resources.php#panel362">Telephony Services for Staff</a></li>
		<li><a href="https://www.abdn.ac.uk/tad/">Training and Documentation Team </a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-services/web.php">Web Team</a></li>
	</ul>
	</li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azJ"></a>J</h2>

<ul>
	<li>Japanese - see the <a href="https://www.abdn.ac.uk/study/international/language-centre.php">Language Centre</a></li>
	<li>Joblink - see&nbsp;<a href="https://www.ausa.org.uk/about/ausa_vacancies/">Students' Association Job Search</a></li>
	<li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
	<li><a href="https://www.abdn.ac.uk/ncs/departments/computing-science/joking-computer-309.php">Joking Computer</a> <!--<li><a href="https://www.abdn.ac.uk/philosophy/cpts/techno.hti">Journal of Ends and Means</a></li>--></li>
	<li><a href="https://abdn.primo.exlibrisgroup.com/discovery/search?vid=44ABE_INST:44ABE_VU1">Journals - electronic journals</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azK"></a>K</h2>

<ul>
	<li>KEY Learning Opportunities - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Centre for Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/about/campus/kings-college-chapel-380.php">King's College Chapel</a></li>
	<li><a href="https://www.abdn.ac.uk/accommodation/prospective-students/kings-hall-80.php">King's Hall </a></li>
	<li><a href="https://www.abdn.ac.uk/museums/" title="King's Museum">King's Museum</a></li>
	<li><a href="https://www.abdn.ac.uk/elphinstone/kist/">Kist - Elphinstone Kist</a></li>
	<li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/kosterlitz.php">Kosterlitz Centre for Therapeutics</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azL"></a>L</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/study/international/language-centre.php">Language Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/language-and-linguistics-1379.php">Language and Linguistics</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/">Language, Literature, Music and Visual Culture, School of</a></li>
	<li><a href="https://www.abdn.ac.uk/sdhp/history/research-61.php">Late Medieval and Early Modern Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/spanish-latin-american-studies-1393.php">Latin American Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/law/">Law</a></li>
	<li>Learning Technology - see <a href="https://www.abdn.ac.uk/cad/">Centre for Academic Development</a></li>
	<li>Legacies, gifts and donations - see the <a href="https://www.abdn.ac.uk/devtrust/">Development Trust</a></li>
	<li>Legal Studies - see <a href="https://www.abdn.ac.uk/law/">School of Law</a></li>
	<li><a href="https://www.abdn.ac.uk/library/" title="Library, Special Collections and Museums">Library, Special Collections and Museums</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/library/" title="Library">Library</a></li>
		<li><a href="https://www.abdn.ac.uk/library/documents/guides/gen/qggen002.pdf">Library Facilities and Services for Disabled Students</a>(PDF file)</li>
		<li><a href="https://www.abdn.ac.uk/library/using-libraries/opening-hours-83.php">Opening Hours</a></li>
		<li><a href="https://www.abdn.ac.uk/museums/" title="Museums and Collections">Museums and Collections</a></li>
		<li><a href="https://www.abdn.ac.uk/library/about/special/" title="Special Collections Centre">Special Collections Centre</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/research-interests-1381.php">Linguistic Research, Centre for </a></li>
	<li>Logic - see <a href="https://www.abdn.ac.uk/ncs/departments/computing-science/">Computing Science</a> and <a href="https://www.abdn.ac.uk/philosophy/">Philosophy</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/quicklinks/lost_found.shtml">Lost and Found Property</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azM"></a>M</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/estates/supportservices/mailroom.shtml">Mail Services</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/maintenance/">Maintenance</a></li>
	<li><a href="https://www.abdn.ac.uk/business/">Management Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/index.php">Management Information Systems</a></li>
	<li><a href="https://www.abdn.ac.uk/about/campus/maps/index.php">Maps - Campus</a></li>
	<li>Marine Bacteria - see <a href="http://www.ncimb.co.uk/">National Collections of Industrial, Marine and Food Bacteria</a></li>
	<li><a href="https://www.abdn.ac.uk/mass-spec/">Mass Spectrometry Facility</a></li>
	<li><a href="https://www.abdn.ac.uk/mathematics/">Mathematical Sciences</a></li>
	<li><a href="https://www.abdn.ac.uk/medi-cal/">Medi-CAL Unit</a></li>
	<li><a href="https://www.abdn.ac.uk/mediareleases/">Media Releases</a></li>
	<li><a href="https://www.abdn.ac.uk/it/services/media/med-ill/">Medical Illustration</a></li>
	<li><a href="https://www.abdn.ac.uk/library/using-libraries/medical-library-127.php">Medical Library</a></li>
	<li>Medicine
	<ul>
		<li><a href="https://www.abdn.ac.uk/careers/resources/occupations/16/" title="Medicine Careers Resources">Medicine Careers Resources</a></li>
		<li><a href="https://www.abdn.ac.uk/mymbchb/">MyMBChB Staff and Student Resources</a> (Login Required)</li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/smmsn/" style="line-height: 17px;">Medicine, Medical Sciences and Nutrition, School of</a></li>
	<li><a href="https://www.abdn.ac.uk/motd">Message of the Day</a></li>
	<li><a href="https://www.abdn.ac.uk/mentalhealth/">Mental Health</a></li>
	<li><a href="https://www.abdn.ac.uk/business-info/working-with-students/career-mentoring.php">Mentoring</a></li>
	<li><a href="https://www.abdn.ac.uk/ceminacs/">Micro and Nanomechanics, Centre for</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/facilities/microscopy-histology/">Microscopy and Imaging facility</a></li>
	<li>Minutes - see <a href="https://www.abdn.ac.uk/staffnet/governance/minutes-and-agendas-135.php">Committees</a></li>
	<li><a href="https://www.abdn.ac.uk/modernthought/">Modern Thought, Centre for</a></li>
	<li>Molecular and Cell Biology - see the <a href="https://www.abdn.ac.uk/smmsn/">School of&nbsp;Medicine, Medical Sciences and Nutrition</a></li>
	<li><a href="https://www.abdn.ac.uk/about/campus/maps/view/119/">Moslem Prayer Room and Mosque</a></li>
	<li><a href="https://www.aberdeenmosque.org/">Mosque</a></li>
	<li><a href="https://www.abdn.ac.uk/motd">MOTD</a></li>
	<li><a href="https://www.abdn.ac.uk/museums/">Museums</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/museums/collections/medical.php">Anatomy Museum</a></li>
		<li><a href="https://www.abdn.ac.uk/geosciences/departments/geology/museum-and-geological-collection-532.php">Geological Collections</a></li>
		<li><a href="https://www.abdn.ac.uk/museums/" title="King's Museum">King's Museum</a></li>
		<li><a href="http://homepages.abdn.ac.uk/npmuseum/">Natural Philosophy Collection of Scientific Instruments</a></li>
		<li><a href="https://www.abdn.ac.uk/museums/collections/pathology-collction-details-246.php">Pathology and Forensic Medicine Collection</a></li>
		<li><a href="https://www.abdn.ac.uk/museums/exhibitions/zoology-museum-588.php">Zoology Museum </a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/music/">Music</a></li>
	<li><a href="https://www.abdn.ac.uk/scottskinner/">Music of James Scott Skinner</a></li>
	<li><a href="https://www.abdn.ac.uk/about/campus/maps/view/119/">Muslim Prayer Room</a> and <a href="https://www.abdn.ac.uk/about/campus/maps/view/118/">Mosque</a></li>
	<li>MyAberdeen
	<ul>
		<li><a href="https://www.abdn.ac.uk/toolkit/systems/myaberdeen-students/">Help for Students</a></li>
		<li><a href="https://www.abdn.ac.uk/toolkit/systems/myaberdeen-staff/">Help for Staff</a></li>
	</ul>
	</li>
	<li><a href="https://myview.abdn.ac.uk/dashboard/dashboard-ui/index.html#/landing">MyHR</a>&nbsp;(Internal Access&nbsp;Only)</li>
	<li><a href="https://www.abdn.ac.uk/local/mysql/">MySQL Guide</a></li>
	<li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azN"></a>N</h2>

<ul>
	<li><a href="http://www.ncimb.co.uk/">National Collections of Industrial, Marine and Food Bacteria</a></li>
	<li><a href="https://www.abdn.ac.uk/sncs/">Natural and Computing Sciences, School of</a></li>
	<li><a href="https://www.abdn.ac.uk/ncs/departments/computing-science/natural-language-generation-187.php">Natural Language Generation Research Group</a></li>
	<li><a href="http://www.ncimb.co.uk/">NCIMB</a></li>
	<li><a href="https://www.abdn.ac.uk/ims/research/neuroscience/">Neurobiology Research Theme</a></li>
	<li><a href="https://www.abdn.ac.uk/neuroscience/">Neuroscience</a></li>
	<li><a href="https://www.abdn.ac.uk/newstudents/">New Students Website</a></li>
	<li><a href="https://www.abdn.ac.uk/news/">News</a></li>
	<li><a href="https://www.aspirenorth.co.uk/">North Forum</a></li>
	<li>Norwegian - see the <a href="https://www.abdn.ac.uk/study/international/language-centre.php">Language Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/research/centre-for-the-novel-215.php">Novel, Centre for the</a></li>
	<li>Nursery, <a href="https://www.abdn.ac.uk/rockinghorse/">Rocking Horse Nursery</a></li>
	<li>Nutrition - see <a href="https://www.abdn.ac.uk/rowett/">The Rowett Institute&nbsp;of Nutrition and Health</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azO"></a>O</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/obsgynae/">Obstetrics and Gynaecology</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/support-for-staff-226.php#panel5511">Occupational Health Service</a></li>
	<li><a href="http://www.oceanlab.abdn.ac.uk/">Oceanlab</a></li>
	<li><a href="https://www.abdn.ac.uk/admin/">Office, University (Central Administration)</a></li>
	<li><a href="https://www.abdn.ac.uk/about/campus/maps/view/48/">Old Town House, Aberdeen</a></li>
	<li>Online Payslip
	<ul>
		<li><a href="https://myview.abdn.ac.uk/dashboard/dashboard-ui/index.html#/landing">MyHR</a>&nbsp;(Internal Access Only)</li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/ereg-login/">Online Registration</a></li>
	<li><a href="http://www.store.abdn.ac.uk/" title="The Online Store">Online Store</a></li>
	<li>Open Lecture Programme - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
	<li><a href="https://www.abdn.ac.uk/acamh/clinical-service/trauma-orthopaedics.php">Orthopaedic Surgery</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-communications.php">Outlook and Outlook web access</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azP"></a>P</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/child_health/">Paediatrics</a></li>
	<li><a href="https://www.abdn.ac.uk/piprgroup">Parallel and Image Processing Research Group (Engineering) </a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/parking-793.php">Parking</a></li>
	<li>Part time Courses - see <a href="https://www.abdn.ac.uk/lifelonglearning/">Lifelong Learning</a></li>
	<li>Passwords - changing your password
	<ul>
		<li><a href="https://www.abdn.ac.uk/local/passwd/">Staff</a></li>
		<li><a href="https://www.abdn.ac.uk/dit/student/help/password">Students</a></li>
	</ul>
	</li>
	<li>Past papers - see <a href="https://www.abdn.ac.uk/library/support/exam-papers-180.php">Exam Papers database</a></li>
	<li><a href="https://www.abdn.ac.uk/museums/collections/pathology-collction-details-246.php">Pathology and Forensic Medicine Collection</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/payroll-information-191.php">Payroll</a>
	<ul>
		<li><a href="https://myview.abdn.ac.uk/dashboard/dashboard-ui/index.html#/landing">MyHR</a>&nbsp;(Internal Access Only)</li>
	</ul>
	</li>
	<li>PCs - <a href="https://www.abdn.ac.uk/freepcs/">real time display of free PCs</a></li>
	<li><a href="https://www.abdn.ac.uk/child_health/">Pediatrics</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/personaltutors.php">Personal Tutors</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Personnel</a></li>
	<li><a href="https://www.abdn.ac.uk/geology/">Petroleum Geology</a></li>
	<li><a href="https://www.abdn.ac.uk/philosophy/">Philosophy</a></li>
	<li>Photocopying - see <a href="https://www.abdn.ac.uk/uniprint/">Copyshop</a> and <a href="https://www.abdn.ac.uk/uniprint/">Reprographics</a></li>
	<li>Photographic reproduction and copying - see <a href="https://www.abdn.ac.uk/uniprint/">Reprographics</a></li>
	<li>Physical Education - see <a href="http://www.aberdeensportsvillage.com/">Aberdeen Sports Village</a></li>
	<li><a href="https://www.abdn.ac.uk/physics/">Physics</a></li>
	<li>Placements and Work Experience&nbsp;- for&nbsp;<a href="https://www.abdn.ac.uk/careers/jobs-work-experience/index.php">Students</a></li>
	<li>Plagiarism
	<ul>
		<li><a href="https://www.abdn.ac.uk/toolkit/skills/referencing/">Guidance and signposting to resources - Toolkit</a></li>
		<li>Guidelines from the <a href="https://www.abdn.ac.uk/staffnet/teaching/academic-quality-handbook-838.php">Academic Quality Handbook</a></li>
	</ul>
	</li>
	<li>Planning</li>
	<li><a href="https://www.abdn.ac.uk/cpem/">Planning and Environmental Management, Centre for</a></li>
	<li>Plant and Soil Science- see <a href="https://www.abdn.ac.uk/sbs/">School of Biological Sciences</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/academic-quality-handbook/Policy%20on%20Drugs%20and%20Alcohol%20Misuse.pdf" target="_blank">Policy on Drugs and Alcohol Misuse (Students)</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DITadvertising.pdf">Policy on the use of University web pages for commercial advertising</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy, Planning and Governance</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/policies-and-procedures-134.php">Policy Zone</a></li>
	<li><a href="https://www.abdn.ac.uk/pir/">Politics and International Relations</a></li>
	<li>Portals:
	<ul>
		<li><a href="https://www.abdn.ac.uk/studenthub/login">Student Hub</a></li>
	</ul>
	</li>
	<li>Portuguese - see the <a href="https://www.abdn.ac.uk/study/international/language-centre.php">Language Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/prospectus/">Postgraduate Catalogue of Courses</a></li>
	<li><a href="https://www.abdn.ac.uk/study/courses/postgraduate/">Postgraduate Prospectus</a></li>
	<li><a href="https://www.abdn.ac.uk/pgrs/">Postgraduate Research School</a></li>
	<li><a href="https://www.abdn.ac.uk/about/campus/maps/view/119/">Prayer Room, Muslim and Mosque</a></li>
	<li><a href="https://www.abdn.ac.uk/capc/">Primary Care, Centre of Academic </a></li>
	<li><a href="https://www.abdn.ac.uk/it/services/media/print_services.php">Printing - Uniprint</a></li>
	<li><a href="https://www.abdn.ac.uk/it/student/print/print-shop.php">The Print Shop</a></li>
	<li><a href="https://www.abdn.ac.uk/site-information/privacy.php">Privacy Statement</a></li>
	<li><a href="https://www.abdn.ac.uk/registry/prizes/">Prizes and Medals</a></li>
	<li><a href="https://www.abdn.ac.uk/procurement/">Procurement</a></li>
	<li>Professional Development - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation, Commercial and CPD Services</a></li>
	<li><a href="https://www.abdn.ac.uk/business/">Property, University of Aberdeen Business School</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/strategy.shtml">Property Development (Estates Section)</a></li>
	<li>Prospect CPD - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation, Commercial and CPD Services</a></li>
	<li><a href="https://www.abdn.ac.uk/prospectus/">Prospectuses</a></li>
	<li>Proteins/Proteomics
	<ul>
		<li><a href="https://www.abdn.ac.uk/proteomics/">Aberdeen Proteomics</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/psychology/">Psychology</a></li>
	<li><a href="https://www.abdn.ac.uk/engage">Public Engagement with Research</a></li>
	<li><a href="https://abdn.pure.elsevier.com/en/">Publications, Research</a></li>
	<li>Public Relations - see <a href="https://www.abdn.ac.uk/news/communications/index.php">Communications</a></li>
	<li>Public Sector Management - see <a href="https://www.abdn.ac.uk/business/about/index.php">Business School</a></li>
	<li><a href="https://www.abdn.ac.uk/foi/">Publication Scheme</a></li>
	<li>Publishing on the web
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DIT_e-publishing.pdf">Code of Practice for the Publishing of Information in Electronic Format</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DITadvertising.pdf">Policy on the use of University web pages for commercial advertising</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/research/pure-306.php">Pure</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azQ"></a>Q</h2>

<ul>
	<li>Quality
	<ul>
		<li><a href="https://www.abdn.ac.uk/elir">Academic Quality Audit</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/teaching/academic-quality-handbook-838.php">Academic Quality Handbook</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/ncs/departments/physics/quantum-gravity-and-gauge-236.php">Quantum Gravity Group</a></li>
</ul>

<p align="right"><a href="#TOP"><em>Return to top</em></a></p>

<h2><a name="azR"></a>R</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/ims/research/abic/">Radiology</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/university-records-management-280.php">Records Management</a></li>
	<li><a href="https://www.abdn.ac.uk/jobs/">Recruitment</a></li>
	<li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/court-members-116.php#panel872">Rector</a></li>
	<li>Reformed Theology - see <a href="https://www.abdn.ac.uk/divinity/">Divinity and Religious Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/students/new-students/registration.php">Registration</a>&nbsp;- Online Student Registration</li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/registry-972.php">Registry</a></li>
	<li>Regulations, Degree Regulations - see <a href="https://www.abdn.ac.uk/registry/calendar/">University Calendar</a></li>
	<li><a href="https://www.abdn.ac.uk/religious_studies/">Religious Studies</a></li>
	<li>Remote Access - see <a href="https://www.abdn.ac.uk/staffnet/working-here/it-services/remote-access.php#panel1239">Virtual Private Network (VPN)</a></li>
	<li>Renewables - see <a href="https://www.abdn.ac.uk/energy/">Institute of Energy Technologies</a></li>
	<li><a href="https://www.abdn.ac.uk/it/services/media/Reprographics.php">Reprographics</a></li>
	<li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/research/impact-ref-and-open-access.php">Research Excellence Framework</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/research/pure-306.php">Research Information System (Pure)</a></li>
	<li><a href="https://www.abdn.ac.uk/riiss/">Research Institute of Irish and Scottish Studies</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/riiss/about/ahrc-centre-66.php">AHRC Research Centre for Irish and Scottish Studies</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-services/passwords.php">Reset Password</a></li>
	<li><a href="https://abdn.pure.elsevier.com/en/">Research Publications</a></li>
	<li>Residential and Catering Services - see <a href="https://www.abdn.ac.uk/hospitality/">Hospitality Services</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/study/reassessment.php">Resits</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/life/food-drink-and-retail.php">Retail</a></li>
	<li>Reunions - see <a href="https://www.abdn.ac.uk/alumni_relations/">Alumni Relations</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/risk-management-and-audit-276.php">Risk Management</a></li>
	<li><a href="https://www.abdn.ac.uk/rockinghorse/">Rocking Horse Nursery</a></li>
	<li>Roman Catholic Chaplaincy</li>
	<li><a href="http://www.iuscivile.com/">Roman Law Resources</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/room-booking-708.php">Room Bookings</a></li>
	<li><a href="https://www.abdn.ac.uk/rowett">Rowett Institute of Nutrition and Health </a></li>
	<li>Russian
	<ul>
		<li>Part time courses at the <a href="https://www.abdn.ac.uk/study/international/language-centre.php">Language Centre</a></li>
	</ul>
	</li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azS"></a>S</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/estates/supportservices/sacrist.shtml">Sacrists</a></li>
	<li>Safety - see <a href="https://www.abdn.ac.uk/safety/">Health and Safety</a></li>
	<li>Scandinavian Studies - see <a href="https://www.abdn.ac.uk/cfss/">Centre for Scandinavian Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/sbs/">School of Biological Sciences</a></li>
	<li><a href="https://www.abdn.ac.uk/sdhp/">School of Divinity, History and Philosophy </a></li>
	<li><a href="https://www.abdn.ac.uk/education/">School of Education</a></li>
	<li><a href="https://www.abdn.ac.uk/engineering/">School of Engineering</a></li>
	<li><a href="https://www.abdn.ac.uk/geosciences/">School of Geosciences</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/">School of Language, Literature, Music and Visual Culture</a></li>
	<li><a href="https://www.abdn.ac.uk/law/">School of Law</a></li>
	<li><a href="https://www.abdn.ac.uk/smmsn/">School of&nbsp;Medicine, Medical Sciences and Nutrition</a></li>
	<li><a href="https://www.abdn.ac.uk/sncs/">School of Natural and Computing Sciences</a></li>
	<li><a href="https://www.abdn.ac.uk/psychology/">School of Psychology</a></li>
	<li><a href="https://www.abdn.ac.uk/socsci/">School of Social Science</a></li>
	<li><a href="https://www.abdn.ac.uk/scottskinner/">Scott Skinner, The Music of James </a></li>
	<li>Scottish and Irish Studies - see <a href="https://www.abdn.ac.uk/riiss/">Research Institute of Irish and Scottish Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/emigration/">Scottish Emigration Database</a></li>
	<li><a href="https://www.abdn.ac.uk/elphinstone/">Scottish Ethnology</a></li>
	<li><a href="https://www.abdn.ac.uk/sfirc/">Scottish Fish Immunology Research Centre</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Search for Staff</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/supportservices/security.shtml">Security</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/course-and-programme-approval-6102.php">SENAS course programme proposal forms </a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/governance/senate/index.php">Senate</a>
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/governance/senate/minutes/index.php">Senate Minutes</a></li>
	</ul>
	</li>
	<li>Service Desk
	<ul>
		<li><a href="https://www.abdn.ac.uk/it/student/help/">IT support for students</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-support.php">IT support for staff</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/sfirc/">SFIRC</a></li>
	<li>Shops - see <a href="https://www.abdn.ac.uk/infohub/life/food-drink-and-retail.php">Retail</a></li>
	<li>Sixth Century Campaign - see the <a href="https://www.abdn.ac.uk/devtrust/">Development Trust</a></li>
	<li><a href="https://www.abdn.ac.uk/scottskinner/">Skinner, The Music of James Scott</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/smallads.php">Small Ads mailing list archive</a></li>
	<li><a href="https://www.abdn.ac.uk/socsci/">Social Science, School of</a></li>
	<li><a href="http://www.ausa.org.uk/">Societies and Clubs, Student</a></li>
	<li><a href="https://www.abdn.ac.uk/sociology/">Sociology</a></li>
	<li>SOCRATES - see <a href="https://www.abdn.ac.uk/erasmus/">Erasmus</a></li>
	<li>Spanish - <a href="https://www.abdn.ac.uk/sll/disciplines/spanish-latin-american-studies-1393.php">see Hispanic Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/cshad/">Spirituality, Health and Disability, Centre for (CSHAD)</a></li>
	<li>Sport
	<ul>
		<li><a href="http://www.aberdeensportsvillage.com/" target="_blank" title="Opens in new window">Aberdeen Sports Village</a></li>
		<li><a href="https://www.abdn.ac.uk/sportandexercise/">Sport &amp; Exercise</a></li>
		<li><a href="http://www.ausa.org.uk/" target="_blank" title="Opens in new window">Sports Union</a></li>
	</ul>
	</li>
	<li>Sports and Exercise Science - see the <a href="https://www.abdn.ac.uk/smmsn/">School of&nbsp;Medicine, Medical Sciences and Nutrition</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/administration/staff_accomm.shtml">Staff Accommodation</a></li>
	<li><a href="https://www.abdn.ac.uk/directory/">Staff Directory</a>&nbsp;- including external access</li>
	<li><a href="https://www.abdn.ac.uk/ncs/departments/mathematics/index.php">Statistics</a></li>
	<li><a href="http://www.store.abdn.ac.uk/" title="The Online Store">Store</a>&nbsp;(Online)</li>
	<li><a href="http://www.ausa.org.uk/">Students' Association</a></li>
	<li><a href="https://www.ausa.org.uk/about/ausa_vacancies/">Students' Association Job Search</a></li>
	<li>Student Finance - Information
	<ul>
		<li><a href="https://www.abdn.ac.uk/undergraduate/finance.php">Undergraduates</a></li>
		<li><a href="https://www.abdn.ac.uk/postgraduate/finance.php">Postgraduate Students</a></li>
		<li><a href="https://www.abdn.ac.uk/international/finance.php">International Students</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/students/support/index.php">Student Health and Sport</a></li>
	<li><a href="https://www.abdn.ac.uk/sls/">Student Learning Service</a></li>
	<li><a href="https://www.abdn.ac.uk/studenthub/login">Student Hub</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/student-record-system-706.php">Student Record System</a></li>
	<li><a href="https://www.abdn.ac.uk/sras/">Student Recruitment and Admissions Services</a></li>
	<li>Students' Representative Council (SRC) - <a href="http://www.ausa.org.uk/">See Students' Association</a></li>
	<li><a href="https://www.abdn.ac.uk/student-support/">Student Support </a></li>
	<li>Student Union - see <a href="http://www.ausa.org.uk/">Students' Association</a></li>
	<li><a href="https://www.abdn.ac.uk/studentmail/">Studentmail</a></li>
	<li><a href="https://www.abdn.ac.uk/alsu/">Study Skills for students</a></li>
	<li><a href="https://www.abdn.ac.uk/study/undergraduate/summer-school-for-access-2116.php">Summer School for Access</a></li>
	<li><a href="https://www.abdn.ac.uk/estates/supportservices/">Support Services</a></li>
	<li><a href="https://www.abdn.ac.uk/student-support/">Supporting Students</a></li>
	<li>Sustainability and Social Responsibility</li>
	<li><a href="https://www.abdn.ac.uk/sustainable-international-development/">Sustainable International Development, Centre for</a></li>
	<li><a href="https://www.abdn.ac.uk/suttie-centre/">Suttie Centre</a></li>
	<li><a href="http://www.aberdeensportsvillage.com/index.php/aquatics" target="_blank" title="Opens in new window">Swimming</a></li>
	<li>Systematic Theology - see <a href="https://www.abdn.ac.uk/divinity/">Divinity</a> and <a href="https://www.abdn.ac.uk/religious_studies/">Religious Studies</a></li>
	<li><a href="https://www.abdn.ac.uk/systemsbiology/">Systems Biology</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azT"></a>T</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/library/about/taylor/">Taylor Library </a></li>
	<li>Teaching - see <a href="https://www.abdn.ac.uk/cad/">Centre for Academic Development</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/teaching/timetables-416.php">Teaching Timetable</a></li>
	<li>Technology Transfer - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
	<li><a href="https://www.abdn.ac.uk/directory/">Telephone Directory</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-resources.php#panel362">Telephony Services</a></li>
	<li><a href="https://www.abdn.ac.uk/students/term-dates.php">Term Dates and Week Numbers</a></li>
	<li>Theology
	<ul>
		<li><a href="https://www.abdn.ac.uk/divinity/">School of Divinity and Religious Studies</a></li>
	</ul>
	</li>
	<li>Timetables
	<ul>
		<li><a href="https://www.abdn.ac.uk/students/academic-life/term--dates.php">Term Dates</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/teaching/timetables-416.php#panel6716">Teaching Timetable</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/about/campus/maps/view/48/">Town House, Old Aberdeen</a></li>
	<li><a href="https://www.abdn.ac.uk/tad/">Training and Documentation Team</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/study/changes-to-studies.php">Transfers</a></li>
	<li>Transport - see <a href="https://www.abdn.ac.uk/engineering/research/ctr/index.php">Centre for Transport Research (CTR)</a></li>
	<li>Travel
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/travel-benefits/corporate-travel.php">Corporate Travel</a></li>
		<li><a href="https://www.abdn.ac.uk/study/international/travelling-to-aberdeen.php">Travelling to the University</a></li>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/travel-overseas-2130.php">Travel Overseas</a></li>
		<li><a href="https://gohealthservices.scot.nhs.uk/travel-clinic" target="_blank" title="Go Health Service">Travel Clinic - Health Service</a></li>
	</ul>
	</li>
	<li>Tropical Environmental Science - see <a href="https://www.abdn.ac.uk/study/courses/undergraduate/science/plant_soil/">Plant and Soil Science</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/finance/tuition-fees.php">Tuition Fees</a></li>
	<li><a href="https://www.abdn.ac.uk/mycourses/">Tutorial Booking</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azU"></a>U</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/ucu/">UCU (University and College Union)</a></li>
	<li><a href="https://www.abdn.ac.uk/registry/courses/">Undergraduate Catalogue of Courses</a></li>
	<li><a href="https://www.abdn.ac.uk/study/courses/undergraduate/">Undergraduate Prospectus</a></li>
	<li>Union, Aberdeen University Students' - <a href="http://www.ausa.org.uk/">See Students' Association</a></li>
	<li><a href="https://www.abdn.ac.uk/it/services/media/print_services.php">Uniprint</a></li>
	<li>UNISON:
	<ul>
		<li><a href="http://www.aub-unison.org.uk/">Aberdeen Universities Branch</a></li>
		<li><a href="http://www.unison.org.uk/">National Website</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/ucu/">University and College Union (UCU)</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/research/word-centre-for-creative-writing-597.php">University of Aberdeen Writers Festival</a></li>
	<li><a href="https://www.abdn.ac.uk/registry/calendar/">University Calendar</a></li>
	<li><a href="https://www.abdn.ac.uk/business/">University of Aberdeen Business School</a></li>
	<li>Urology - see <a href="https://www.abdn.ac.uk/urology/">Academic Urology Unit</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azV"></a>V</h2>

<ul>
	<li>Vacancies, staff - see <a href="https://www.abdn.ac.uk/jobs/">Human Resources</a></li>
	<li><a href="https://www.abdn.ac.uk/it/services/media/video-conferencing.php">Video Conferencing</a></li>
	<li><a href="https://www.abdn.ac.uk/museums/exhibitions/online-exhibitions.php">Virtual Museum - Marischal Virtual Museum </a></li>
	<li>Virtual Private Network (VPN)
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/working-here/it-services/remote-access.php#panel1239">About the VPN, including connection guidelines</a></li>
		<li><a href="https://remote.abdn.ac.uk">Login to the VPN</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/study/open-days.php">Visits to the University</a>
	<ul>
		<li>Old Aberdeen visits - see <a href="https://www.abdn.ac.uk/about/campus/maps/view/48/">Old Town House</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/sll/disciplines/film-visual-culture-1338.php">Visual Culture</a></li>
	<li>Vocational Training - see <a href="https://www.abdn.ac.uk/research-innovation/">Research and Innovation</a></li>
	<li>VPN - see <a href="https://www.abdn.ac.uk/staffnet/working-here/it-services/remote-access.php#panel1239">Virtual Private Network</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azW"></a>W</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/diss/heritage/gww/index.htm">Washington Wilson, George archive</a></li>
	<li><a href="https://www.abdn.ac.uk/dit/documents/Web_content_filter_guidelines.pdf">Web Content Filtering</a></li>
	<li>Web Design - <a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-authorscreators/">Accessibility of online materials</a></li>
	<li>Web Policy
	<ul>
		<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DIT_e-publishing.pdf">Code of Practice for the Publishing of Information in Electronic Format</a>- PDF</li>
		<li><a href="https://www.abdn.ac.uk/staffnet/documents/policy-zone-information-policies/DITadvertising.pdf">Policy on the use of University web pages for commercial advertising</a>- PDF</li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/weddings/">Weddings</a></li>
	<li><a href="https://www.abdn.ac.uk/students/term-dates.php">Week Numbers and Term Dates</a></li>
	<li><a href="https://www.abdn.ac.uk/wireless/">Wireless Network Access</a></li>
	<li><a href="https://www.abdn.ac.uk/infohub/study/changes-to-studies.php">Withdrawal</a></li>
	<li><a href="https://www.abdn.ac.uk/sll/research/word-centre-for-creative-writing-597.php">Word - University of Aberdeen Writers' Festival</a></li>
	<li>Work Placements
	<ul>
		<li><a href="https://www.abdn.ac.uk/business-info/working-with-students/student-placements-internships.php">For Employers</a></li>
		<li><a href="https://www.abdn.ac.uk/careers/jobs-work-experience/work-experience-during-your-studies.php">For Students</a></li>
	</ul>
	</li>
	<li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>

<h2><a name="azX"></a>X</h2>

<h2><a name="azY"></a>Y</h2>

<h2><a name="azZ"></a>Z</h2>

<ul>
	<li>Zoology - see <a href="https://www.abdn.ac.uk/sbs/">School of Biological Sciences</a>

	<ul>
		<li><a href="https://www.abdn.ac.uk/museums/exhibitions/zoology-museum-588.php">Zoology Museum</a></li>
	</ul>
	</li>
</ul>

<p align="right"><em><a href="#TOP">Return to top</a></em></p>
                        </div>
                    </div>
                                </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/about/index.php">About</a></li>
            
            <li><a href="/about/our-website/index.php">Our Website</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/about/our-website/atoz.php" class="current" aria-current="page">A to Z</a></li>
                
                <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                
                <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                
                <li><a href="/about/our-website/notice-and-takedown-policy-675.php">Notice and Takedown </a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/about/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
