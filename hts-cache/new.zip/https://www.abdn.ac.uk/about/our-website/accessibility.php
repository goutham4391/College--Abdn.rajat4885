<!doctype html>
<html lang="en-GB" dir="ltr">
    <head>
    <meta charset="utf-8">
    <title>Accessibility Statement for the University of Aberdeen Website | About | The University of Aberdeen</title>
    <!-- Page ID : 542 -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Information on the accessibility standards we adopt in our website">
    
        <meta name="keywords" content="accessibility, accessibility statement, Web Content Accessibility Guidelines, wcag, equalities, Accessibility Regulations 2018, Web Content Accessibility Guidelines,  mobile accessibility">
            <link rel="apple-touch-icon" sizes="180x180" href="/global/images/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/global/images/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/global/images/icons/favicon-16x16.png">
    <link rel="manifest" href="/global/images/icons/manifest.json">
    <link rel="mask-icon" href="/global/images/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-config" content="/global/images/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    
        <link rel="stylesheet" href="/global/css/opentext_responsive/global.css?cb=20221026">
            <!--[if lte IE 8]>
        <link rel="stylesheet" href="/global/css/opentext_responsive/ie_lte8.css?cb=20221026" media="screen">
    <![endif]-->
    <link rel="stylesheet" href="/global/css/opentext_responsive/funnelback_search.css?cb=20221026" media="screen">
    <link rel="stylesheet" href="https://uoab-search.squiz.cloud/s/resources-global/css/funnelback.autocompletion-2.6.0.css" media="screen">
        <link rel="stylesheet" href="/global/css/opentext_responsive/print.css?cb=20221026" media="print">
        <!--[if lte IE 8]>
        <script>
            var els = ['article', 'aside', 'details', 'figcaption', 'figure', 'footer', 'header', 'hgroup', 'main', 'nav', 'section', 'summary', 'picture'];
            for (var i = 0; i < els.length; i ++) {
                document.createElement(els[i]);
            }
        </script>
    <![endif]-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/global/js/priorityplus_navigation.js"></script>
    <!--[if IE 6]>
        <script src="/global/js/ie.js"></script>
    <![endif]-->
    <script>window.MSInputMethodContext && document.documentMode && document.write('<script src="/global/js/ie11CustomProperties.min.js"><\/script>');</script>
    
<script>
    var global_base_url = '/global/';
</script>
</head>
    <body class="no_js">
        <script>
            document.getElementsByTagName('body')[0].className = '';
        </script>
        
    <header id="top">
        <ul class="skip_links">
            <li><a href="#main">Skip to content</a></li>
            <li><a href="https://www.abdn.ac.uk/about/our-website/accessibility.php">About Accessibility on our website</a></li>
        </ul>
        <div id="modal_fade"></div>
    <div class="global_header_wrapper">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="global_header">
                    <div class="clearfix">
                        <div class="uni_logo">
                            
                          <a href="https://www.abdn.ac.uk/">
                              <img src="/global/images/layout/UoA_Primary_Logo_RGB_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Primary_Logo_RGB_2018.svg?cb=20221026" alt="University of Aberdeen" style="width: 300px">
                          </a>
                                                  </div>
                        <nav id="uni_menu" class="uni_menu no_js row" aria-label="University of Aberdeen Navigation">
    <ul>
        <li>
            <a href="https://www.abdn.ac.uk/study/">Study</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/undergraduate/">Undergraduate</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/degree-programmes/">Undergraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/subject-areas/">Subject Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/study-abroad-and-exchanges.php">Go Abroad</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/finance.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/undergraduate/how-to-apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-taught/">Postgraduate Taught</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/degree-programmes/">Postgraduate Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/online/">Online Degrees</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/part-time.php">Part-time Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/finance-funding-1599.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-taught/apply.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/research-areas/">Research Areas</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/current-phd-opportunities-1640.php">PhD Opportunities</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/finance-funding-1641.php">Finance and Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/how-to-apply-1639.php">How to Apply</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/study/online/">Online Learning</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/online/degrees.php">Online Degrees</a></li>
                        <li><a href="https://on.abdn.ac.uk/courses/">Short Courses</a></li>
                        <li><a href="https://on.abdn.ac.uk/categories/">Study Subjects</a></li>
                        <li><a href="https://on.abdn.ac.uk/how-online-learning-works/">How Online Learning Works</a></li>
                        <li><a href="https://on.abdn.ac.uk/discover/fees-funding-and-discounts/">Fees and Funding</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/">About</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/campus/">Campus</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Maps and Directions</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/contact/">Contact Information</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                        <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/history/">History</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/facts-figures/">Facts &amp; Figures</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/about/colleges-schools-institutes/">Schools and Institutes</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/strategy-and-governance/">Strategy and Governance</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/management/">Management</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/coronavirus/">Coronavirus (Covid-19)</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li class="menu_img menu_img_about"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/research/">Research</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/research/explore/">Explore our Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/impact/">Impact</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/institutes-centres/">Find a Centre or Institute</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/facilities/">Facilities</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/postgraduate-research/">Postgraduate Research Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/jobs/">Research Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/support/">Research Support</a></li>
                    </ul>
                </li>
                <li class="uni_menu_2col col_img_right">
                    <ul>
                        <li class="menu_img menu_img_research"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_alumni"></li>
                    </ul>
                <li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/alumni/">Alumni</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/alumni/connected/">Stay in Touch</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/involved/">Get Involved</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/benefits-services/">Benefits and Services</a></li>
                        <li><a href="https://www.abdnalumni.org/">Alumni Hub</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/events-reunions.php">Events and Reunions</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/our-alumni/">Our Alumni</a></li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/giving/">Development Trust</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/giving/difference/">Make a Difference</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/talk/">Apply for Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/giving/giving/">Giving</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/business-info/">Business</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li class="uni_menu_2col">
                    <ul>
                        <li class="menu_img menu_img_business"></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/training/">Development and Training</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/facilities-and-expertise/">Facilities and Expertise</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/working-with-students/">Working with Students</a></li>
                    </ul>
                </li>
                <li>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/business-info/collaborative-research/">Collaboration</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/funding/">Funding</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/business-contacts/">Business Contacts</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
        <li>
            <a href="https://www.abdn.ac.uk/about/quick-links.php">Quick Links</a>
            <ul class="uni_menu_wide uni_menu_4col col">
                <li>
                    <b><a href="https://www.abdn.ac.uk/students/">Student Resources</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mytimetable-3376.php">MyTimetable</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/academic-life/mycurriculum-3375.php">MyCurriculum</a></li>
                        <li><a href="https://abdn.blackboard.com/">MyAberdeen</a></li>
                        <li><a href="https://www.abdn.ac.uk/studenthub/">Student Hub</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Student Email</a></li>
                        <li><a href="https://www.abdn.ac.uk/students/student-channel/">Student Channel</a></li>
                        <li class="uni_menu_text_box">
                            <strong>Infohub Opening Hours <i class="fa fa-clock-o" aria-hidden="true"></i></strong>
                            <dl class="clearfix">
                                <dt>Mon - Thu</dt>
                                <dd>09:00 - 17:00</dd>
                                <dt>Fri</dt>
                                <dd>10:00 - 17:00</dd>
                                <dt>Sat - Sun</dt>
                                <dd>Closed</dd>
                            </dl>
                            Email: <a href="mailto:infohub@abdn.ac.uk">infohub@abdn.ac.uk</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <b><a href="https://www.abdn.ac.uk/staffnet/">StaffNet</a></b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/staffnet/working-here/">Working Here</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/secure/management-information-systems-1428.php">Management Information Systems</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/teaching/">Teaching &amp; Learning</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/governance/">Policy &amp; Governance</a></li>
                        <li><a href="https://www.outlook.com/abdn.ac.uk">Staff Email</a></li>
                    </ul>
                </li>
                <li>
                    <b>Our Website</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                        <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                        <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                        <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                    </ul>
                </li>
                <li>
                    <b>Popular</b>
                    <ul>
                        <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                        <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                        <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                        <li><a href="https://www.abdn.ac.uk/epayments/">ePayments</a></li>
                        <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                        <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
                        <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                        <li class="uni_menu_close">
                            <a href="#">
                                Close <i class="fa fa-times" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<div class="toggle_controls">
    <a href="https://www.abdn.ac.uk/search/" id="uni_search_toggle" class="uni_search_toggle no_js">
        <i class="fa fa-search" aria-hidden="true"></i>
        <span>Search</span>
    </a>
    <a href="#section_nav" class="uni_menu_toggle uni_menu_show_mobile_only">
        <i class="fa fa-navicon" aria-hidden="true"></i>
        <span>Menu</span>
    </a>
</div>
<form id="global_search" method="get" role="search" action="https://www.abdn.ac.uk/search/results.php" aria-label="Search the University of Aberdeen website">
    <fieldset>
        <legend>Search Our Website</legend>
        
            <label for="within" class="offscreen">Search In</label>
            <select id="within" name="within">
                <option value="abdn">University Website</option>
                <option value="dir">Staff Directory</option>
                <option value="lib">Library Collections</option>
            </select>
                    <label for="query">Keywords</label>
        <input type="search" id="query" name="query" placeholder="Search" value="">
                <button type="submit">
            <i class="fa fa-search" aria-hidden="true"></i>
            <b>Search</b>
        </button>
    </fieldset>
    <p>Or Browse:</p>
    <ul>
        <li><a href="https://www.abdn.ac.uk/about/contact/">Contacts</a></li>
        <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php" style="speak-as: spell-out;">A to Z</a></li>
        <li><a href="https://www.abdn.ac.uk/people/">Staff Directory</a></li>
    </ul>
</form>
<script>
    document.getElementById('global_search').className += ' collapsed';
</script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
      <div id="section_heading">
        <div class="container">
          <div class="row">
            <div class="col">
                <a href="/about/" class="section_head_text">
                    About                </a>
                            </div>
          </div>
        </div>
      </div>
    <nav id="section_top_level" class="section_top_level_wrapper" aria-label="About navigation">
    <div class="container">

    <ul class="top_level">
    
            <li>
                <a href="/about/schools-institutes/index.php">Schools and Institutes</a>
            </li>
            
            <li>
                <a href="/about/campus/index.php">Campus</a>
            </li>
            
            <li>
                <a href="/about/strategy-and-governance/index.php">Strategy and Governance</a>
            </li>
            
            <li>
                <a href="/about/management/index.php">Management</a>
            </li>
            
            <li>
                <a href="/about/facts-figures/index.php">Facts & Figures</a>
            </li>
            
            <li>
                <a href="/about/history/index.php">History</a>
            </li>
            
            <li>
                <a href="/about/contact/index.php">Contact</a>
            </li>
            
            <li>
                <a href="/about/partnerships/index.php">Partnerships</a>
            </li>
            
            <li>
                <a href="/about/coronavirus/index.php">Coronavirus (Covid-19)</a>
            </li>
            
    </ul>
        </div>
</nav>
<script>
    try {
        document.addEventListener('DOMContentLoaded', function(){
            priorityPlusList = new PriorityPlusList({
                selector: '#section_top_level ul',
                moreButtonContent: '<a href="#">More</a>'
            });
        })
    }
    catch (e) {
        if (typeof console !== 'undefined' && typeof console.log !== 'undefined') {
            console.log('PriorityPlusList does not offer support for your current browser');
        }
    }
</script>

    <h1 class="offscreen">Accessibility Statement for the University of Aberdeen Website</h1>
    
    <div class="breadcrumb_wrapper">
        <div class="container"><div class="breadcrumb" role="navigation" aria-label="Breadcrumb">
    <ol>
        
            <li><a href="https://www.abdn.ac.uk/">University Home</a></li>
            
            <li><a href="/about/">About</a></li>
            
            <li><a href="/about/our-website/index.php">Our Website</a></li>
            
            <li tabindex="0" aria-current="page">Accessibility</li>
                </ol>
</div>

        </div>
    </div>    </header>

<main id="main" class="subpage" tabindex="-1">
        <div class="container">
        <div class="column_container">
            <div class="content_column">
                
                    <div class="section">
                        <div class="container">
                    
                        <div class="h1">Accessibility Statement for the University of Aberdeen Website</div>
                        <h2>Overview</h2>

<p>URL: <a href="https://www.abdn.ac.uk/">https://www.abdn.ac.uk/</a></p>

<p>This website is run by The University of Aberdeen. We want as many people as possible to be able to use this website. For example, that means you should be able to:</p>

<ul>
	<li>change colours, contrast levels and fonts</li>
	<li>zoom in (up to 300%) without the text spilling off the screen</li>
	<li>navigate most of the website using just a keyboard</li>
	<li>navigate most of the website using speech recognition software</li>
	<li>listen to most of the website using a screen reader (including the most recent versions of JAWS, NVDA and VoiceOver)</li>
</ul>

<p>We're working to make website text as simple as possible.</p>

<p><a href="https://mcmw.abilitynet.org.uk/">AbilityNet</a> has advice on making your device easier to use.</p>

<h3>How accessible this website is</h3>

<p>We're confident that our website is largely very accessible; however, we know some parts are not:</p>

<ul>
	<li>some areas may not be fully compatible with screen readers</li>
	<li>you may not be able to access all content by using the keyboard alone</li>
	<li>not all media will have a transcript, or be subtitled</li>
	<li>some text may not reflow in a single column when you change the size of the browser window or use certain levels of magnification</li>
	<li>some older documents (PDF, PowerPoint, Word) are not fully accessible to screen reader software</li>
</ul>

<p>Further <a href="#appendix1">information on specific services and escalation routes is provided in Appendix 1</a>.</p>

<h3 id="feedback-and-contact-information">Feedback and contact information</h3>

<p>If you need information in a different format like accessible PDF, large print, Easy Read, audio recording or braille, please get in touch:</p>

<ul>
	<li>Report an issue online at <a href="https://myit.abdn.ac.uk">myit.abdn.ac.uk</a></li>
	<li>Email <a href="mailto:servicedesk@abdn.ac.uk?subject=Report%20accessibility%20problem">servicedesk@abdn.ac.uk</a></li>
</ul>

<p>We’ll reply to reports within one working day and will aim to provide a workable solution as soon as possible and no later than seven days.</p>

<p>You can also write to us at:</p>

<p>University of Aberdeen,<br />
King's College,<br />
Aberdeen,<br />
AB24 3FX</p>

<h3>Reporting accessibility problems with this website</h3>

<p>We’re always looking to improve the accessibility of this website. If you find any problems not listed on this page or think we’re not meeting accessibility requirements, <a href="#feedback-and-contact-information">please contact us using the details above</a>.</p>

<h3>Enforcement procedure</h3>

<p>The Equality and Human Rights Commission (EHRC) is responsible for enforcing the Public Sector Bodies (Websites and Mobile Applications) (No. 2) Accessibility Regulations 2018 (the ‘accessibility regulations’). If you’re not happy with how we respond to your feedback, <a class="govuk-link" href="https://www.equalityadvisoryservice.com/" rel="external">contact the Equality Advisory and Support Service (EASS)</a>.</p>

<h2>Visiting us in person</h2>

<p>You can arrange to visit the University (for example to visit a Disability Advisor) <a href="#feedback-and-contact-information">using the contact details above</a>. We can provide audio induction loops or a text relay service for people who are D/deaf, hearing impaired or have a speech impediment. If you require a British Sign Language interpreter, please contact us in advance. You can use <a href="https://contactscotland-bsl.org/">contactSCOTLAND-BSL</a> to do this if you prefer.</p>

<h2>Technical information about this website’s accessibility</h2>

<p>The University of Aberdeen is committed to making its website accessible, in accordance with the <a href="http://www.legislation.gov.uk/uksi/2018/852/contents/made">Public Sector Bodies (Websites and Mobile Applications) (No. 2) Accessibility Regulations 2018</a>.</p>

<p>The website is only partially compliant with the <a href="https://www.w3.org/TR/WCAG21/">Web Content Accessibility Guidelines version 2.1</a> (WCAG) AA standard, due to the non-compliances listed below.</p>

<h2>Non-accessible content</h2>

<p>The content listed below is non-accessible for the following reasons.</p>

<h3>Non-compliance with the accessibility regulations</h3>

<p>The following items don’t comply with the WCAG 2.1 AA success criteria. We're working to address these occurrences . We prioritise this work based on volume of traffic (scale) and key user journeys. When we publish new content we’ll make sure this meets accessibility standards. We've created a <a href="https://www.abdn.ac.uk/staffnet/documents/digital-accessibility-policy.docx">Digital Accessibility Policy</a> to ensure staff are aware of their responsiblities. All staff are made aware of accessibility legislation and offered support.</p>

<h4>Text and page structure</h4>

<p>Some of our written content and page structure is not accessible. Examples include:</p>

<ul>
	<li>Meaningless link text e.g. “click here”</li>
	<li>Links using only colour as a distinguishing factor</li>
	<li>Tables without row headers</li>
	<li>Legacy pages that don’t reflow when zoomed or viewed in mobile devices</li>
	<li>Insufficient text colour contrast</li>
	<li>Content which is not semantically structured</li>
</ul>

<p>We constantly audit our site and address these issues as quickly as practicable when they are identified. Our remaining legacy websites that don’t reflow when zoomed are being migrated to new responsive templates or retired. Colour contrast is being audited as part of our template review. We've reviewed and revised our training, and will continue to do so, to provide specific guidance to our content editors and developers.</p>

<h4>Video</h4>

<p>Many videos on our site don’t have transcripts or audio descriptions. We’re reviewing and removing or resolving these, based on order of priority. All new videos published since September 2020 have captions, auto-captions or accessible alternatives.</p>

<h4>Keyboard accessibility</h4>

<p>Alhough our main web templates and applications are fully keyboard accessible, we're aware that other areas of our website may not be. We're addressing these based on order of priority.</p>

<h4>Documents</h4>

<p>Many older PowerPoint, PDF and Word documents don’t meet accessibility standards, for example, they might not be structured in a way that's accessible to a screen reader, or PDFs may not have titles.</p>

<p>We’re reviewing and removing or resolving these based on order of priority. All staff are made aware of accessibility legislation and offered support in the creation of accessible documents, for example <a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-authorscreators/">via user guides</a>. Guidance on creating accessible documents is included in MS Office training workshops and training materials as appropriate.</p>

<p>Please note that <a href="http://www.legislation.gov.uk/uksi/2018/952/regulation/4/made">certain documents may be outside the scope of the accessibility regulations</a>.</p>

<h4>Images</h4>

<p>Many images on our site don’t have alternative content and in most cases this is because they are purely decorative; however, some images don’t have appropriate alternative content, and others represent text as images. We’re addressing these issues through regular auditing and by providing specific guidance and training to our content editors.</p>

<h4>Forms</h4>

<p>Some forms are not correctly labelled and/or are not keyboard accessible. Our forms are being audited and identified issues are addressed; we have raised some of these with our third party supplier, Gecko, as noted in <a href="#appendix2">Appendix 2</a>.</p>

<h4>Other issues</h4>

<p>Further <a href="#appendix2">information on specific technical and content issues is provided in Appendix 2</a>.</p>

<h3>Disproportionate burden</h3>

<p>We’re not claiming disproportionate burden for any of our services at present.</p>

<h3>Content that’s not within the scope of the accessibility regulations</h3>

<p>The <a href="http://www.legislation.gov.uk/uksi/2018/952/regulation/4/made">accessibility regulations</a> don’t require us to fix documents published before 23 September 2018 if they’re not essential to providing our services. Our policy is that any new documents we publish will meet accessibility standards. Any documents essential to providing our service will be fixed or replaced with an accessible HTML page.</p>

<p>We don’t plan to add captions to live video streams because live video is <a href="http://www.legislation.gov.uk/uksi/2018/952/regulation/4/made" rel="external">exempt from meeting the accessibility regulations</a>.</p>

<p>We ensure online maps are as accessible as possible by, for example, providing addresses and geolocation information in an accessible form.</p>

<h2>What we’re doing to improve accessibility</h2>

<p>We’ve an ongoing University-wide commitment to improve accessibility and have put in place governance and support to establish a permanent culture of accessibility and inclusion. Accessibility work is overseen by a Digital Accessibility Working Group, comprising representative members from across the institution.</p>

<p>The University also takes the following measures to ensure accessibility:</p>

<ul>
	<li>Accessibility is an objective of our Strategic Plan</li>
	<li>Accessibility is integrated into training given to all Content Management System editors</li>
	<li>Accessibility is integrated into training given to all designers and developers within the University</li>
	<li>Accessibility is part of our internal policies</li>
	<li>Accessibility is integrated into our procurement practices</li>
	<li>An accessibility officer will be appointed</li>
</ul>

<h2>Preparation of this accessibility statement</h2>

<p>This statement was prepared on 31st March 2020. It was last reviewed 20th July 2022.</p>

<p>This website is tested on an ongoing basis; manually by staff and also via automated testing using the tool <a href="https://siteimprove.com/">Siteimprove</a>. We prioritise work on conformance of our website based on two factors: volume of traffic (scale) and key user journeys.</p>

<p>We use this approach to decide areas for comprehensive testing.</p>

<h3>Examples of areas comprehensively tested</h3>

<table border="1" cellpadding="5" cellspacing="0">
	<thead>
		<tr>
			<th>Section</th>
			<th>Status</th>
			<th>Date tested</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><a href="https://www.abdn.ac.uk/">University Home Page</a></td>
			<td>No issues</td>
			<td>9th June 2020</td>
		</tr>
		<tr>
			<td><a href="https://abdn.primo.exlibrisgroup.com/discovery/search?vid=44ABE_INST:44ABE_VU1">Primo Discovery</a></td>
			<td>Partially conformant</td>
			<td>December 2021</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/library/">Library Website</a></td>
			<td>No issues</td>
			<td>December 2021</td>
		</tr>
		<tr>
			<td><a href="https://on.abdn.ac.uk/">On-Demand Learning</a></td>
			<td>No issues</td>
			<td>23rd July 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/study/">Study Here</a></td>
			<td>No issues</td>
			<td>September 2020</td>
		</tr>
		<tr>
			<td><a href="https://aura.abdn.ac.uk/">Aberdeen University Research Archive</a></td>
			<td>Partially conformant</td>
			<td>24th June 2020</td>
		</tr>
		<tr>
			<td><a href="https://app.geckoform.com/public/#/modern/21FO00fiq9t81700e76n98vbbs">GeckoEngage Form Builder</a></td>
			<td>Partially conformant</td>
			<td>25th June 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/about/our-website/accessibility-test-bed-1054.php">Website Templates</a></td>
			<td>No issues</td>
			<td>September 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/research/acreef/">Legacy Templates</a></td>
			<td>Partially conformant</td>
			<td>25th March 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/news/">News Templates</a></td>
			<td>No issues</td>
			<td>September 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/events/">Events Templates</a></td>
			<td>No issues</td>
			<td>September 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/people/m.mcconnell/">Staff Pages Templates</a></td>
			<td>No issues</td>
			<td>November 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/library/support/exam-papers-180.php">Exam Papers</a></td>
			<td>Partially conformant</td>
			<td>25th March 2020</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/pgap">Postgraduate Applicant Portal</a></td>
			<td>Partially conformant</td>
			<td>9th November 2019</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/eaccommodation">eAccommodation</a></td>
			<td>Partially conformant</td>
			<td>8th October 2019</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/epayments">ePayments</a></td>
			<td>Partially conformant</td>
			<td>17th September 2019</td>
		</tr>
		<tr>
			<td><a href="https://www.abdn.ac.uk/pgap/agents">Agents Portal</a></td>
			<td>Partially conformant</td>
			<td>9th September 2019</td>
		</tr>
	</tbody>
</table>

<h2>Other sites within our domain</h2>

<p>The University website consists of many related sub-sites and systems. The University is responsible for the accessibility of these; some will have their own accessibility statements. If you encounter an issue with any system or site, <a href="#feedback-and-contact-information">please contact us using the details above</a>.</p>

<h2>Mobile applications</h2>

<p>The University makes available various mobile applications to its staff and students. The University is responsible for the accessibility of these; some will have their own accessibility statements. If you encounter an issue with these please <a href="#feedback-and-contact-information">contact us using the details above</a>.</p>

<p>Mobile applications used in support of MyAberdeen are detailed in <a href="#appendix1mobile">Appendix 1</a>.</p>

<h2>Accessibility resources</h2>

<ul>
	<li><a href="https://www.abdn.ac.uk/disabilities/">Disability Services for Students</a></li>
	<li><a href="https://www.abdn.ac.uk/assistivetechnology/">Assistive Technology Services</a></li>
	<li>Fact sheet on <a href="https://www.abdn.ac.uk/library/documents/guides/gen/qggen002.pdf">University Library facilities and services for disabled students</a></li>
	<li><a href="https://www.abdn.ac.uk/staffnet/working-here/support-for-staff-226.php#panel5515">Disability information</a> for University of Aberdeen staff</li>
	<li><a href="https://www.abdn.ac.uk/toolkit/#assistive_technology">eLearning accessibility</a></li>
	<li><a href="https://www.w3.org/TR/WCAG21/">Web Content Accessibility Guidelines (WCAG) 2.1</a></li>
	<li><a href="https://www.rnib.org.uk/services-for-businesses">The RNIB web access centre</a></li>
	<li><a href="http://www.skill.org.uk">National Bureau for Students with Disabilities</a></li>
	<li>British Sign Language (BSL) - <a href="/about/documents/BSL_Plan_29Aug18.docx" target="_blank" title="British Sign Language action plan">Action Plan 2018-2024</a></li>
</ul>

<h2 id="appendix1">Appendix 1 – Specific services</h2>

<h3>MyAberdeen Virtual Learning Environment</h3>

<p>MyAberdeen is the main institutional Virtual Learning Environment. It is powered by Blackboard Learn and includes other software applications, such as Turnitin and Panopto.&nbsp; This accessibility statement aims to cover all the software applications that form part of MyAberdeen. &nbsp;</p>

<h4>Blackboard Learn Software</h4>

<p>Blackboard Learn was developed in accordance WCAG 2.1 Level AA. &nbsp;Blackboard Learn is structured using heading styles which allows for navigation using the keyboard or a screen reader.&nbsp; However, annotated feedback provided in Blackboard Assignments is not yet fully accessible and audio/video comments in assignments currently do not have text transcription.&nbsp; For further details on the accessibility of the platform see Blackboard’s pages on <a href="https://help.blackboard.com/Learn/Student/Ultra/Accessibility">Accessibility in Blackboard Learn</a> and <a href="https://www.blackboard.com/blackboard-accessibility-commitment">Blackboard’s statement of commitment</a>.</p>

<p id="appendix1mobile">Blackboard provide mobile applications for staff and students. Accessibility statements for these are available for <a href="https://help.blackboard.com/Blackboard_App/Accessibility">students</a> and <a href="https://help.blackboard.com/Blackboard_Instructor/Accessibility">staff</a>.</p>

<h4>Blackboard Ally Software</h4>

<p>We’ve integrated <a href="https://help.blackboard.com/Ally/Ally_for_LMS">Blackboard Ally</a> with MyAberdeen to provide feedback and reporting for staff on the accessibility of documents, images and HTML content.&nbsp;</p>

<p>Blackboard Ally also generates <a href="https://help.blackboard.com/Ally/Ally_for_LMS/Student/Alternative_Formats">alternative file formats</a> for students viewing documents on MyAberdeen.&nbsp; For example, a Word document uploaded to a course area can be downloaded as a PDF, MP3, ePub, Beeline Reader or Electronic Braille files.&nbsp;</p>

<h5>Documents, Images and HTML Content</h5>

<p>Common accessibility issues highlighted to staff by Blackboard Ally are:</p>

<ul>
	<li>Colour contrast issues</li>
	<li>Images without alternative text description</li>
	<li>Documents without appropriate tags, titles or heading styles</li>
	<li>Tables without headers</li>
	<li>Scanned documents without OCR (Optical Character Recognition)</li>
</ul>

<p>Each semester, teaching staff publish over 130,000 documents, images, and HTML items on MyAberdeen, mostly in the form of PDFs, images, Word documents and PowerPoint presentations.&nbsp; The overall Ally accessibility score for Spring term course learning materials in the academic year 2021-22 was 62.1%.&nbsp; We work every year with academic schools to identify areas for improvement.</p>

<h4>Virtual Classroom Software</h4>

<p>MyAberdeen has two integrated virtual classroom applications, Blackboard Collaborate, which is widely used, and Microsoft Teams which is currently being piloted.&nbsp; Both platforms are compatible with screen-readers and allow keyboard navigation.&nbsp;</p>

<p>Collaborate provides live person-generated captions which may be used to support students with a declared hearing impairments and functionality to pin a web cam to keep it visible on screen.&nbsp; In addition, staff may add captions to recordings.&nbsp; Future developments will include automatic live captions.&nbsp; Detailed technical information on the accessibility of Collaborate is available in the <a href="https://help.blackboard.com/Collaborate/Ultra/Administrator/Accessibility">Blackboard Collaborate help</a> page.&nbsp;</p>

<p>Microsoft Teams has the facility for live automatic captions and to pin a web cam.&nbsp; Detailed technical information on the accessibility of Microsoft Teams is available on the <a href="https://support.microsoft.com/en-us/office/accessibility-overview-of-microsoft-teams-2d4009e7-1300-4766-87e8-7a217496c3d5">Microsoft Teams support</a> page.</p>

<h4>Turnitin Software</h4>

<p>We’ve integrated Turnitin text-matching software with MyAberdeen to help identify plagiarism in student submissions.&nbsp; <a href="https://help.turnitin.com/integrity/accessibility.htm">Turnitin Originality Report and Feedback Studio can be navigated by using the keyboard or a screen reader</a>.&nbsp; However, Turnitin is not yet fully accessible so provides a text-only similarity report which is compatible with assistive technology.&nbsp; Audio comments currently do not have text transcription.&nbsp; Detailed technical information on the accessibility of Turnitin is available in the <a href="https://www.turnitin.com/about/accessibility">Turnitin Voluntary Product Accessibility Templates</a>.</p>

<h4>Questionmark Software</h4>

<p>A small number of courses make use of assessments using Questionmark software.&nbsp; Detailed technical information on the accessibility of Questionmark can be found on <a href="https://support.questionmark.com/content/accessibility-statement">Questionmark’s accessibility statement</a>.</p>

<h4>Panopto Software</h4>

<p>The University generates 13,000 hours of media each year, mostly in the form of lecture capture video, which is hosted on our media platform, Panopto.&nbsp; A detailed technical assessment on the accessibility of Panopto (for web and mobile app) is available in the <a href="https://support.panopto.com/s/article/Learn-About-Accessibility-Features">Panopto Voluntary Product Accessibility Template</a> (VPAT) document.</p>

<h3>Audio/Video Material</h3>

<p>We’re committed to improving the accessibility of media on Panopto and have introduced measures to help make learning material more inclusive.&nbsp; In the academic year 2021-22, approximately 40% of videos generated have closed captions.&nbsp;</p>

<p>We provide schools with <a href="https://www.abdn.ac.uk/coursebooking/">staff development</a> along with <a href="https://www.abdn.ac.uk/staffnet/teaching/support-and-guidance-14122.php#panel14151">guidance and funding to enable good quality closed captions to be provided</a>.&nbsp; In the first instance, staff are encouraged to caption their own video material, using tools built into the Panopto service.&nbsp; We also provide content creators with guidance on how to generate transcripts and audio description using Panopto and the Dictate feature in Microsoft Word.</p>

<p>However, some videos only have automated captions where staff have been unable to provide good quality captions and some videos have no captions if staff feel the accuracy of automated captions would be detrimental to the student experience (e.g. in languages and STEM subjects). In such cases accessible alternative materials are made available.</p>

<p>We’ll continue to work towards improving the accessibility of media and providing suitable tools to make this process less time consuming for academic staff and more beneficial for our students.</p>

<h4>Action Taken by the University</h4>

<h3>Staff Development</h3>

<p>In January 2022, we launched a <a href="https://www.abdn.ac.uk/staffnet/teaching/inclusivity-and-accessibility-in-education-framework.php">Inclusivity and Accessibility Framework</a> for staff which brings together the guidance and support available.</p>

<p>We provide <a href="https://www.abdn.ac.uk/coursebooking/">staff development sessions</a> throughout the year which show how to make course areas, documents, and media on MyAberdeen more accessible.&nbsp; Written guidance and supporting resources are also available on our <a href="https://www.abdn.ac.uk/toolkit/skills/accessibility-for-authorscreators/">Toolkit “Accessibility for Authors and Creators”</a>. &nbsp;</p>

<h4>Course Accessibility Service</h4>

<p>To support teaching staff and help raise awareness, the eLearning Team have introduced a <a href="https://www.abdn.ac.uk/staffnet/teaching/what-we-do-9645.php#panel14234">Course Accessibility Service</a>.&nbsp; This service includes an audit of individual course areas on MyAberdeen and the generation of a detailed report highlighting digital accessibility issues found within the course.&nbsp; In addition to the audit and report, the service also provides the time of an eLearning Support Assistant to make changes to learning materials in agreement with teaching staff with the aim of improving accessibility for users.</p>

<p>Common accessibility issues highlighted by the service are:</p>

<ul>
	<li>Tables without row headers</li>
	<li>Insufficient text colour contrast</li>
	<li>Content which is not semantically structured</li>
	<li>Videos without closed captions, transcripts or audio descriptions</li>
	<li>Areas which are not fully keyboard accessible</li>
	<li>Many PowerPoint, PDF and Word documents are not compliant</li>
	<li>Images without ALT tags</li>
	<li>Some forms may not be correctly labelled and/or are not keyboard accessible</li>
	<li>Handwritten lecture material</li>
</ul>

<h4>Funding Support to Improve Video Captioning</h4>

<p>To further support schools make video more accessible, central funds are made available to each school allowing them to pay for Post Graduate Research Students to support the provision of good quality captions, where the academic is unable to do so.&nbsp;</p>

<p>Where the University is aware of a course with a student with a hearing impairment (or other identified need), the academic staff in the course are offered access to a centrally funded external service (<a href="https://cielo24.com/">Cielo24</a>) by the eLearning Team to ensure that all videos in their course have good quality closed captions. &nbsp;This inclusive approach ensures that all students on the course can benefit from the video captions.</p>

<h4>Procedure for Procurement</h4>

<p>In 2021, the eLearning team created a procedure for checking eLearning software for accessibility ahead of procurement to help ensure that new systems which are introduced are inclusive for all our users.&nbsp; The eLearning team also feedback to software providers and encourage developers to make eLearning software accessible as part of that process.</p>

<h4>Contact Information</h4>

<p>If you are a student and wish to raise an issue or need information in a different format, please get in touch with your course coordinator in the first instance. &nbsp;If course coordinators cannot resolve the issue, please contact the eLearning team at <a href="mailto:elearning@abdn.ac.uk">elearning@abdn.ac.uk</a> or <a href="tel:+441224273765">+44(0)1224 273765</a>.</p>

<h3>Dental and Medical Virtual Learning Environments</h3>

<h4>MyMBChB</h4>

<p>MyMBChB, MyBDS and MyPA are in-house developed virtual learning environments used by the Medical School and built by the Learning Technologies team. We are continually improving the user experience for all users of the application and are applying the relevant accessibility standards throughout.</p>

<p>The environments are partially compliant with the WCAG 2.1 AA standard.</p>

<h4>Non-accessible content</h4>

<p>These environments may only be partially compliant with the standard due to the following:</p>

<ul>
	<li>Meaningless link text e.g. “click here”</li>
	<li>Links using only colour as a distinguishing factor</li>
	<li>Tables without row headers</li>
	<li>Pages that don’t reflow when pinched or zoomed on mobile devices</li>
	<li>Insufficient text colour contrast</li>
	<li>Lack of visual focus when using keyboard navigation</li>
	<li>Videos without closed captions, transcripts, or audio descriptions</li>
	<li>Teaching assets in PowerPoint, PDF or Word documents which may have accessibility issues</li>
</ul>

<p>Please note the list above is not exhaustive. We regularly audit our site and are addressing these issues as they are identified. For new video assets, auto-captioning will be used to provide captions. Staff have been provided with documentation and training in providing accessible assets, as elsewhere in this statement.</p>

<p>Occasionally the quality of unedited automatic captions for specialist terminology may be poor and academic staff may decide this is detrimental to students’ learning. In such cases automated captions may not be provided by default and accessible alternative materials will be provided while manual work takes place to provide accurate captioning.</p>

<h5>Specific areas of non-compliance</h5>

<p>MyMBChB’s student timetable cannot be read meaningfully using a screen reader. However, an alternative accessible version is available via the ‘List View’ link which can be found in the timetable menu or from the tab button quick links.</p>

<h4>If you cannot access parts of these environments or wish to report an accessibility problem</h4>

<p>We welcome your feedback on the accessibility of MyMBChB, MyBDS and MyPA. If you wish to raise an issue, or need information in a different format such as an accessible PDF, large print, Easy Read, audio recording or braille, please contact the Learning Technologies team via email <a href="mailto:learning-technologies@abdn.ac.uk">learning-technologies@abdn.ac.uk</a> or phone <a href="tel:+441224437032">+44(0) 1224 437032</a>.</p>

<h4>Integrations</h4>

<p>MyMBChB, MyBDS and MyPA have integrations with the following systems:</p>

<ul>
	<li><a href="https://abdn.cloud.panopto.eu/">Panopto</a></li>
	<li><a href="https://www.abdn.ac.uk/medical/elf/">ELF (E-Learning Framework)</a></li>
	<li><a href="https://www.questionmark.com/">Questionmark Perception</a></li>
</ul>

<p>The University is responsible for the accessibility of these systems. Should you encounter an issue, please email <a href="mailto:learning-technologies@abdn.ac.uk">learning-technologies@abdn.ac.uk</a> or phone <a href="tel:+441224437032">+44(0)1224 437032</a>.</p>

<h3 id="appendix1lib">Library, Special Collections &amp; Museums Collections</h3>

<p>Library, Special Collections &amp; Museums (LSCM) provide collections to staff, students and others which are primarily asset based (Word, PDF, PowerPoint and JPG files). We believe these assets are largely <a href="http://www.legislation.gov.uk/uksi/2018/852/regulation/3/made">exempt as described in sections 3 (2) (a) and 3 (2) (f) of the legislation</a>. However, it is our intent to make our collections as accessible as possible and therefore we note below issues of which we are aware and actions we are taking to address these.</p>

<p>Should you encounter an issue with the collections listed below, please email <a href="mailto:library@abdn.ac.uk">library@abdn.ac.uk</a> and we will endeavour to help you.</p>

<h4>Exam Papers</h4>

<p>LSCM make available to students a database of past exam papers. This database can be interrogated using the Library search interface, <a href="https://abdn.primo.exlibrisgroup.com/">Primo</a>, or browsed by subject area. A proportion of exam papers available in the database don’t meet the accessibility standard, as they are published in earlier formats of Microsoft Word.</p>

<p>We'll ensure that future papers are made accessible via staff training as noted elsewhere in this statement.</p>

<h4>Research Archive (Aberdeen University Research Archive [AURA])</h4>

<p>The University’s Research Archive is hosted by the University of Edinburgh using the open source solution, <a href="https://duraspace.org/dspace/">DSPace</a>. Archived assets are overwhelmingly PDF assets (c. 11K) or Word docx files (c. 1.5K) with small numbers of other formats such as PowerPoint, HTML and JPG. Many of these assets will not be fully accessible.</p>

<p>It is a current requirement of many research funders and the Research Excellence Framework that papers are submitted as PDF. We will ensure that future papers are made as accessible as possible via staff training as noted elsewhere in this statement. We are considering future use of the Open Document Format to increase the accessibility of this archive.</p>

<h4>Theses</h4>

<p>LSCM make research theses available online. These may be in PDF, various versions of Word or other asset types, including deprecated word-processed files. Many of these assets will not be accessible.</p>

<h4>eBooks and Journals</h4>

<p>At the time of writing, certain eBooks and journal articles available via our online library catalogue may not be accessible. We're evaluating this issue and will engage with third-party publishers if necessary.</p>

<p>We'll ensure that future theses are made as accessible as possible via appropriate training and support for students.</p>

<h4>Archive Collections - CalmView</h4>

<p>We use <a href="https://www.axiell.com/uk/solutions/product/calmview-5/">Axiell’s CalmView5</a> to facilitate access to our archives. Axiell believe the CalmView product is compliant with the regulations, except for embedded Instagram social widgets, specifically:</p>

<ul>
	<li>iframe content lacks a title</li>
	<li>social images lack ALT text</li>
</ul>

<p>We don't have a workaround for these exceptions at present.</p>

<h3 id="appendix1res">Research</h3>

<h4>Pure Research Portal</h4>

<ul>
	<li>The Pure Research Portal is designed to be responsive and work well on all devices.</li>
	<li>Our software provider continues to work towards making the Pure Research Portal fully WCAG 2.1 AA compliant.</li>
	<li>The current web accessibility statement can be read at <a href="https://abdn.pure.elsevier.com/en/web-accessibility/">https://abdn.pure.elsevier.com/en/web-accessibility/</a></li>
</ul>

<h2 id="appendix2">Appendix 2 – Specific technical and content issues</h2>

<p>We are aware of specific issues on our site which may appear as accessibility problems, or for which there is no straightforward resolution.</p>

<h3>Google Search</h3>

<p>We use Google services to provide search functionality to parts of our site. We don’t have control over the code used in these results and this may occasionally cause issues. For example, images returned in Google’s custom search results don’t have alternative text attributes. <a href="https://www.google.co.uk/accessibility/customers-partners/">Google commit to making accessibility a core part of their products</a> and typically issues are resolved quickly.</p>

<h3>iFrames</h3>

<p>We’re aware that some browsers allow the iFrame element to receive focus, but don’t allow for that focus to be styled, so it is possible that for some users, focus may be lost briefly when entering an iFrame element. This is most notable in Firefox.</p>

<h3>Generic Link Text</h3>

<p>We try to make all link text meaningful; however, parts of our site intentionally use generic link text; for example, "Find out more". We believe that where such link text is used the linked resource is unequivocally inferred from its surrounding context; for example, further information on a news story.</p>

<h3>Link Syntax</h3>

<p>We’re aware that occasionally the same link text is used for links going to apparently different resources; for example, the word ‘About’ appearing in the page content, menu bar and site breadcrumb is variously linked to:</p>

<ul>
	<li><a href="https://www.abdn.ac.uk/about/">https://www.abdn.ac.uk/about/index.php</a></li>
	<li><a href="https://www.abdn.ac.uk/about/">http://www.abdn.ac.uk/about/index.php</a></li>
	<li><a href="https://www.abdn.ac.uk/about/">https://www.abdn.ac.uk/about/</a></li>
</ul>

<p>These links appear to be different, but are the same resource. We endeavour to standardise link URLs to avoid this false positive error, but this is not always possible due to how pages are rendered by the server and the CMS database.</p>

<h3>GeckoEngage</h3>

<p>We use a form builder solution from <a href="https://geckoengage.com/">GeckoEngage</a>. We’ve reviewed this for accessibility and found minor issues which we have reported to the supplier (for example, embedded forms don't have titles). The supplier has assessed these issues and is scheduling work to address them. We’ll continue to engage with the supplier.</p>

<h3>Panopto</h3>

<p>We use <a href="https://www.panopto.com/">Panopto</a> extensively throughout our website. Currently there is an issue where Panopto videos embedded in an iFrame display an &lt;img&gt; element without a text alternative. We've raised this issue with Panopto and they've assured us it will be resolved.</p>

<p>Last reviewed: 20th July 2022<br />
Last updated: 10th August 2022</p>
                        </div>
                    </div>
                                </div>
            <div class="subsection_column">
                
<div id="section_nav_wrapper" class="section">
    <div id="section_nav" class="container">

    <nav id="primary_nav" role="navigation" aria-label="Section Menu">
        <h2 id="primary_nav_breadcrumb" class="offscreen">Breadcrumb</h2>
    
        <ul aria-labelledby="primary_nav_breadcrumb">
        
            <li><a href="/">University Home</a></li>
            
            <li><a href="/about/index.php">About</a></li>
            
            <li><a href="/about/our-website/index.php">Our Website</a></li>
            
        </ul>
        
        <h2 class="offscreen">In This Section</h2>
        <ul class="open" aria-label="In This Section">
        
                <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                
                <li><a href="/about/our-website/accessibility.php" class="current" aria-current="page">Accessibility</a></li>
                
                <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                
                <li><a href="/about/our-website/notice-and-takedown-policy-675.php">Notice and Takedown </a></li>
                
        </ul>
        
    </nav>
    <nav class="global_nav clearfix" role="navigation" aria-label="Quick Links">
    <h2>Quick Links</h2>
    <div id="link_wrapper" class="clearfix">
        <div class="quick_links_col">
            <h3>Our Website</h3>
            <ul aria-label="Our Website">
                <li><a href="https://www.abdn.ac.uk/study/">Study</a></li>
                <li><a href="https://www.abdn.ac.uk/about/">About</a></li>
                <li><a href="https://www.abdn.ac.uk/research/">Research</a></li>
                <li><a href="https://www.abdn.ac.uk/alumni/">Alumni &amp; Giving</a></li>
                <li><a href="https://www.abdn.ac.uk/business-info/">Business</a></li>
                <li><a href="https://www.abdn.ac.uk/news/">News</a></li>
                <li><a href="https://www.abdn.ac.uk/events/">Events</a></li>
            </ul>
        </div>
        <div class="quick_links_col">
            <h3>Popular</h3>
            <ul aria-label="Popular Pages">
                <li><a href="https://www.abdn.ac.uk/students/">For Students</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/">For Staff</a></li>
                <li><a href="https://www.store.abdn.ac.uk/">Online Store</a></li>
                <li><a href="https://www.abdn.ac.uk/jobs/">Jobs</a></li>
                <li><a href="https://www.abdn.ac.uk/library/">Library</a></li>
                <li><a href="https://www.abdn.ac.uk/staffnet/directory.php">Staff Directory</a></li>
                <li><a href="https://www.abdn.ac.uk/it/">IT Services</a></li>
                <li><a href="https://www.abdn.ac.uk/about/our-website/atoz.php">A to Z</a></li>
                <li><a href="https://www.abdn.ac.uk/about/campus/maps/">Campus Maps</a></li>
            </ul>
        </div>
    </div>
</nav>

    </div>
</div>
            </div>
        </div>
    </div>
    </main>
<footer>
    <div class="container">
        <div class="footer_wrapper">
            <div class="right_column">
                <ul class="footer_utility_links">
                    <li><a href="/students/">For Students</a></li>
                    <li><a href="/staffnet/">For Staff</a></li>
                    
                        <li><a href="/about/sitemap.php">Sitemap</a></li>
                                        </ul>
                                <div class="global_social">
                    <h2>Connect With Us</h2>
                    <ul>
                        <li>
                            <a href="https://www.youtube.com/user/uniofaberdeen" class="fab fa-youtube" title="YouTube" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">YouTube</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/aberdeenuni/" class="fab fa-twitter" title="Twitter" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Twitter</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/universityofaberdeen/" class="fab fa-facebook-square" title="Facebook" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Facebook</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://pinterest.com/aberdeenuni/" class="fab fa-pinterest" title="Pinterest" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Pinterest</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/uniofaberdeen/" class="fab fa-instagram" title="Instagram" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Instagram</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.linkedin.com/school/13849" class="fab fa-linkedin" title="LinkedIn" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">LinkedIn</i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.weibo.com/abdn" class="fab fa-weibo" title="Weibo" target="_blank" rel="noopener noreferrer">
                                <i class="offscreen">Weibo</i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="left_column">
                <div class="global_contact" itemscope itemtype="https://schema.org/CollegeOrUniversity">
                    <h2 class="offscreen">Contact Us</h2>
                    <a href="https://www.abdn.ac.uk/" class="uni_logo_footer">
                        <img src="/global/images/layout/UoA_Landscape_Logo_RGB_REVERSE_2018.png?cb=20221026" srcset="/global/images/layout/UoA_Landscape_Logo_CMYK_REVERSE_2018.svg?cb=20221026" alt="University of Aberdeen">
                    </a>
                    <dl>
                        <dt>Address</dt>
                        <dd class="address" itemscope itemtype="https://schema.org/PostalAddress">
                            <span itemprop="name">University of Aberdeen</span><br>
                            <span itemprop="streetAddress">King's College</span>,<br>
                            <span itemprop="addressLocality">Aberdeen</span>,<br>
                            <span itemprop="postalCode">AB24 3FX</span>
                        </dd>
                        <dt>Phone</dt>
                        <dd itemprop="telephone" class="phone">
                            Tel: <a href="tel:+441224272000">+44 (0)1224 272000</a>
                        </dd>
                    </dl>
                    <div class="where_are_we utility">
                        <ul>
                            <li><a href="/about/contact/">Contacts</a></li>
                            <li><a href="/about/our-website/atoz.php">A to Z</a></li>
                            <li><a href="/about/campus/maps/">Maps and Directions</a></li>
                            <li><a href="/people/">Staff Directory</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="top_of_page_align">
            <a href="#top" class="top_of_page">Top of Page</a>
        </div>
    </div>
    <div class="dark">
        <div class="container">
            <div class="legals utility">
                <ul>
                    <li><a href="/about/our-website/privacy.php">Privacy Statement</a></li>
                    <li><a href="/about/our-website/accessibility.php">Accessibility</a></li>
                    <li><a href="/about/our-website/cookies.php">Cookies</a></li>
                    <li><a href="/slavery-statement/">Slavery &amp; Human Trafficking Statement</a></li>
                    <li><a href="/staffnet/governance/freedom-of-information-254.php?utm_source=website-address&utm_medium=web-link&utm_campaign=FOI">Freedom of Information</a></li>
                </ul>
            </div>
            <div class="charity">
                <p>The University of Aberdeen is a charity registered in Scotland, No.SC013683</p>
            </div>
        </div>
    </div>
</footer>
<script src="/global/js/opentext_responsive/navigation.js?cb=20221026"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/typeahead.bundle-0.11.1.min.js"></script>
<script src="https://uoab-search.squiz.cloud/s/resources-global/js/funnelback.autocompletion-2.6.0.js"></script>
<script src="/global/js/opentext_responsive/funnelback_search.js?cb=20221026"></script>
<script>
    $(document).ready(function() {
        $('iframe[src*="kaltura.com"], iframe[src*="youtube.com"], iframe[src*="vimeo.com"], iframe[src*="prezi.com"], iframe[src*="panopto.eu"], div[class="kWidgetIframeContainer"]').each(function() {
            var $this = $(this);

            // remove any inline style
            $this.removeAttr('style');

            if ($this.hasClass('kWidgetIframeContainer')) {
                // remove Kaltura class
                $this.removeClass('kWidgetIframeContainer');

                // add responsive container class
                $this.addClass('video_container');
                return;
            }

            // get the video source
            var src = $this.attr('src');

            // ensure https;
            if (src.indexOf('http:') > -1) {
                src = src.replace('http:', 'https:');
            }

            // ensure correct kaltura domain being used
            if (src.indexOf('cdnapi.kaltura') > -1) {
                src = src.replace('cdnapi.kaltura', 'cdnapisec.kaltura');
            }

            // if it's a playlist
            if ($this.attr('src').match(/playlistAPI/)) {
                $this.css('width', '100%');
                return;
            }

            // add a wrapper
            if (!$this.parent().hasClass('video_container') && !$this.parent().parent().hasClass('homepage_video_container')) {
                $this.wrap('<div class="video_container"></div>');
            };

            // force Youtube to show related videos from the channel the original video came from
            if (src.indexOf('youtube') > -1) {
                if (src.indexOf('rel=') > -1) {
                    src = src.replace(/rel=[1-9]/, 'rel=0');
                }
                else {
                    if (src.indexOf('?') === -1) {
                        src += '?';
                    }
                    else {
                        src += '&';
                    }

                    src += 'rel=0';
                }
            }

            $this.attr('src', src);
        });

        $('table').each(function() {
            // add a wrapper
            $(this).wrap('<div class="responsive_table"></div>');
            $(this).css('table-layout', 'auto');
            $(this).css('width', '100%');
        });

        $('#uni_menu > ul > li > a').each(function() {
            var the_prefix = $(this).html().toLowerCase().replace(/(\&amp;)/g, '').replace(/\s/g, '');

            $(this).parent().find('a').addClass('uni_menu_' + the_prefix);
        });

        // check all links in content for URLs as text and wrap them
        var url_regex = /((https?|ftp|rtmp):\/\/)?(www\.)?([-a-z0-9_]+\.)+([a-z]){2,4}/i;

        $('main').find('a').each(function() {
            var has_url = url_regex.test($(this).text());

            if (has_url) {
                $(this).addClass('wrap_url');
            }
        });

        // ensafen target _blank
        $('main').find('a[target="_blank"]').each(function() {
            $(this).attr('rel', 'noopener noreferrer');
        });

});
    //  This extends jQuery selector to find any element that can gain focus
    jQuery.extend(jQuery.expr[':'], {
        focusable: function(el, index, selector) {
            return $(el).is('button, [href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])');
        }
    });
</script>

                <script src="https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js"></script>
                
                <script src="/global/cookies/js/cookie-consent.js?cb=20221026"></script>
                    </body>
</html>
